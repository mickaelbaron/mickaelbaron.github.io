package eclipse.swt.TransparencyExamples;

import java.util.HashMap;
import java.util.Map;

import com.sun.jna.Native;
import com.sun.jna.win32.StdCallLibrary;
import com.sun.jna.win32.W32APIFunctionMapper;
import com.sun.jna.win32.W32APITypeMapper;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
@SuppressWarnings("serial")
public interface User32 extends StdCallLibrary {

	@SuppressWarnings("unchecked")
	Map UNICODE_OPTIONS = new HashMap() {
		{
			put(OPTION_TYPE_MAPPER, W32APITypeMapper.UNICODE);
			put(OPTION_FUNCTION_MAPPER, W32APIFunctionMapper.UNICODE);
		}
	};
	@SuppressWarnings("unchecked")
	Map ASCII_OPTIONS = new HashMap() {
		{
			put(OPTION_TYPE_MAPPER, W32APITypeMapper.ASCII);
			put(OPTION_FUNCTION_MAPPER, W32APIFunctionMapper.ASCII);
		}
	};

	@SuppressWarnings("unchecked")
	Map DEFAULT_OPTIONS = Boolean.getBoolean("w32.ascii") ? ASCII_OPTIONS
			: UNICODE_OPTIONS;

	User32 INSTANCE = (User32) Native.loadLibrary("user32", User32.class,
			DEFAULT_OPTIONS);

	int GWL_EXSTYLE = -20;
	int WS_EX_LAYERED = 0x80000;

	int LWA_COLORKEY = 1;
	int LWA_ALPHA = 2;
	
	int GetWindowLong(int hWnd, int nIndex);
	int SetWindowLong(int hWnd, int nIndex, int dwNewLong);

	boolean SetLayeredWindowAttributes(int hwnd, int crKey, byte bAlpha,
			int dwFlags);
}
