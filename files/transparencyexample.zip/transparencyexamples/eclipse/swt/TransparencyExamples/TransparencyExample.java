package eclipse.swt.TransparencyExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class TransparencyExample {
	public TransparencyExample() {
		final Display display = new Display();
		final Shell myShell = new Shell(display, SWT.SHELL_TRIM | SWT.ON_TOP);
		myShell.setText("Transparency Example");
		myShell.setLayout(new FillLayout(SWT.VERTICAL));
		
		final Button myButton = new Button(myShell,SWT.NONE);
		myButton.setText("Go To The Transparency Dream");

		final Composite myComposite = new Composite(myShell, 0x80000);
		Color colorBlack = Display.getDefault().getSystemColor(SWT.COLOR_DARK_BLUE);
		myComposite.setBackground(colorBlack);
			
		myShell.setSize(400, 200);
		myShell.setLocation(0, 0);
		myShell.open();
			
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				User32 lib = User32.INSTANCE;

		        int flags = lib.GetWindowLong(myShell.handle, User32.GWL_EXSTYLE);
		        flags |= User32.WS_EX_LAYERED;		        
		        lib.SetWindowLong(myShell.handle, User32.GWL_EXSTYLE, flags);
		        Color myColor = Display.getDefault().getSystemColor(SWT.COLOR_DARK_BLUE);		        
		        lib.SetLayeredWindowAttributes(myShell.handle, myColor.handle, (byte)200, User32.LWA_COLORKEY | User32.LWA_ALPHA);		        
			}			
		});
		
		while(!myShell.isDisposed()) {
		if (!display.readAndDispatch())
		display.sleep();
		}
		display.dispose();		
	}
	
	public static void main(String[] argv) {
		new TransparencyExample();
	}
}
