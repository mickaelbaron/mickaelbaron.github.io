package eclipse.swt.SWTGlassPaneExamples;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class SWTGlassPane {
	
	/**
	 * Main window where the SWTGlassPane is linked. 
	 */
	private Shell windowParent;
	
	/**
	 * Transparency layout. It aims to catch mouse interaction when the glasspane is enabled.
	 */
	private Shell transparencyShell;
	
	/**
	 * GlassPane layout. It aims to draw the transparency content.
	 */
	private Shell glassPaneShell;
	
	/**
	 * Color used for specifying the transparency color key.
	 */
	private Color transparencyColor;
	
	/**
	 * Listeners from client.
	 */
	private List<MouseListener> mouseListeners;
	
	public SWTGlassPane(Shell pWindowParent, Color pColor) {
		this.transparencyColor = pColor;
		this.windowParent = pWindowParent;
		
		mouseListeners = new ArrayList<MouseListener>();
		
		transparencyShell = new Shell(windowParent, SWT.NO_TRIM);	
		
		glassPaneShell = new Shell(transparencyShell, SWT.NO_TRIM);
		glassPaneShell.setBackground(transparencyColor);
		
		// Dispatch event from Transparency layout to GlassPane layout.
		transparencyShell.addMouseListener(new MouseListener() {
			
			public void mouseDoubleClick(MouseEvent event) {			
				for (MouseListener iterable_element : mouseListeners) {
					iterable_element.mouseDoubleClick(event);
				}
			}

			public void mouseDown(MouseEvent event) {
				for (MouseListener iterable_element : mouseListeners) {
					iterable_element.mouseDown(event);
				}	
			}

			public void mouseUp(MouseEvent event) {			
				for (MouseListener iterable_element : mouseListeners) {
					iterable_element.mouseUp(event);
				}
			}			
		});
		
		this.windowParent.addControlListener(new ControlListener() {
			public void controlMoved(ControlEvent event) {
				setShellBounds();
			}

			public void controlResized(ControlEvent event) {
				setShellBounds();
			}			
		});
		
		// Transparency management.
		User32 lib = User32.INSTANCE;

        int flags = lib.GetWindowLong(glassPaneShell.handle, User32.GWL_EXSTYLE);
        flags |= User32.WS_EX_LAYERED;		        
        lib.SetWindowLong(glassPaneShell.handle, User32.GWL_EXSTYLE, flags);
        Color myColor = Display.getDefault().getSystemColor(SWT.COLOR_BLUE);		        
        lib.SetLayeredWindowAttributes(glassPaneShell.handle, myColor.handle, (byte)0, User32.LWA_COLORKEY); 
        
        flags = lib.GetWindowLong(transparencyShell.handle, User32.GWL_EXSTYLE);
        flags |= User32.WS_EX_LAYERED;		        
        lib.SetWindowLong(transparencyShell.handle, User32.GWL_EXSTYLE, flags);	        
        lib.SetLayeredWindowAttributes(transparencyShell.handle, 0, (byte)1, User32.LWA_ALPHA); 

        setShellBounds();        
	}

	public Composite getGlassPane() {
		return this.glassPaneShell;
	}
	
	public void addMouseMoveListener(MouseMoveListener pMouseMoveListener) {
		transparencyShell.addMouseMoveListener(pMouseMoveListener);		
	}
	
	public void addMouseListener(MouseListener pMouseListener) {
		mouseListeners.add(pMouseListener);
		glassPaneShell.addMouseListener(pMouseListener);
	}
	
	public void addPaintListener(PaintListener pPaintListener) {
		glassPaneShell.addPaintListener(pPaintListener);
	}
	
	public void setEnable(boolean pEnable) {
		if (transparencyShell == null || glassPaneShell == null) {
			return;
		}	
		
		setShellBounds();
		
		transparencyShell.setVisible(pEnable);
		glassPaneShell.setVisible(pEnable);		
	}
	
	private void setShellBounds() {
		Rectangle clientArea = windowParent.getClientArea();
		Point locationPoint = windowParent.toDisplay(0, 0);
		
		transparencyShell.setSize(clientArea.width, clientArea.height);
		transparencyShell.setLocation(locationPoint.x, locationPoint.y);
		
		glassPaneShell.setSize(clientArea.width, clientArea.height);
		glassPaneShell.setLocation(locationPoint.x, locationPoint.y);
	}
}
