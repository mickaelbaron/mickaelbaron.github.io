package eclipse.swt.SWTGlassPaneExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class SWTGlassPaneExample {

	private Button checkButton;

	public SWTGlassPaneExample() {
		final Display display = new Display();
		final Shell myShell = new Shell(display);
		myShell.setText("SWTGlassPane Example");
		RowLayout rl = new RowLayout();
		rl.pack = false;
		rl.marginTop = 20;
		rl.marginLeft = 50;
		myShell.setLayout(rl);
		
		checkButton = new Button(myShell, SWT.CHECK);
		checkButton.setText("Glass pane \"visible\"");

		final Button myButton1 = new Button(myShell, SWT.FLAT);
		myButton1.setText("Button 1");
		
		final Button myButton2 = new Button(myShell, SWT.FLAT);
		myButton2.setText("Button 2");
			
		myShell.setSize(450, 100);
		myShell.setLocation(0, 0);
		myShell.open();

		final SWTGlassPane myGlassPane = new SWTGlassPane(myShell, Display.getDefault().getSystemColor(SWT.COLOR_BLUE));
			
		myGlassPane.addMouseListener(new MouseAdapter() {
			public void mouseUp(MouseEvent e) {
				final int gap = 2;
				Rectangle cursor = new Rectangle(e.x, e.y, gap, gap);
				if (checkButton.getBounds().intersects(cursor)) {
					myGlassPane.setEnable(false);
					checkButton.setSelection(false);
				} else {					
					GC myGC = new GC(myGlassPane.getGlassPane());
					myGC.setAdvanced(true);
					Color myColor = new Color(display,50,50,50);
					myGC.setBackground(myColor);
					myGC.fillOval(e.x, e.y, 15, 15);
					myGC.dispose();
				}
			}			
		});
		
		myGlassPane.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent event) {
				Color systemColor = Display.getDefault().getSystemColor(SWT.COLOR_CYAN);
				event.gc.setBackground(systemColor);
				event.gc.fillOval(10, 10, 55, 55);
			}			
		});

		checkButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				myGlassPane.setEnable(true);
			}			
		});
		
		while(!myShell.isDisposed()) {
		if (!display.readAndDispatch())
		display.sleep();
		}
		display.dispose();		
	}

	public static void main(String[] argv) {
		new SWTGlassPaneExample();
	}
}
