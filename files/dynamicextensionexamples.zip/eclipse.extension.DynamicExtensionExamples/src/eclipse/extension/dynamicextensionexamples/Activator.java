package eclipse.extension.dynamicextensionexamples;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IRegistryEventListener;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public class Activator extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "eclipse.extension.DynamicExtensionExamples";

	// The shared instance
	private static Activator plugin;
	
	/**
	 * The constructor
	 */
	public Activator() {
		Platform.getExtensionRegistry().addListener(new IRegistryEventListener() {
			public void added(IExtension[] extensions) {
				System.out.println("extension added : ");
				for (IExtension currentExtension : extensions) {
					IConfigurationElement[] configurationElements = currentExtension.getConfigurationElements();
					for (IConfigurationElement configurationElement : configurationElements) {
						System.out.println("  - " + configurationElement.getAttribute("id"));
					}
				}
			}

			public void added(IExtensionPoint[] extensionPoints) {
				System.out.println("extension point added : ");
				for (IExtensionPoint currentExtensionPoint : extensionPoints) {
					System.out.println("  - " + currentExtensionPoint.getUniqueIdentifier());
				}
			}

			public void removed(IExtension[] extensions) {
				
			}

			public void removed(IExtensionPoint[] extensionPoints) {
				
			}			
		});
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given
	 * plug-in relative path
	 *
	 * @param path the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}
}
