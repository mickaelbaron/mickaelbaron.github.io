package eclipse.jface.TableViewerExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.AbstractTableViewer;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ILazyContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class LazyContentProviderExample {
	public LazyContentProviderExample() {
		Display display = new Display();
		
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer utilisant un ILazyContentProvider");
		final TableViewer viewer = new TableViewer(shell, SWT.VIRTUAL | SWT.FULL_SELECTION);
		viewer.setLabelProvider(new MyTableLabelProvider());
		viewer.setContentProvider(new MyLazyContentProvider(viewer));
		
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		
		viewer.setUseHashlookup(true);
		viewer.setInput(myPersonList);
		viewer.setItemCount(myPersonList.size());
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    new TableColumn(table, SWT.CENTER).setText("Nom");   
	    new TableColumn(table, SWT.CENTER).setText("Prénom");
	    new TableColumn(table, SWT.CENTER).setText("Sport");
	    new TableColumn(table, SWT.CENTER).setText("Age");
	    new TableColumn(table, SWT.CENTER).setText("Végétarien");
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	public static void main(String[] argv) {
		new LazyContentProviderExample();
	}
	
	static class MyLazyContentProvider implements ILazyContentProvider {
		private AbstractTableViewer ref;
		
		private ArrayList<Person> myPersonList;
		
		public MyLazyContentProvider(AbstractTableViewer pRef) {
			ref = pRef;
		}
		
		public void updateElement(int index) {
			System.out.println("MyLazyContentProvider.updateElement()" + " " + index);
			ref.replace(myPersonList.get(index), index);
		}

		public void dispose() {
			
		}

		@SuppressWarnings("unchecked")
		public void inputChanged(Viewer view, Object oldInput, Object newInput) {
			this.myPersonList = (ArrayList<Person>)newInput;
		}		
	}
	
	static class MyTableLabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			Person currentPerson = (Person)element;
			switch(columnIndex) {
			case 0 : return currentPerson.getName();
			case 1 : return currentPerson.getFirstName();
			case 2 : return currentPerson.getSportName();
			case 3 : return Integer.toString(currentPerson.getOld());
			case 4 : return Boolean.toString(currentPerson.isVegetarian());
			default : return "";
			}
		}

		public void addListener(ILabelProviderListener listener) {
		}

		public void dispose() {
		}

		public boolean isLabelProperty(Object element, String property) {
			return false;
		}

		public void removeListener(ILabelProviderListener listener) {
		}
	}
}
