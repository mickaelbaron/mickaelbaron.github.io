package eclipse.jface.TableViewerExamples;

import java.util.ArrayList;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.OwnerDrawLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.graphics.TextLayout;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class OwnerDrawLabelExample {

	public static void main(String[] argv) {		
		new OwnerDrawLabelExample();
	}
	
	public OwnerDrawLabelExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer utilisant OwnerDrawLabelProvider");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		viewer.setContentProvider(new MyStructuredContentProvider());		

		TableViewerColumn column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new OwnerDrawLabelProvider() {
			
			protected void erase(Event event, Object element) {
				if ((event.detail & SWT.SELECTED) == 0) return;
		
				Display display = viewer.getTable().getDisplay();
				final Color red = display.getSystemColor(SWT.COLOR_RED);
				final Color yellow = display.getSystemColor(SWT.COLOR_YELLOW);
				
				GC gc = event.gc;
				Color oldForeground = gc.getForeground();
				Color oldBackground = gc.getBackground();
				
				gc.setForeground(red);
				gc.setBackground(yellow);
				gc.fillGradientRectangle(0, event.y, 100, 10, false);
				gc.setForeground(oldForeground);
				gc.setBackground(oldBackground);
				
				event.detail &= ~SWT.SELECTED;
			}
			
			protected void measure(Event event, Object element) {
				Person currentPerson = (Person)element;
				int height = event.gc.textExtent(currentPerson.getName()).y + 5;
				int width = event.gc.textExtent(currentPerson.getName()).x;
				event.setBounds(new Rectangle(0,0, width, height));
			}

			protected void paint(Event event, Object element) {
				Person currentPerson = (Person)element;
				
				Display display = viewer.getControl().getDisplay();
				TextLayout layout = new TextLayout(display);
				layout.setText(currentPerson.getName());

				TextStyle plain = new TextStyle(JFaceResources
						.getFont(JFaceResources.DEFAULT_FONT), display
						.getSystemColor(SWT.COLOR_LIST_FOREGROUND), null);
				
				TextStyle italic = new TextStyle(JFaceResources.getFontRegistry()
						.getItalic(JFaceResources.DEFAULT_FONT), display
						.getSystemColor(SWT.COLOR_BLUE), null);

				Font newFont = new Font(display, "Arial", 9, SWT.BOLD);
				TextStyle font = new TextStyle(newFont, display
						.getSystemColor(SWT.COLOR_WHITE), display
						.getSystemColor(SWT.COLOR_BLACK));
				
				layout.setStyle(plain, 0, 2);
				layout.setStyle(italic, 3, 5);
				layout.setStyle(font, 6, currentPerson.getName().length() - 1);
				layout.draw(event.gc, event.x, event.y);
			}			
		});
		column.getColumn().setText("Nom");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getFirstName();
			}
			
		});
		column.getColumn().setText("Prénom");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getSportName();
			}
			
		});
		column.getColumn().setText("Sport");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return Integer.toString(currentPerson.getOld());
			}
			
		});
		column.getColumn().setText("Age");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public int getToolTipDisplayDelayTime(Object object) {
				return 500;
			}

			public int getToolTipTimeDisplayed(Object object) {
				return 5000;
			}

			public Color getToolTipBackgroundColor(Object object) {
				return Display.getCurrent().getSystemColor(SWT.COLOR_BLACK);
			}

			public String getToolTipText(Object element) {
				return "Ceci est un exemple de bulle d'aide";
			}

			public boolean useNativeToolTip(Object object) {
				return false;
			}

			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return Boolean.toString(currentPerson.isVegetarian());
			}
			
		});
		column.getColumn().setText("Végétarien");
				
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		
		viewer.setInput(myPersonList);
		OwnerDrawLabelProvider.setUpOwnerDraw(viewer);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<Person> localInputElement = (ArrayList<Person>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
}
