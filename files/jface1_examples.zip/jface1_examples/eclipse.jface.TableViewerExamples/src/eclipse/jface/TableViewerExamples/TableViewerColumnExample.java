package eclipse.jface.TableViewerExamples;
import java.util.ArrayList;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerToolTipSupport;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.window.ToolTip;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TableViewerColumnExample {

	public static void main(String[] argv) {		
		new TableViewerColumnExample();
	}
	
	public TableViewerColumnExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("Simple Table Viewer");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		viewer.setContentProvider(new MyStructuredContentProvider());		

		TableViewerColumn column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public Color getBackground(Object element) {
				return Display.getDefault().getSystemColor(SWT.COLOR_GREEN);
			}

			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getName();
			}
			
		});
		column.getColumn().setText("Nom");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getFirstName();
			}
			
		});
		column.getColumn().setText("Prénom");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getSportName();
			}
			
		});
		column.getColumn().setText("Sport");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return Integer.toString(currentPerson.getOld());
			}
			
		});
		column.getColumn().setText("Age");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public int getToolTipDisplayDelayTime(Object object) {
				return 500;
			}

			public int getToolTipTimeDisplayed(Object object) {
				return 5000;
			}

			public String getToolTipText(Object element) {
				return "Ceci est un exemple de bulle d'aide";
			}

			public boolean useNativeToolTip(Object object) {
				return false;
			}

			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return Boolean.toString(currentPerson.isVegetarian());
			}
			
		});
		column.getColumn().setText("Végétarien");
		ColumnViewerToolTipSupport.enableFor(viewer,ToolTip.NO_RECREATE);		
		
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		
		viewer.setInput(myPersonList);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<Person> localInputElement = (ArrayList<Person>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
}
