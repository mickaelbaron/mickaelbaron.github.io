package eclipse.jface.TableViewerExamples;
import java.util.ArrayList;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerToolTipSupport;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.window.ToolTip;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TableViewerColumnTinyExample {

	public static void main(String[] argv) {		
		new TableViewerColumnTinyExample();
	}
	
	public TableViewerColumnTinyExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("Simple Table Viewer");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		viewer.setContentProvider(new MyStructuredContentProvider());		

		TableViewerColumn column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public Color getBackground(Object element) {
				return Display.getDefault().getSystemColor(SWT.COLOR_GREEN);
			}

			public String getText(Object element) {
				PersonData currentPerson = (PersonData)element;
				return currentPerson.getName();
			}
			
		});
		column.getColumn().setText("Nom");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				PersonData currentPerson = (PersonData)element;
				return currentPerson.getFirstName();
			}
			
			public int getToolTipDisplayDelayTime(Object object) {
				return 500;
			}

			public int getToolTipTimeDisplayed(Object object) {
				return 5000;
			}

			public String getToolTipText(Object element) {
				return "Ceci est un exemple de bulle d'aide";
			}

			public boolean useNativeToolTip(Object object) {
				return false;
			}
			
		});
		column.getColumn().setText("Prénom");
		ColumnViewerToolTipSupport.enableFor(viewer,ToolTip.NO_RECREATE);
				
		ArrayList<PersonData> myPersonList = new ArrayList<PersonData>();
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));
		
		viewer.setInput(myPersonList);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<PersonData> localInputElement = (ArrayList<PersonData>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
	
	static class PersonData {
		private String name;
		
		private String firstName;
		
		public PersonData(String pName, String pFirstName) {
			super();
			this.name = pName;
			this.firstName = pFirstName;
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getFirstName() {
			return firstName;
		}
		
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
	}
}
