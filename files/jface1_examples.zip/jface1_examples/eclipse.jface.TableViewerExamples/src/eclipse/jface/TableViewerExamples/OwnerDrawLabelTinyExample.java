package eclipse.jface.TableViewerExamples;

import java.util.ArrayList;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.OwnerDrawLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.graphics.TextLayout;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class OwnerDrawLabelTinyExample {

	public static void main(String[] argv) {		
		new OwnerDrawLabelTinyExample();
	}
	
	public OwnerDrawLabelTinyExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer utilisant OwnerDrawLabelProvider");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		viewer.setContentProvider(new MyStructuredContentProvider());		

		TableViewerColumn column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new OwnerDrawLabelProvider() {
			
			protected void measure(Event event, Object element) {
				PersonData currentPerson = (PersonData)element;
				int height = event.gc.textExtent(currentPerson.getName()).y + 5;
				int width = event.gc.textExtent(currentPerson.getName()).x;
				event.setBounds(new Rectangle(0,0, width, height));
			}

			protected void paint(Event event, Object element) {
				PersonData currentPerson = (PersonData)element;
				
				Display display = viewer.getControl().getDisplay();
				TextLayout layout = new TextLayout(display);
				layout.setText(currentPerson.getName());

				TextStyle plain = new TextStyle(JFaceResources
						.getFont(JFaceResources.DEFAULT_FONT), display
						.getSystemColor(SWT.COLOR_LIST_FOREGROUND), null);
				
				TextStyle italic = new TextStyle(JFaceResources.getFontRegistry()
						.getItalic(JFaceResources.DEFAULT_FONT), display
						.getSystemColor(SWT.COLOR_BLUE), null);

				Font newFont = new Font(display, "Arial", 9, SWT.BOLD);
				TextStyle font = new TextStyle(newFont, display
						.getSystemColor(SWT.COLOR_GREEN), null);
				
				layout.setStyle(plain, 0, 2);
				layout.setStyle(italic, 3, 5);
				layout.setStyle(font, 6, currentPerson.getName().length() - 1);
				layout.setOrientation(SWT.RIGHT_TO_LEFT);

				layout.draw(event.gc, event.x, event.y);
			}			
		});
		column.getColumn().setText("Nom");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				PersonData currentPerson = (PersonData)element;
				return currentPerson.getFirstName();
			}
			
		});
		column.getColumn().setText("Prénom");		
				
		ArrayList<PersonData> myPersonList = new ArrayList<PersonData>();
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));
		
		viewer.setInput(myPersonList);
		OwnerDrawLabelProvider.setUpOwnerDraw(viewer);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<Person> localInputElement = (ArrayList<Person>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
	
	static class PersonData {
		private String name;
		
		private String firstName;
		
		public PersonData(String pName, String pFirstName) {
			super();
			this.name = pName;
			this.firstName = pFirstName;
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getFirstName() {
			return firstName;
		}
		
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
	}
}
