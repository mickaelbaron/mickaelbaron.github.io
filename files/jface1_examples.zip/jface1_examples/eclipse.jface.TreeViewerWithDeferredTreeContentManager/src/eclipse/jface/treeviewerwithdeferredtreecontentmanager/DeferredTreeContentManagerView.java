package eclipse.jface.treeviewerwithdeferredtreecontentmanager;

import java.util.ArrayList;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.ui.progress.DeferredTreeContentManager;
import org.eclipse.ui.progress.IDeferredWorkbenchAdapter;
import org.eclipse.ui.progress.IElementCollector;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Note : this example is based on this one "http://www.ji.co.za/unplugged/index.php?paged=4"
 * 
 * Date : october 2007
 */
public class DeferredTreeContentManagerView extends ViewPart {
	public static final String ID = "eclipse.jface.TreeViewerWithDeferredTreeContentManager.view";

	private TreeParent invisibleRoot;

	private TreeViewer viewer;

	public void createPartControl(Composite parent) {
		viewer = new TreeViewer(parent, SWT.VIRTUAL | SWT.MULTI | SWT.H_SCROLL
				| SWT.V_SCROLL);
		viewer.setContentProvider(new MyTreeContentProvider());
		viewer.setLabelProvider(new MyTreeLabelProvider());

		TreeParent root = new TreeParent("Root");
		invisibleRoot = new TreeParent("");
		invisibleRoot.addChild(root);

		viewer.setInput(invisibleRoot);
	}

	static class MyTreeLabelProvider extends LabelProvider {
		public String getText(Object element) {
			if (!(element instanceof TreeObject)) {
				return "Loading...";
			} else {
				return element.toString();
			}
		}
	}

	static class MyTreeContentProvider implements ITreeContentProvider {

		private DeferredTreeContentManager manager;

		@SuppressWarnings("unchecked")
		public Object[] getElements(Object element) {
			TreeParent myParent = (TreeParent) element;
			return myParent.getChildren(element);
		}

		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
			if (viewer instanceof AbstractTreeViewer) {
				manager = new DeferredTreeContentManager(this,
						(AbstractTreeViewer) viewer);
			}
		}

		public Object[] getChildren(Object parentElement) {
			return manager.getChildren(parentElement);
		}

		public Object getParent(Object element) {
			if (element instanceof TreeObject) {
				return ((TreeObject) element).getParent();
			}
			return null;
		}

		public boolean hasChildren(Object element) {
			return manager.mayHaveChildren(element);
		}
	}

	private static class TreeObject {
		private String name;

		private TreeObject parent;

		public TreeObject(String pName) {
			this.name = pName;
		}

		public void setParent(TreeObject pParent) {
			this.parent = pParent;
		}

		public TreeObject getParent() {
			return parent;
		}

		public String toString() {
			return name;
		}
	}

	private static class TreeParent extends TreeObject implements
			IDeferredWorkbenchAdapter {
		private static final int leafLength = 10;
		private ArrayList<TreeObject> children;

		public TreeParent(String name) {
			super(name);
			children = new ArrayList<TreeObject>();
		}

		public void addChild(TreeObject child) {
			children.add(child);
			child.setParent(this);
		}

		public void removeChild(TreeObject child) {
			children.remove(child);
			child.setParent(null);
		}

		public Object[] getChildren(Object o) {
			return children.toArray();
		}

		public void fetchDeferredChildren(Object object,
				IElementCollector collector, IProgressMonitor monitor) {
			collector.add(new TreeParent("Parent"), monitor);
			for (int i = 0; i < leafLength; i++) {
				collector.add(new TreeObject("Leaf " + i), monitor);
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		public boolean hasChildren() {
			return children.size() > 0;
		}

		public boolean isContainer() {
			return (this instanceof TreeParent);
		}

		public ISchedulingRule getRule(Object object) {
			return null;
		}

		public ImageDescriptor getImageDescriptor(Object object) {
			return null;
		}

		public String getLabel(Object element) {
			return null;
		}

		public Object getParent(Object element) {
			return null;
		}
	}

	public void setFocus() {
		viewer.getControl().setFocus();
	}
}