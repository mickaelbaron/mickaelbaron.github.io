package eclipse.jface.TreeExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TreeColumnSelectionExample {
	public TreeColumnSelectionExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Exemple de la Tree SWT avec sélection");
		shell.setLayout(new FillLayout());
		Tree myTree = new Tree(shell, SWT.FULL_SELECTION);
		
		TreeColumn column = new TreeColumn(myTree, SWT.NONE);
		column.setText("Colonne 1");
		column.setResizable(true);
		column.setMoveable(true);
		column.setWidth(100);
		
		column = new TreeColumn(myTree, SWT.NONE);
		column.setText("Colonne 2");
		column.setResizable(true);
		column.setWidth(100);
		
		column = new TreeColumn(myTree, SWT.NONE);
		column.setText("Colonne 3");
		column.setResizable(true);
		column.setWidth(100);
				
		final int ROW = 7;
		for (int i = 0; i < ROW; i++) {
			TreeItem current = new TreeItem(myTree, SWT.NONE);
			current.setText("Noeud " + i);
			
			final int SUB_ROW = 3;
			for (int j = 0; j < SUB_ROW; j++) {
				TreeItem subCurrent = new TreeItem(current, SWT.NONE);
				subCurrent.setText("Sous Noeud " + j);
				subCurrent.setText(1, "Valeur 1 " + j);
				subCurrent.setText(2, "Valeur 2 " + j);
			}
		}
		
		myTree.setHeaderVisible(true);
		myTree.setLinesVisible(true);
		myTree.setTopItem(myTree.getItem(5));
		myTree.setSelection(myTree.getItem(5));
		myTree.getItem(5).setExpanded(true);
		
		shell.setSize(350, 300);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] argv) {
		new TreeColumnSelectionExample();
	}
}
