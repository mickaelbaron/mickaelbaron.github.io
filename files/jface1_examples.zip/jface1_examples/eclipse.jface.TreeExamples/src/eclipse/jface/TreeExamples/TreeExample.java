package eclipse.jface.TreeExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TreeExample {
	public TreeExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Exemple de la Tree SWT");
		shell.setLayout(new FillLayout());
		Tree myTree = new Tree(shell, SWT.FULL_SELECTION);
		
		final int ROW = 4;
		for (int i = 0; i < ROW; i++) {
			TreeItem current = new TreeItem(myTree, SWT.NONE);
			current.setText("Noeud " + i);
			
			final int SUB_ROW = 3;
			for (int j = 0; j < SUB_ROW; j++) {
				TreeItem subCurrent = new TreeItem(current, SWT.NONE);
				subCurrent.setText("Sous Noeud " + j);
			}
		}
		shell.setSize(350, 300);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] argv) {
		new TreeExample();
	}
}
