package eclipse.jface.TableExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2007
 */
public class TableColomnExample {
	public TableColomnExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Exemple de la Table SWT");
		shell.setLayout(new FillLayout());
		Table table = new Table(shell, SWT.NONE);
		table.setHeaderVisible(true);

		for (int i = 0; i < 3; i++) {
			TableColumn column = new TableColumn(table, SWT.NONE);
			column.setWidth(100);
			column.setText("Colonnne " + i);
			column.setMoveable(true);
			column.setResizable(true);
		}

		shell.setSize(350, 300);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new TableColomnExample();
	}
}
