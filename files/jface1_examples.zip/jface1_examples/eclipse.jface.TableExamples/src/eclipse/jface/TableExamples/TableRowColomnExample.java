package eclipse.jface.TableExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2007
 */
public class TableRowColomnExample {
	public TableRowColomnExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Exemple de la Table SWT avec des cellules");
		shell.setLayout(new FillLayout());
		Table table = new Table(shell, SWT.NONE);
		table.setHeaderVisible(true);

		for (int i = 0; i < 3; i++) {
			TableColumn column = new TableColumn(table, SWT.NONE);
			column.setWidth(100);
			column.setText("Colonnne " + i);
			column.setMoveable(true);
			column.setResizable(true);
		}

		for (int i = 0; i < 50; i++) {
			new TableItem(table, SWT.NONE);
		}

		TableItem[] items = table.getItems();
		for (int i = 0; i < items.length; i++) {
			int backgroundColor = (i % 2 == 0 ? SWT.COLOR_CYAN : SWT.COLOR_RED);
			items[i].setBackground(Display.getDefault().getSystemColor(
					backgroundColor));
			for (int j = 0; j < 3; j++) {
				items[i].setText(j, "cellule " + j + ":" + i);
			}
		}

		shell.setSize(350, 300);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new TableRowColomnExample();
	}
}
