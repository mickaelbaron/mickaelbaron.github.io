	package eclipse.jface.FilterExamples;
import java.util.ArrayList;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TableViewerFilterExample {
	
	private boolean isFiltred = false;
	
	public TableViewerFilterExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer : Utilisation d'un filtre");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		Button myButton = new Button(shell, SWT.CHECK);
		myButton.setText("Filtrer les végétariens");
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				isFiltred = !isFiltred;
				viewer.refresh();
			}			
		});
		
		viewer.setUseHashlookup(true);
		viewer.setContentProvider(new MyStructuredContentProvider());		
		viewer.setLabelProvider(new MyTableLabelProvider());
		
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont", 22, false));
		myPersonList.add(new Person("Motte", 15, false));
		myPersonList.add(new Person("Pratdut", 25, true));
		myPersonList.add(new Person("Giphone", 35, false));
		myPersonList.add(new Person("Garphine", 50, false));
		myPersonList.add(new Person("Sume", 31, false));
		myPersonList.add(new Person("Chedantrou", 36, false));
		myPersonList.add(new Person("Factions", 15, false));
		myPersonList.add(new Person("Pouillou", 26, false));
		
		viewer.setInput(myPersonList);
		ViewerFilter current = new ViewerFilter() {
			public boolean select(Viewer viewer, Object parentElement, Object element) {
				if (isFiltred) {
					return ((Person)element).isVegetarian();
				} else {
					return true;
				}
			}			
		};
		
		ViewerFilter[] viewerFilterTab = new ViewerFilter[1];
		viewerFilterTab[0] = current;
		viewer.setFilters(viewerFilterTab);		
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    new TableColumn(table, SWT.CENTER).setText("Nom");   
	    new TableColumn(table, SWT.CENTER).setText("Age");
	    new TableColumn(table, SWT.CENTER).setText("Végétarien");
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	    }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}

	public static void main(String[] argv) {		
		new TableViewerFilterExample();
	}
}
