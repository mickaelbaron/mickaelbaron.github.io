package eclipse.jface.FilterExamples;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class Person {
	private String name;
	
	private int old;
	
	private boolean vegetarian;

	public Person(String name, int pOld, boolean vegetarian) {
		super();
		this.name = name;
		this.old = pOld;
		this.vegetarian = vegetarian;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getOld() {
		return old;
	}

	public void setOld(int pOld) {
		this.old = pOld;
	}

	public boolean isVegetarian() {
		return vegetarian;
	}

	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}
}
