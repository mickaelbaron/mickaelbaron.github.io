package eclipse.jface.TreeViewerExamples;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class Job {
	
	private List<Person> myPerson;

	private String job;

	public Job(String pMetier) {
		this.job = pMetier;
		myPerson = new ArrayList<Person>();
	}

	public void addPerson(Person pPerson) {
		myPerson.add(pPerson);
		pPerson.setParent(this);
	}

	public String getJob() {
		return job;
	}

	public List<Person> getPersons() {
		return myPerson;
	}
	
	public String toString() {
		return job;
	}

	public boolean isPersonEmpty() {
		return myPerson.isEmpty();
	}
}
