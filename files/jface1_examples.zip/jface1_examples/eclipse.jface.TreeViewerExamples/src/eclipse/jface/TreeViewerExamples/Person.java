package eclipse.jface.TreeViewerExamples;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class Person {
	private String name;

	private String address;
	
	private String old;
	
	private String vehicule;
	
	private String salary;

	private Job parent;

	public Person(String pName, String pAddress, String pOld,
			String pVehicule, String pSalary) {
		this.name = pName;
		this.address = pAddress;
		this.old = pOld;
		this.vehicule = pVehicule;
		this.salary = pSalary;
	}

	public Job getParent() {
		return parent;
	}
	
	public void setParent(Job pWork) {
		this.parent = pWork;
	}

	public String getName() {
		return this.name;
	}

	public String getAdress() {
		return address;
	}

	public String getOld() {
		return old;
	}

	public String getVehicule() {
		return vehicule;
	}

	public String getSalary() {
		return salary;
	}
}
