package eclipse.jface.TreeViewerExamples;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TreeViewerColumnTinyExample {

	private List<Job> myPersonWork;

	public TreeViewerColumnTinyExample() {
		Display display = new Display();

		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TreeViewer avec colonnes");
		final TreeViewer viewer = new TreeViewer(shell, SWT.FULL_SELECTION);
		viewer.setContentProvider(new MyTreeContentProvider());
		
		TreeViewerColumn column = new TreeViewerColumn(viewer, SWT.CENTER);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				if (element instanceof Person) {
					Person current = (Person)element;
					return current.getName();
				} else {
					return element.toString();					
				}
			}
		});
		column.getColumn().setText("Métier / Nom");
		
		column = new TreeViewerColumn(viewer, SWT.CENTER);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				if (element instanceof Person) {
					Person current = (Person)element;
					return current.getAdress();
				} else {
					return null;
				}
			}
		});
		column.getColumn().setText("Adresse");

		column = new TreeViewerColumn(viewer, SWT.CENTER);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				if (element instanceof Person) {
					Person current = (Person)element;
					return current.getOld();
				} else {
					return null;
				}
			}
		});
		column.getColumn().setText("Old");

		column = new TreeViewerColumn(viewer, SWT.CENTER);
		column.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				if (element instanceof Person) {
					Person current = (Person)element;
					return current.getVehicule();
				} else {
					return null;
				}
			}
		});
		column.getColumn().setText("Véhicule");

		myPersonWork = new ArrayList<Job>();

		Job currentWork = new Job("Informaticien");
		currentWork.addPerson(new Person("Robert Glan", "Nancy", "25", "Voiture", "1600"));
		currentWork.addPerson(new Person("John Rambo", "Limoges", "35", "Train", "1900"));
		currentWork.addPerson(new Person("Antoine Ronba", "Niort", "40", "Avion", "5000"));
		myPersonWork.add(currentWork);
		
		currentWork = new Job("Medecin");
		currentWork.addPerson(new Person("Jean Dupont", "Tours", "39", "Train", "1200"));
		currentWork.addPerson(new Person("Guy Fregatte", "La Rochelle", "35", "Bateau", "2000"));
		currentWork.addPerson(new Person("Olivier Huile", "Nantes", "45", "Avion", "12000"));
		currentWork.addPerson(new Person("Tony Presson", "Paris", "43", "Cheval", "2000"));
		currentWork.addPerson(new Person("Jean Mange", "Paris", "29", "Voiture", "9000"));
		myPersonWork.add(currentWork);
		
		Tree tree = viewer.getTree();
		tree.setLayoutData(new GridData(GridData.FILL_BOTH));
		viewer.setInput(myPersonWork);

		for (int i = 0, n = tree.getColumnCount(); i < n; i++) {
			tree.getColumn(i).setWidth(100);
		}

		tree.setHeaderVisible(true);
		tree.setLinesVisible(true);
		viewer.expandAll();

		
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}

	static class MyTreeContentProvider implements ITreeContentProvider {

		@SuppressWarnings("unchecked")
		public Object[] getElements(Object element) {
			final Object[] currentPersonWorks = ((List<Job>) element)
					.toArray();
			return currentPersonWorks;
		}

		public void dispose() {
		}

		public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		}

		public Object[] getChildren(Object element) {
			final Job currentPersonWork = (Job) element;
			return currentPersonWork.getPersons().toArray();
		}

		public Object getParent(Object element) {
			if (element instanceof Person) {
				return ((Person)element).getParent();
			} else {
				return null;
			}
		}

		public boolean hasChildren(Object element) {
			if (element instanceof Job) {
				Job current = (Job) element;
				return !current.isPersonEmpty();
			} else {
				return false;
			}
		}
	}

	private static class Job {
		private List<Person> myPerson;

		private String job;

		public Job(String pMetier) {
			this.job = pMetier;
			myPerson = new ArrayList<Person>();
		}

		public void addPerson(Person pPerson) {
			myPerson.add(pPerson);
			pPerson.setParent(this);
		}

		public String getMetier() {
			return job;
		}

		public List<Person> getPersons() {
			return myPerson;
		}

		public String toString() {
			return job;
		}

		public boolean isPersonEmpty() {
			return myPerson.isEmpty();
		}
	}

	private static class Person {
		private String name;
	
		private String adress;
		
		private String old;
		
		private String vehicule;
		
		private String salary;

		private Job parent;

		public Person(String pName, String pAdress, String pOld,
				String pVehicule, String pSalary) {
			this.name = pName;
			this.adress = pAdress;
			this.old = pOld;
			this.vehicule = pVehicule;
			this.salary = pSalary;
		}

		public Job getParent() {
			return parent;
		}
		
		public void setParent(Job pWork) {
			this.parent = pWork;
		}

		public String getName() {
			return this.name;
		}

		public String getAdress() {
			return adress;
		}

		public String getOld() {
			return old;
		}

		public String getVehicule() {
			return vehicule;
		}

		public String getSalary() {
			return salary;
		}
	}

	public static void main(String[] argv) {
		new TreeViewerColumnTinyExample();
	}
}
