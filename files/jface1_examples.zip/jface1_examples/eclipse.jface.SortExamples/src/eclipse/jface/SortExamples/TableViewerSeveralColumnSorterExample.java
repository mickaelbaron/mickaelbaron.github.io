package eclipse.jface.SortExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TableViewerSeveralColumnSorterExample {
	
	public TableViewerSeveralColumnSorterExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer : Utilisation d'un tri sur plusieurs colonnes cliquables");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		viewer.setUseHashlookup(true);
		viewer.setContentProvider(new MyStructuredContentProvider());		
		
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont", "Jean", 17));
		myPersonList.add(new Person("Motte", "Henry", 59));
		myPersonList.add(new Person("Pratdut", "John", 76));
		myPersonList.add(new Person("Giphone", "Pierre", 25));
		myPersonList.add(new Person("Garphine", "Maurice", 50));
		myPersonList.add(new Person("Bannal", "Tony", 99));
		myPersonList.add(new Person("Devil", "Defer", 30));
		
		viewer.setInput(myPersonList);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    TableViewerColumn refNameColumn = new TableViewerColumn(viewer, SWT.NONE);
	    refNameColumn.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getName();
			}	    	
	    });
	    refNameColumn.getColumn().setText("Nom");
	    ColumnSorter refCS = new ColumnSorter(viewer, refNameColumn) {
	    	public int columnCompare(Viewer viewer, Object e1, Object e2) {
	    		Person p1 = (Person) e1;
				Person p2 = (Person) e2;
				return p1.getName().compareToIgnoreCase(p2.getName());
	    	}
	    };
	    
	    TableViewerColumn refFirstNameColumn = new TableViewerColumn(viewer, SWT.NONE);
	    refFirstNameColumn.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getFirstName();
			}	    	
	    });
	    refFirstNameColumn.getColumn().setText("Prénom");
	    new ColumnSorter(viewer, refFirstNameColumn) {
	    	public int columnCompare(Viewer viewer, Object e1, Object e2) {
	    		Person p1 = (Person) e1;
				Person p2 = (Person) e2;
				return p1.getFirstName().compareToIgnoreCase(p2.getFirstName());	    		
	    	}
	    };
	    
	    TableViewerColumn refOldColumn = new TableViewerColumn(viewer, SWT.NONE);
	    refOldColumn.setLabelProvider(new ColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return Integer.toString(currentPerson.getOld());
			}	    	
	    });
	    refOldColumn.getColumn().setText("Age");
	    new ColumnSorter(viewer, refOldColumn) {
	    	public int columnCompare(Viewer viewer, Object e1, Object e2) {
	    		Person p1 = (Person) e1;
				Person p2 = (Person) e2;
				return new Integer(p1.getOld()).compareTo(new Integer(p2.getOld()));
	    	}
	    };
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	    }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    
	    refCS.setSorter(refCS, ColumnSorter.ASC);
	    viewer.refresh();
	    
	    
		shell.open();

		
		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}

	@SuppressWarnings("unused")
	
	public static void main(String[] argv) {		
		new TableViewerSeveralColumnSorterExample();
	}
}
