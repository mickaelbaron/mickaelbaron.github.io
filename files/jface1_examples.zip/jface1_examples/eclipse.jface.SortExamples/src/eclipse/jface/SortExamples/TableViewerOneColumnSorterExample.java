package eclipse.jface.SortExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TableViewerOneColumnSorterExample {
	
	private boolean isSorted = false;
	
	public TableViewerOneColumnSorterExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer : Utilisation d'un tri sur une colonne");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		Button myButton = new Button(shell, SWT.CHECK);
		myButton.setText("Trier les noms");
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Table myTable = viewer.getTable();
				isSorted = !isSorted;
				if (isSorted) {
					viewer.setComparator(new MyViewerComparer());
					myTable.setSortColumn(myTable.getColumn(0));
					myTable.setSortDirection(SWT.UP);
				} else {
					viewer.setComparator(null);
					myTable.setSortColumn(null);
					myTable.setSortDirection(SWT.NONE);
				}
				viewer.refresh();
			}			
		});
		
		viewer.setUseHashlookup(true);
		viewer.setContentProvider(new MyStructuredContentProvider());		
		viewer.setLabelProvider(new MyTableLabelProvider());
		
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont", "Jean", 17));
		myPersonList.add(new Person("Motte", "Henry", 59));
		myPersonList.add(new Person("Pratdut", "John", 76));
		myPersonList.add(new Person("Giphone", "Pierre", 25));
		myPersonList.add(new Person("Garphine", "Maurice", 50));
		myPersonList.add(new Person("Bannal", "Tony", 99));
		myPersonList.add(new Person("Devil", "Defer", 30));
		
		viewer.setInput(myPersonList);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    new TableColumn(table, SWT.CENTER).setText("Nom");   
	    new TableColumn(table, SWT.CENTER).setText("Prénom");
	    new TableColumn(table, SWT.CENTER).setText("Age");
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	    }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}

	@SuppressWarnings("unused")
	private static class MyViewerComparer extends ViewerComparator {

		public int compare(Viewer viewer, Object e1, Object e2) {
			Person p1 = (Person) e1;
			Person p2 = (Person) e2;
			return p1.getName().compareToIgnoreCase(p2.getName());
		}
	}
	
	public static void main(String[] argv) {		
		new TableViewerOneColumnSorterExample();
	}
}
