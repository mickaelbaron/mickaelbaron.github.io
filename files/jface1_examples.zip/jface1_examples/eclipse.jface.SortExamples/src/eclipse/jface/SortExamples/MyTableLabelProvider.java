package eclipse.jface.SortExamples;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class MyTableLabelProvider implements ITableLabelProvider {
	public Image getColumnImage(Object element, int columnIndex) {
		return null;
	}

	public String getColumnText(Object element, int columnIndex) {
		Person currentPerson = (Person)element;
		switch(columnIndex) {
		case 0 : return currentPerson.getName();
		case 1 : return currentPerson.getFirstName();
		case 2 : return Integer.toString(currentPerson.getOld());
		default : return "";
		}
	}

	public void addListener(ILabelProviderListener listener) {
	}

	public void dispose() {
	}

	public boolean isLabelProperty(Object element, String property) {
		return false;
	}

	public void removeListener(ILabelProviderListener listener) {
	}
}
