package eclipse.jface.SortExamples;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class Person {
	private String name;
	
	private int old;
	
	private String firstName;
	
	public Person(String pName, String pFirstName, int pOld) {
		super();
		this.name = pName;
		this.old = pOld;
		this.firstName = pFirstName;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getOld() {
		return old;
	}

	public void setOld(int pOld) {
		this.old = pOld;
	}

	public String getFirstName() {
		return this.firstName;
	}
	
	public void setFirstName(String pFirstName) {
		this.firstName = pFirstName;
	}
	
	public String toString() {
		return name;
	}
}
