package eclipse.jface.SortExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.Viewer;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class MyStructuredContentProvider implements IStructuredContentProvider {
	@SuppressWarnings("unchecked")
	public Object[] getElements(Object inputElement) {
		ArrayList<Person> localInputElement = (ArrayList<Person>)inputElement;				
		return localInputElement.toArray();
	}
	
	public void dispose() {
	}

	public void inputChanged(Viewer viewer, Object oldInput,
			Object newInput) {
	}	
}
