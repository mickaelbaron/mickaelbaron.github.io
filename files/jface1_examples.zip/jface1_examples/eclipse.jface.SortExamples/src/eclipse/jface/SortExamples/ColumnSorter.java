package eclipse.jface.SortExamples;

import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public abstract class ColumnSorter extends ViewerComparator {
	private ColumnViewer refViewer;

	private TableViewerColumn column;

	public static final int ASC = 1;

	public static final int NONE = 0;

	public static final int DESC = -1;

	private int direction = 0;

	public ColumnSorter(ColumnViewer pViewer, TableViewerColumn pColumn) {
		this.refViewer = pViewer;
		this.column = pColumn;

		this.column.getColumn().addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				if (ColumnSorter.this.refViewer.getComparator() != null) {
					if (ColumnSorter.this.refViewer.getComparator() == ColumnSorter.this) {
						int tdirection = ColumnSorter.this.direction;

						if (tdirection == ASC) {
							setSorter(ColumnSorter.this, DESC);
						} else if (tdirection == DESC) {
							setSorter(ColumnSorter.this, NONE);
						}
					} else {
						setSorter(ColumnSorter.this, ASC);
					}
				} else {
					setSorter(ColumnSorter.this, ASC);
				}
			}
		});
	}

	public void setSorter(ColumnSorter sorter, int direction) {
		if (direction == NONE) {
			column.getColumn().getParent().setSortColumn(null);
			column.getColumn().getParent().setSortDirection(SWT.NONE);
			refViewer.setComparator(null);
		} else {
			column.getColumn().getParent().setSortColumn(column.getColumn());
			sorter.direction = direction;

			if (direction == ASC) {
				column.getColumn().getParent().setSortDirection(SWT.DOWN);
			} else {
				column.getColumn().getParent().setSortDirection(SWT.UP);
			}

			if (refViewer.getComparator() == sorter) {
				refViewer.refresh();
			} else {
				refViewer.setComparator(sorter);
			}

		}
	}

	public int compare(Viewer viewer, Object e1, Object e2) {
		return direction * columnCompare(viewer, e1, e2);
	}

	public abstract int columnCompare(Viewer viewer, Object e1, Object e2);

}
