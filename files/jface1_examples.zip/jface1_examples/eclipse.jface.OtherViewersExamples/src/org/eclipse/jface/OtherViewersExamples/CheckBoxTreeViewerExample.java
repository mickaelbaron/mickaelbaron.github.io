package org.eclipse.jface.OtherViewersExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.BaseLabelProvider;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTreeViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class CheckBoxTreeViewerExample {
	public CheckBoxTreeViewerExample() {
		Display display = new Display();

		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("CheckboxTreeViewer example");
		final CheckboxTreeViewer viewer = new CheckboxTreeViewer(shell, SWT.FULL_SELECTION);
		viewer.setContentProvider(new MyTreeContentProvider());
		viewer.setLabelProvider(new MyTreeLabelProvider());
		
		TreeParent root = new TreeParent("");
		TreeParent treeParent = new TreeParent("Root 1");
		treeParent.addChild(new TreeObject("Leaf 1"));
		treeParent.addChild(new TreeObject("Leaf 2"));
		treeParent.addChild(new TreeObject("Leaf 3"));
		TreeParent subRoot1 = new TreeParent("Sub Root 1");
		subRoot1.addChild(new TreeObject("Sub Leaf 1"));
		subRoot1.addChild(new TreeObject("Sub Leaf 2"));
		subRoot1.addChild(new TreeObject("Sub Leaf 3"));
		treeParent.addChild(subRoot1);
		root.addChild(treeParent);
		viewer.setInput(root);
	
		viewer.addCheckStateListener(new ICheckStateListener() {
			public void checkStateChanged(CheckStateChangedEvent event) {
				if (event.getElement() instanceof TreeParent) {
					viewer.setSubtreeChecked(event.getElement(), viewer.getChecked(event.getElement()));
				}
			}			
		});
		
		Tree tree = viewer.getTree();
		tree.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyTreeLabelProvider extends BaseLabelProvider implements ILabelProvider {

		public Image getImage(Object element) {
			return null;
		}

		public String getText(Object element) {
			return element.toString();					
		}		
	}
	
	static class MyTreeContentProvider implements ITreeContentProvider {

		@SuppressWarnings("unchecked")
		public Object[] getElements(Object element) {
			if (element instanceof TreeParent) {
				return ((TreeParent)element).getChildren();
			}
			return null;
		}

		public void dispose() {
		}

		public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		}

		public Object[] getChildren(Object element) {
			if (element instanceof TreeParent) {
				return ((TreeParent)element).getChildren();
			} else {
				return null;
			}
		}

		public Object getParent(Object element) {
			if (element instanceof TreeObject) {
				return ((TreeObject)element).getParent();
			} else {
				return null;
			}
		}

		public boolean hasChildren(Object element) {
			if (element instanceof TreeParent) {
				return ((TreeParent)element).hasChildren();
			} else {
				return false;
			}
		}
	}
	
	private static class TreeObject {
		private String name;

		private TreeObject parent;

		public TreeObject(String pName) {
			this.name = pName;
		}

		public void setParent(TreeObject pParent) {
			this.parent = pParent;
		}

		public TreeObject getParent() {
			return parent;
		}

		public String toString() {
			return name;
		}
	}

	private static class TreeParent extends TreeObject {
		private ArrayList<TreeObject> children;

		public TreeParent(String name) {
			super(name);
			children = new ArrayList<TreeObject>();
		}

		public void addChild(TreeObject child) {
			children.add(child);
			child.setParent(this);
		}

		public void removeChild(TreeObject child) {
			children.remove(child);
			child.setParent(null);
		}

		public Object[] getChildren() {
			return children.toArray();
		}
		
		public boolean hasChildren() {
			return (children.size() > 0);
		}
	}
	
	public static void main(String[] argv) {
		new CheckBoxTreeViewerExample();
	}
}
