package org.eclipse.jface.OtherViewersExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class CheckBoxTableViewerExample {

	public static void main(String[] argv) {		
		new CheckBoxTableViewerExample();
	}
	
	public CheckBoxTableViewerExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("CheckboxTableViewer example");
		final CheckboxTableViewer viewer = CheckboxTableViewer.newCheckList(shell, SWT.FULL_SELECTION);
		viewer.setUseHashlookup(true);
		viewer.setContentProvider(new MyStructuredContentProvider());		
		viewer.setLabelProvider(new MyTableLabelProvider());
		
		ArrayList<PersonData> myPersonList = new ArrayList<PersonData>();
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));	
		
		viewer.setInput(myPersonList);
		
		viewer.addCheckStateListener(new ICheckStateListener() {
			public void checkStateChanged(CheckStateChangedEvent event) {
				PersonData myPersonData = (PersonData)event.getElement();
				System.out.println(myPersonData.getName());
			}			
		});
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    new TableColumn(table, SWT.CENTER).setText("Nom");   
	    new TableColumn(table, SWT.CENTER).setText("Prénom");
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<PersonData> localInputElement = (ArrayList<PersonData>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
	
	static class PersonData {
		private String name;
		
		private String firstName;
		
		public PersonData(String pName, String pFirstName) {
			super();
			this.name = pName;
			this.firstName = pFirstName;
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getFirstName() {
			return firstName;
		}
		
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
	}
	
	static class MyTableLabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			PersonData currentPerson = (PersonData)element;
			switch(columnIndex) {
			case 0 : return currentPerson.getName();
			case 1 : return currentPerson.getFirstName();
			default : return "";
			}
		}

		public void addListener(ILabelProviderListener listener) {
		}

		public void dispose() {
		}

		public boolean isLabelProperty(Object element, String property) {
			return false;
		}

		public void removeListener(ILabelProviderListener listener) {
		}
	}
}
