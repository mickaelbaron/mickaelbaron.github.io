package org.eclipse.jface.OtherViewersExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerToolTipSupport;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.window.ToolTip;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class ListViewerWithTableViewerExample {
	private java.util.List<Person> myPersonList = new ArrayList<Person>();
	
	public static void main(String[] argv) {		
		new ListViewerWithTableViewerExample();
	}
	
	public ListViewerWithTableViewerExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer as a ListViewer");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		
		viewer.setContentProvider(new MyStructuredContentProvider());		

		TableViewerColumn column = new TableViewerColumn(viewer,SWT.NONE);		
		column.setLabelProvider(new ColumnLabelProvider() {
			public Image getImage(Object element) {
				return super.getImage(element);
			}

			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getName();
			}
			
			public int getToolTipDisplayDelayTime(Object object) {
				return 500;
			}

			public int getToolTipTimeDisplayed(Object object) {
				return 5000;
			}

			public String getToolTipText(Object element) {
				return "Ceci est un exemple de bulle d'aide";
			}

			public boolean useNativeToolTip(Object object) {
				return false;
			}
			
		});
		ColumnViewerToolTipSupport.enableFor(viewer,ToolTip.NO_RECREATE);
				
		myPersonList.add(new Person("David Jean"));
		myPersonList.add(new Person("Tonny Bannal"));
		myPersonList.add(new Person("Eric Proust"));
		myPersonList.add(new Person("Elisabeth Queen"));
		myPersonList.add(new Person("Clara Fox"));
		myPersonList.add(new Person("Samantha Cash"));
		myPersonList.add(new Person("Jean Aimart"));
		myPersonList.add(new Person("Alfred Sawyer"));
		
		viewer.setInput(myPersonList);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(150);
	      }	    
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<Person> localInputElement = (ArrayList<Person>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}

	static class Person {
		private String name;
		
		public Person(String pName) {
			this.name = pName;
		}
		
		public String getName() {
			return name;
		}
	}
}
