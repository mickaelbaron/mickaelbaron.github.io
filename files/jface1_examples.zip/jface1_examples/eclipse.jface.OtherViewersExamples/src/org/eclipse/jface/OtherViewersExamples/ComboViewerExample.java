package org.eclipse.jface.OtherViewersExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.ComboViewer;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class ComboViewerExample {
	private java.util.List<Person> myPerson = new ArrayList<Person>();
	
	public ComboViewerExample() {
		Display display = new Display();

		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("ComboViewer Example");
		
		ComboViewer myComboViewer = new ComboViewer(shell, SWT.NONE);
		myComboViewer.setContentProvider(new MyStructuredContentProvider());
		myComboViewer.setLabelProvider(new MyLabelProvider());
		
		myPerson.add(new Person("David Jean"));
		myPerson.add(new Person("Tonny Bannal"));
		myPerson.add(new Person("Eric Proust"));
		myPerson.add(new Person("Elisabeth Queen"));
		myPerson.add(new Person("Clara Fox"));
		myPerson.add(new Person("Samantha Cash"));
		myPerson.add(new Person("Jean Aimart"));
		myPerson.add(new Person("Alfred Sawyer"));
		
		myComboViewer.setInput(myPerson);
		
		Combo myCombo = myComboViewer.getCombo();
		GridData gridData = new GridData(GridData.FILL_BOTH);
		myCombo.setLayoutData(gridData);
		
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyLabelProvider extends LabelProvider {
		public String getText(Object element) {
			if (element instanceof Person) {
				return ((Person)element).getName();
			} else {
				return "";
			}
		}		
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object element) {
			java.util.List<List> currentElement = (ArrayList)element;
			return currentElement.toArray();
		}

		public void dispose() {
		}

		public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		}		
	}
	
	static class Person {
		private String name;
		
		public Person(String pName) {
			this.name = pName;
		}
		
		public String getName() {
			return name;
		}
	}
	
	public static void main(String[] argv) {
		new ComboViewerExample();
	}
}
