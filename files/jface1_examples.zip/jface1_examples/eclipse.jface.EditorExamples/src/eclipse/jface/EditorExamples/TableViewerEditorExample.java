package eclipse.jface.EditorExamples;
import java.util.ArrayList;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ICellModifier;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TableViewerEditorExample {
	
	public TableViewerEditorExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer : éditeur commun");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);
		viewer.setUseHashlookup(true);
		viewer.setContentProvider(new MyStructuredContentProvider());		
		viewer.setLabelProvider(new MyTableLabelProvider());
		
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont", 22, false));
		myPersonList.add(new Person("Motte", 15, false));
		myPersonList.add(new Person("Pratdut", 25, true));
		myPersonList.add(new Person("Giphone", 35, false));
		myPersonList.add(new Person("Garphine", 50, false));
		myPersonList.add(new Person("Sume", 31, false));
		myPersonList.add(new Person("Chedantrou", 36, false));
		myPersonList.add(new Person("Factions", 15, false));
		myPersonList.add(new Person("Pouillou", 26, false));
		
		viewer.setInput(myPersonList);
				
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
		viewer.setCellModifier(new ICellModifier() {

			public boolean canModify(Object element, String property) {
				return true;
			}

			public Object getValue(Object element, String property) {
				Person currentPerson = (Person)element;
				if (property.equals("NOM")) {					
					return (currentPerson).getName();
				} else if (property.equals("AGE")) {
					return Integer.toString(currentPerson.getOld());
				} else {
					return Boolean.toString(currentPerson.isVegetarian());
				}
			}

			public void modify(Object element, String property, Object value) {
				TableItem currentItem = (TableItem)element;
				Person currentPerson = (Person)currentItem.getData();
				if (property.equals("NOM")) {					
					currentPerson.setName((String)value);
				} else if (property.equals("AGE")) {
					currentPerson.setOld(Integer.parseInt((String)value));
				} else {
					currentPerson.setVegetarian(Boolean.parseBoolean((String)value));
				}
				
				viewer.refresh(currentPerson);
			}
			
		});
		viewer.setColumnProperties(new String[] {"NOM", "AGE", "VEGETARIEN"});
		viewer.setCellEditors(new CellEditor[] { new TextCellEditor(table),
				new TextCellEditor(table), new TextCellEditor(table)});
	    
	    new TableColumn(table, SWT.CENTER).setText("Nom");   
	    new TableColumn(table, SWT.CENTER).setText("Age");
	    new TableColumn(table, SWT.CENTER).setText("Végétarien");
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}

	public static void main(String[] argv) {		
		new TableViewerEditorExample();
	}
}
