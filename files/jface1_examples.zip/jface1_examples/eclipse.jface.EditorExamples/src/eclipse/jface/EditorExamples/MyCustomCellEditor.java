package eclipse.jface.EditorExamples;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class MyCustomCellEditor extends CellEditor {
	private Text myText;
	
	private Composite myComposite;
	
	public MyCustomCellEditor(Composite parent, int style) {
		super(parent, style);
	}

	protected Control createControl(Composite parent) {
		myComposite = new Composite(parent, SWT.NONE);
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		gridLayout.marginTop = -5;
		gridLayout.marginBottom = -5;
		gridLayout.verticalSpacing = 0;
		gridLayout.marginWidth = 0;
		myComposite.setLayout(gridLayout);
		Label myLabel = new Label(myComposite, SWT.NONE);
		myLabel.setText("Saisir : ");
		myText = new Text(myComposite, SWT.NONE);
		myText.setLayoutData(new GridData(GridData.FILL_BOTH));
		myText.addSelectionListener(new SelectionAdapter() {
			public void widgetDefaultSelected(SelectionEvent e) {
				MyCustomCellEditor.this.fireApplyEditorValue();
			}			
		});
		return myComposite;
	}

	protected Object doGetValue() {
		return myText.getText();
	}

	protected void doSetFocus() {
		myText.setFocus();		
		myText.selectAll();
	}

	protected void doSetValue(Object element) {
		if (element instanceof String) {
			myText.setText((String)element);
		}
	}
}
