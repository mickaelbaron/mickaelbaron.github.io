package eclipse.jface.EditorExamples;

import java.util.ArrayList;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
* @author Mickael BARON (baron.mickael@gmail.com)
* 
* Date : october 2007
*/
public class TableViewerColumnEditorExample {

	public static void main(String[] argv) {		
		new TableViewerColumnEditorExample();
	}
	
	public TableViewerColumnEditorExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("TableViewer : éditeur par colonne");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);	
		viewer.setContentProvider(new MyStructuredContentProvider());		

		TableViewerColumn column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new MyColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return currentPerson.getName();
			}
		});
		column.getColumn().setText("Nom");
		column.setEditingSupport(new MyEditingSupport(viewer));
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new MyColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return Integer.toString(currentPerson.getOld());
			}		
		});
		column.getColumn().setText("Age");

		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new MyColumnLabelProvider() {
			public String getText(Object element) {
				Person currentPerson = (Person)element;
				return Boolean.toString(currentPerson.isVegetarian());
			}		
		});
		column.getColumn().setText("Végétarien");
		
		ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont", 22, false));
		myPersonList.add(new Person("Motte", 15, false));
		myPersonList.add(new Person("Pratdut", 25, true));
		myPersonList.add(new Person("Giphone", 35, false));
		myPersonList.add(new Person("Garphine", 50, false));
		myPersonList.add(new Person("Sume", 31, false));
		myPersonList.add(new Person("Chedantrou", 36, false));
		myPersonList.add(new Person("Factions", 15, false));
		myPersonList.add(new Person("Pouillou", 26, false));
			
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
		viewer.setInput(myPersonList);
		
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyEditingSupport extends EditingSupport {

		private CellEditor editor;
		private Viewer myViewer;
		public MyEditingSupport(ColumnViewer viewer) {
			super(viewer);
			myViewer = viewer;
			editor = new TextCellEditor((Composite)viewer.getControl());
		}
		protected boolean canEdit(Object element) {
			return true;
		}

		protected CellEditor getCellEditor(Object element) {
			return editor;
		}	

		protected Object getValue(Object element) {
			Person current = (Person)element;
			return current.getName();
		}

		protected void setValue(Object element, Object value) {
			Person current = (Person)element;
			current.setName((String)value);
			myViewer.refresh();
		}		
	}
	
	static class MyColumnLabelProvider extends ColumnLabelProvider {
	
		public int getToolTipDisplayDelayTime(Object object) {
			return 500;
		}

		public int getToolTipTimeDisplayed(Object object) {
			return 2000;
		}
		
		public Point getToolTipShift(Object object) {
			return new Point(5, 5);
		}

		public boolean useNativeToolTip(Object object) {
			return false;
		}
	}
}