package eclipse.jface.SelectionExamples;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.BaseLabelProvider;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class TreeViewerSelectionExample {
	
	private List<Job> myPersonWork;
	
	public TreeViewerSelectionExample() {
		Display display = new Display();

		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(2, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("Selection Tree Viewer");
		final TreeViewer viewer = new TreeViewer(shell, SWT.FULL_SELECTION);
		viewer.setContentProvider(new MyTreeContentProvider());
		viewer.setLabelProvider(new MyTreeLabelProvider());
		
		myPersonWork = new ArrayList<Job>();
		
		Job currentWork = new Job("Informaticien");
		currentWork.addPerson(new Person("Robert Glan", "Nancy", "25", "Voiture", "1600"));
		currentWork.addPerson(new Person("John Rambo", "Limoges", "35", "Train", "1900"));
		currentWork.addPerson(new Person("Antoine Ronba", "Niort", "40", "Avion", "5000"));
		myPersonWork.add(currentWork);
		
		currentWork = new Job("Medecin");
		currentWork.addPerson(new Person("Jean Dupont", "Tours", "39", "Train", "1200"));
		currentWork.addPerson(new Person("Guy Fregatte", "La Rochelle", "35", "Bateau", "2000"));
		currentWork.addPerson(new Person("Olivier Huile", "Nantes", "45", "Avion", "12000"));
		currentWork.addPerson(new Person("Tony Presson", "Paris", "43", "Cheval", "2000"));
		currentWork.addPerson(new Person("Jean Mange", "Paris", "29", "Voiture", "9000"));
		myPersonWork.add(currentWork);
		
		Tree tree = viewer.getTree();
		GridData gridData = new GridData(GridData.FILL_BOTH);
		gridData.horizontalSpan = 2;
		tree.setLayoutData(gridData);
		viewer.setInput(myPersonWork);
		
		tree.setLinesVisible(true);
		viewer.expandAll();

		Button myButton = new Button(shell, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				TreeSelection currentSelection = (TreeSelection)viewer.getSelection();
				TreePath[] paths = currentSelection.getPaths();
				for (TreePath treePath : paths) {
					Object lastSegment = treePath.getLastSegment();
					System.out.println(lastSegment.toString());
				}
			}			
		});
		myButton.setText("Get Selection");
		myButton.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));
		
		myButton = new Button(shell, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				Job firstJob = myPersonWork.get(0);
				Object[] tabObject = {firstJob, firstJob.getPersons().get(0)};
				TreePath path = new TreePath(tabObject);
				viewer.setSelection(new TreeSelection(path));
			}	
		});
		myButton.setText("Set Selection");
		myButton.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));

		
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	

	static class MyTreeLabelProvider extends BaseLabelProvider implements ILabelProvider {

		public Image getImage(Object element) {
			return null;
		}

		public String getText(Object element) {
			if (element instanceof Person) {
				Person current = (Person)element;
				return current.getName();
			} else {
				return element.toString();					
			}
		}		
	}
	
	static class MyTreeContentProvider implements ITreeContentProvider {

		@SuppressWarnings("unchecked")
		public Object[] getElements(Object element) {
			final Object[] currentPersonWorks = ((List<Job>) element)
					.toArray();
			return currentPersonWorks;
		}

		public void dispose() {
		}

		public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		}

		public Object[] getChildren(Object element) {
			final Job currentPersonWork = (Job) element;
			return currentPersonWork.getPersons().toArray();
		}

		public Object getParent(Object element) {
			if (element instanceof Person) {
				return ((Person)element).getParent();
			} else {
				return null;
			}
		}

		public boolean hasChildren(Object element) {
			if (element instanceof Job) {
				Job current = (Job) element;
				return !current.isPersonEmpty();
			} else {
				return false;
			}
		}
	}
	
	private static class Job {
		private List<Person> myPerson;

		private String job;

		public Job(String pMetier) {
			this.job = pMetier;
			myPerson = new ArrayList<Person>();
		}

		public void addPerson(Person pPerson) {
			myPerson.add(pPerson);
			pPerson.setParent(this);
		}

		public String getMetier() {
			return job;
		}

		public List<Person> getPersons() {
			return myPerson;
		}

		public String toString() {
			return job;
		}

		public boolean isPersonEmpty() {
			return myPerson.isEmpty();
		}
	}

	private static class Person {
		private String name;
	
		private String adress;
		
		private String old;
		
		private String vehicule;
		
		private String salary;

		private Job parent;

		public Person(String pName, String pAdress, String pOld,
				String pVehicule, String pSalary) {
			this.name = pName;
			this.adress = pAdress;
			this.old = pOld;
			this.vehicule = pVehicule;
			this.salary = pSalary;
		}

		public Job getParent() {
			return parent;
		}
		
		public void setParent(Job pWork) {
			this.parent = pWork;
		}

		public String getName() {
			return this.name;
		}

		public String getAdress() {
			return adress;
		}

		public String getOld() {
			return old;
		}

		public String getVehicule() {
			return vehicule;
		}

		public String getSalary() {
			return salary;
		}
		
		public String toString() {
			return name;
		}
	}
	
	public static void main(String[] argv) {
		new TreeViewerSelectionExample();
	}
}
