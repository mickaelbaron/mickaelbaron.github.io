package eclipse.jface.SelectionExamples;
import java.util.ArrayList;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
public class BothTableViewerSelectionExample {

	public static void main(String[] argv) {		
		new BothTableViewerSelectionExample();
	}
	
	public BothTableViewerSelectionExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(2, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("Simple Table Viewer");
		final TableViewer viewer1 = new TableViewer(shell, SWT.FULL_SELECTION);
		
		viewer1.setUseHashlookup(true);
		viewer1.setContentProvider(new MyStructuredContentProvider());		
		viewer1.setLabelProvider(new MyTableLabelProvider());
		
		GridData myData = new GridData(GridData.FILL_BOTH);
		Table table1 = viewer1.getTable();
	    table1.setLayoutData(myData);
		
	    new TableColumn(table1, SWT.CENTER).setText("Nom");   
	    new TableColumn(table1, SWT.CENTER).setText("Prénom");
	    new TableColumn(table1, SWT.CENTER).setText("Sport");
	    new TableColumn(table1, SWT.CENTER).setText("Age");
	    new TableColumn(table1, SWT.CENTER).setText("Végétarien");
	    
	    for (int i = 0, n = table1.getColumnCount(); i < n; i++) {
	        table1.getColumn(i).setWidth(100);
	      }	    
	    
	    table1.setHeaderVisible(true);
	    table1.setLinesVisible(true);
	   
	    
		final ArrayList<Person> myPersonList = new ArrayList<Person>();
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		myPersonList.add(new Person("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new Person("Motte","John", "Football", 15, false));
		myPersonList.add(new Person("Pratdut","Béatrice", "Basketball", 25, true));
		myPersonList.add(new Person("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new Person("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new Person("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new Person("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new Person("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new Person("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new Person("Rioux","René", "Rugby", 61, false));
		viewer1.setInput(myPersonList);
		
		final TableViewer viewer2 = new TableViewer(shell, SWT.FULL_SELECTION);
		viewer2.setUseHashlookup(true);
		viewer2.setContentProvider(new MyStructuredContentProvider());		
		viewer2.setLabelProvider(new MyTableLabelProvider());
				
		myData = new GridData(GridData.FILL_BOTH);
		Table table2 = viewer2.getTable();
	    table2.setLayoutData(myData);
		
	    new TableColumn(table2, SWT.CENTER).setText("Nom");   
	    new TableColumn(table2, SWT.CENTER).setText("Prénom");
	    new TableColumn(table2, SWT.CENTER).setText("Sport");
	    new TableColumn(table2, SWT.CENTER).setText("Age");
	    new TableColumn(table2, SWT.CENTER).setText("Végétarien");
	    
	    for (int i = 0, n = table2.getColumnCount(); i < n; i++) {
	    	table2.getColumn(i).setWidth(100);
	      }	    
	    
	    table2.setHeaderVisible(true);
	    table2.setLinesVisible(true);
		
		viewer2.setInput(myPersonList);
		
			viewer1.addSelectionChangedListener(new ISelectionChangedListener() {
	
				public void selectionChanged(SelectionChangedEvent event) {
					ISelection selection = event.getSelection();
					if (selection instanceof IStructuredSelection) {
						IStructuredSelection currentSelection = (IStructuredSelection)selection;
						viewer2.setSelection(currentSelection);
					}
				}
			
		});
		
		
		Button myButton = new Button(shell, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				ISelection mySelection = viewer1.getSelection();
				if (mySelection instanceof IStructuredSelection) {
					IStructuredSelection current = (IStructuredSelection)mySelection;
					int index = myPersonList.indexOf(current.getFirstElement());
					index = (index + 1) % myPersonList.size(); 
					StructuredSelection currentSel = new StructuredSelection(myPersonList.get(index));
					viewer1.setSelection(currentSel, true);
				}
			}
		});
		myButton.setText("Go Selection (Viewer)");

		myData = new GridData(GridData.FILL_HORIZONTAL);
		myData.horizontalSpan = 2;
		myButton.setLayoutData(myData);
			    
	    viewer1.refresh();
	    viewer2.refresh();

		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<Person> localInputElement = (ArrayList<Person>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
	
	static class MyTableLabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			Person currentPerson = (Person)element;
			switch(columnIndex) {
			case 0 : return currentPerson.getName();
			case 1 : return currentPerson.getFirstName();
			case 2 : return currentPerson.getSportName();
			case 3 : return Integer.toString(currentPerson.getOld());
			case 4 : return Boolean.toString(currentPerson.isVegetarian());
			default : return "";
			}
		}

		public void addListener(ILabelProviderListener listener) {
		}

		public void dispose() {
		}

		public boolean isLabelProperty(Object element, String property) {
			return false;
		}

		public void removeListener(ILabelProviderListener listener) {
		}
	}
}
