﻿package eclipse.jface.TableViewerExamples;
import java.util.ArrayList;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerToolTipSupport;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.window.ToolTip;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2007
 */
public class TableViewerColumnTinyExample {

	public static void main(String[] argv) {		
		new TableViewerColumnTinyExample();
	}
	
	public TableViewerColumnTinyExample() {
		Display display = new Display();
			
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setBounds(10, 10, 300, 300);
		shell.setText("LabelProvider par colonne");
		final TableViewer viewer = new TableViewer(shell, SWT.FULL_SELECTION);	
		viewer.setContentProvider(new MyStructuredContentProvider());		

		TableViewerColumn column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new MyColumnLabelProvider() {
			public Color getBackground(Object element) {
				return Display.getDefault().getSystemColor(SWT.COLOR_GREEN);
			}

			public String getText(Object element) {
				PersonData currentPerson = (PersonData)element;
				return currentPerson.getName();
			}
			public Color getToolTipBackgroundColor(Object object) {
				return Display.getCurrent().getSystemColor(SWT.COLOR_MAGENTA);
			}
			
			public String getToolTipText(Object element) {
				PersonData myReference = (PersonData)element;				
				return "Le nom de cette personne est : " + myReference.getName();
			}			
		});
		column.getColumn().setText("Nom");
		
		column = new TableViewerColumn(viewer,SWT.NONE);
		column.setLabelProvider(new MyColumnLabelProvider() {
			public String getText(Object element) {
				PersonData currentPerson = (PersonData)element;
				return currentPerson.getFirstName();
			}

			public Color getToolTipBackgroundColor(Object object) {
				return Display.getCurrent().getSystemColor(SWT.COLOR_CYAN);
			}
			
			public String getToolTipText(Object element) {
				PersonData myReference = (PersonData)element;				
				return "Le prénom de cette personne est : " + myReference.getFirstName();
			}			
		});
		column.getColumn().setText("Prénom");
		ColumnViewerToolTipSupport.enableFor(viewer,ToolTip.NO_RECREATE);		
		
		ArrayList<PersonData> myPersonList = new ArrayList<PersonData>();
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));
		myPersonList.add(new PersonData("Dupont","Sandrine"));
		myPersonList.add(new PersonData("Motte","John"));
		myPersonList.add(new PersonData("Pratdut","Béatrice"));
		myPersonList.add(new PersonData("Giphone","Harry"));
		myPersonList.add(new PersonData("Garphine","Mohamed"));
		myPersonList.add(new PersonData("Sume","Bruce"));
		myPersonList.add(new PersonData("Chedantrou","Damien"));
		myPersonList.add(new PersonData("Factions","Pauline"));
		myPersonList.add(new PersonData("Pouillou","Laurent"));
		myPersonList.add(new PersonData("Rioux","René"));
		
		viewer.setInput(myPersonList);
		
		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	    
		shell.open();

		while (!shell.isDisposed()) {
			display.readAndDispatch();
		}
		display.dispose();
	}
	
	static class MyColumnLabelProvider extends ColumnLabelProvider {
	
		public int getToolTipDisplayDelayTime(Object object) {
			return 500;
		}

		public int getToolTipTimeDisplayed(Object object) {
			return 2000;
		}
		
		public Point getToolTipShift(Object object) {
			return new Point(5, 5);
		}

		public boolean useNativeToolTip(Object object) {
			return false;
		}
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<PersonData> localInputElement = (ArrayList<PersonData>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
	
	static class PersonData {
		private String name;
		
		private String firstName;
		
		public PersonData(String pName, String pFirstName) {
			super();
			this.name = pName;
			this.firstName = pFirstName;
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getFirstName() {
			return firstName;
		}
		
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
	}
}
