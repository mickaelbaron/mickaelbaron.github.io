package eclipse.labs.jugercp.quizz.views;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.ui.part.ViewPart;

import eclipse.labs.jugercp.attendees.Activator;
import eclipse.labs.jugercp.attendees.IAttendee;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2009
 */
public class QuizzViewPart extends ViewPart {

	@Override
	public void dispose() {
		super.dispose();
	}

	private Label myCountLabel;

	public QuizzViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		GridLayout currentGridLayout = new GridLayout();

		parent.setLayout(currentGridLayout);

		myCountLabel = new Label(parent, SWT.CENTER);
		Font font = new Font(Display.getDefault(), "Arial", 50, SWT.NORMAL);
		myCountLabel.setFont(font);
		myCountLabel.setBackground(Display.getDefault().getSystemColor(
				SWT.COLOR_WHITE));
		myCountLabel.setForeground(Display.getDefault().getSystemColor(
				SWT.COLOR_BLACK));

		GridData myGridData = new GridData(GridData.FILL_BOTH);
		myCountLabel.setLayoutData(myGridData);

		Button goButton = new Button(parent, SWT.FLAT);
		goButton.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});
		goButton.setText("JUGeRCP Quizz");
		myGridData = new GridData(GridData.FILL_HORIZONTAL);
		goButton.setLayoutData(myGridData);
	}

	@Override
	public void setFocus() {
	}
}
