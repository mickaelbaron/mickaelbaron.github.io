package eclipse.labs.jugercp.attendees.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2009
 */
public class JUGAttendeesPerspectiveFactory implements IPerspectiveFactory {

	@Override
	public void createInitialLayout(IPageLayout layout) {
		layout.setEditorAreaVisible(false);
		String editorArea = layout.getEditorArea();

		layout.addView("eclipse.labs.jugercp.attendees.attendeeid",
				IPageLayout.LEFT, 0.5f, editorArea);
		layout.addView("eclipse.labs.jugercp.attendees.listattendeesid",
				IPageLayout.BOTTOM, 0.5f, editorArea);
		layout.addView("org.eclipse.ui.views.PropertySheet",
				IPageLayout.BOTTOM, 0.5f,
				"eclipse.labs.jugercp.attendees.attendeeid");
	}
}
