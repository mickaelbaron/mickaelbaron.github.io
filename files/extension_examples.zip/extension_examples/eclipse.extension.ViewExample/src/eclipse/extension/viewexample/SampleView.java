package eclipse.extension.viewexample;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public class SampleView extends ViewPart {

	public SampleView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		Label myLabel = new Label(parent, SWT.NONE);
		myLabel.setText("Hello World in a new View");
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
	}
}
