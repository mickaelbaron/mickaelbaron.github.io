package eclipse.extension.wizardexamples;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;

public class HolidayWizard extends Wizard implements INewWizard {

	/**
	 * Main page.
	 */
	HolidayMainPage holidayPage;
	
	/**
	 * Page related to the plane choice.
	 */
	PlanePage planePage;
	
	/**
	 * Page related to the car choice.
	 */
	CarPage carPage;

	/**
	 * The model 
	 */
	HolidayModel model;

	protected boolean planeCompleted = false;

	protected boolean carCompleted = false;

	/**
	 * Constructor for HolidayMainWizard.
	 */
	public HolidayWizard() {
		super();
		model = new HolidayModel();
	}

	public void addPages() {
		holidayPage = new HolidayMainPage();
		addPage(holidayPage);
		planePage = new PlanePage("");
		addPage(planePage);
		carPage = new CarPage("");
		addPage(carPage);
	}

	public boolean canFinish() {
		if (this.getContainer().getCurrentPage() == holidayPage)
			return false;

		if (model.usePlane)
			return planeCompleted;
		return carCompleted;
	}

	public boolean performFinish() {
		String summary = model.toString();
		System.out.println(summary);
		return true;
	}

	public void init(IWorkbench workbench, IStructuredSelection selection) {
		
	}
}
