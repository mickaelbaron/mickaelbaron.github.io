package eclipse.extension.wizardexamples.views;

import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import eclipse.extension.wizardexamples.HolidayWizard;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public class WizardExamples extends ViewPart {

	public WizardExamples() {
	}

	public void createPartControl(final Composite parent) {
		Button openWizard = new Button(parent, SWT.FLAT);
		openWizard.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				HolidayWizard wizard = new HolidayWizard();
				wizard.setWindowTitle("Holiday Wizard");
				WizardDialog refWizardDialog = new WizardDialog(parent.getShell(), wizard);
				refWizardDialog.open();
			}			
		});
		openWizard.setText("Open Holiday Wizard");
	}

	public void setFocus() {
	}
}