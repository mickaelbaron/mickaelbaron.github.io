package eclipse.extension.calculator.views;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public class RegistryQueryView extends ViewPart {

	public RegistryQueryView() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(2, true));
		
		Button example1Button = new Button(parent, SWT.FLAT);
		example1Button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				IExtensionRegistry extensionRegistry = Platform.getExtensionRegistry();
				IExtension extension = extensionRegistry.getExtension("eclipse.extension.binaryoperator.minusId");
				System.out.println(extension.getLabel());
				
				IExtensionPoint extensionPoint = extensionRegistry.getExtensionPoint("org.eclipse.ui.views");
				IExtension[] extensions = extensionPoint.getExtensions();
				for (IExtension current :extensions) {
					System.out.println(current.getUniqueIdentifier());
				}

				IExtension reg = extensionRegistry.getExtension("eclipse.extension.Calculator.calculatorViewId");
				System.out.println(reg.getConfigurationElements().length);
				if (reg.getConfigurationElements().length == 2) {
					System.out.println(reg.getConfigurationElements()[0].getNamespaceIdentifier()); // .getAttribute("name"));
				}
				System.out.println(reg.getConfigurationElements().length);
			}			
		});
		example1Button.setText("Extension MinusID");
		
		Button example2Button = new Button(parent, SWT.FLAT);
		example2Button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				IExtensionRegistry extensionRegistry = Platform.getExtensionRegistry();
				IExtension[] extensions = extensionRegistry.getExtensions("eclipse.extension.binaryoperator");
				for (IExtension current : extensions) {
					System.out.println(current.getUniqueIdentifier());
				}
			}			
		});
		example2Button.setText("Extensions");
		
		Button example3Button = new Button(parent, SWT.FLAT);
		example3Button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				IExtensionRegistry extensionRegistry = Platform.getExtensionRegistry();
				IExtensionPoint extPoint = extensionRegistry.getExtensionPoint("eclipse.extension.calculator.binaryoperator");
				System.out.println(extPoint.getLabel());
			}			
		});
		example3Button.setText("Point Extension binaryoperator");
		
		Button example4Button = new Button(parent, SWT.FLAT);
		example4Button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				IExtensionRegistry extensionRegistry = Platform.getExtensionRegistry();
				IExtensionPoint[] extPoint = extensionRegistry.getExtensionPoints();
				for (IExtensionPoint current : extPoint) {
					System.out.println(current.getUniqueIdentifier());
				}
			}			
		});
		example4Button.setText("Points Extension");
		
		Button exemple5Button = new Button(parent, SWT.FLAT);
		exemple5Button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				IExtensionRegistry extensionRegistry = Platform.getExtensionRegistry();
				IExtensionPoint extPoint = extensionRegistry.getExtensionPoint("eclipse.extension.calculator.binaryoperator");
				
				IConfigurationElement[] configurationElements = extPoint.getConfigurationElements();
				for (IConfigurationElement current : configurationElements) {
					String[] attributeNames = current.getAttributeNames();
					for (String currentAttributeName : attributeNames) {
						System.out.println("Attribut : " + currentAttributeName
								+ " / Valeur : "
								+ current.getAttribute(currentAttributeName));
					}
				}
			}			
		});
		exemple5Button.setText("Attributs/Valeurs");
	}

	public void setFocus() {
	}
}
