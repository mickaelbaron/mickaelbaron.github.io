package eclipse.extension.calculator.views;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import eclipse.extension.calculator.binaryoperator.IBinaryOperator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public class CalculatorView extends ViewPart {

	public CalculatorView() {
	}

	public void createPartControl(Composite parent) {
		String extensionPointId = "eclipse.extension.calculator.binaryoperator";
		final IConfigurationElement[] contributions = Platform
				.getExtensionRegistry().getConfigurationElementsFor(
						extensionPointId);
			
		parent.setLayout(new GridLayout(1, true));

		Composite operatorComposite = new Composite(parent, SWT.NONE);
		operatorComposite.setLayout(new GridLayout(1, true));
		Label comboLabel = new Label(operatorComposite, SWT.NONE);
		comboLabel.setText("Choose a binary operator");
		final Combo myCombo = new Combo(operatorComposite, SWT.NONE);
		for (int i = 0; i < contributions.length; i++) {
			myCombo.add(contributions[i].getAttribute("designation"));
		}

		Composite inputArea = new Composite(parent, SWT.NONE);
		inputArea.setLayout(new GridLayout(2, true));
		Label leftLabel = new Label(inputArea, SWT.NONE);
		leftLabel.setText("Left");
		Label rightLabel = new Label(inputArea, SWT.NONE);
		rightLabel.setText("Right");
		final Text leftInput = new Text(inputArea, SWT.BORDER);
		final Text rightInput = new Text(inputArea, SWT.BORDER);

		Button compute = new Button(parent, SWT.FLAT);
		compute.setText("Compute");
		
		Composite resultArea = new Composite(parent, SWT.NONE);
		resultArea.setLayout(new GridLayout(1, true));
		Label resultLabel = new Label(resultArea, SWT.NONE);
		resultLabel.setText("Result");
		final Text resultText = new Text(resultArea, SWT.BORDER);
		
		compute.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {				
				int selectionIndex = myCombo.getSelectionIndex();
				if (selectionIndex != -1) {
					Double leftDouble = Double.parseDouble(leftInput.getText());
					Double rightDouble = Double.parseDouble(rightInput.getText());
					
					try {
						IBinaryOperator binaryOperator = (IBinaryOperator) (contributions[selectionIndex]
								.createExecutableExtension("class"));
						Double resultDouble = binaryOperator.compute(leftDouble, rightDouble);
						resultText.setText(resultDouble.toString());
					} catch (CoreException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
	}

	public void setFocus() {
	}
}