package eclipse.extension.calculator.binaryoperator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public interface IBinaryOperator {
	Double compute(Double left, Double right);
}
