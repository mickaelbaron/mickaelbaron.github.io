package eclipse.extension.binaryoperator.plus;

import eclipse.extension.calculator.binaryoperator.IBinaryOperator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public class Plus implements IBinaryOperator {

	public Plus() {
	}

	public Double compute(Double left, Double right) {
		double leftValue = left.doubleValue();
		double rightValue = right.doubleValue();
		
		double doubleResult = leftValue + rightValue;		
		return doubleResult;
	}
}
