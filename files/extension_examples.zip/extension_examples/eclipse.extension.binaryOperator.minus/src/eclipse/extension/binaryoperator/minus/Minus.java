package eclipse.extension.binaryoperator.minus;

import eclipse.extension.calculator.binaryoperator.IBinaryOperator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
public class Minus implements IBinaryOperator {

	public Minus() {
	}

	public Double compute(Double left, Double right) {
		double leftValue = left.doubleValue();
		double rightValue = right.doubleValue();
		
		double doubleResult = leftValue - rightValue;		
		return doubleResult;
	}
}
