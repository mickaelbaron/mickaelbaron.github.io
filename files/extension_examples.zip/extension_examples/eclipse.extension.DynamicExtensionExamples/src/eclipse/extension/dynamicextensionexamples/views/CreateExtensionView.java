package eclipse.extension.dynamicextensionexamples.views;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.eclipse.core.internal.registry.ExtensionRegistry;
import org.eclipse.core.internal.registry.spi.ConfigurationElementAttribute;
import org.eclipse.core.internal.registry.spi.ConfigurationElementDescription;
import org.eclipse.core.runtime.ContributorFactoryOSGi;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IContributor;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.RegistryFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.ui.part.ViewPart;
import org.osgi.framework.Bundle;

import eclipse.extension.dynamicextensionexamples.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2008
 */
@SuppressWarnings("restriction")
public class CreateExtensionView extends ViewPart {
	private int sequenceId = 0;
	
	/**
	 * The constructor.
	 */
	public CreateExtensionView() {
	}

	public void createPartControl(Composite parent) {		
		parent.setLayout(new GridLayout(1, true));
		
		Group addExtensionGroup = new Group(parent, SWT.NONE);
		addExtensionGroup.setLayout(new GridLayout(1, true));
		addExtensionGroup.setText("Add Extension");
		
		Button myButtonAddExtension = new Button(addExtensionGroup, SWT.FLAT);
		myButtonAddExtension.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				createFromAddExtension();
			}			
		});
		myButtonAddExtension.setText("Add New View with userToken");
		
		Button myButtonAddExtensionWithoutToken = new Button(addExtensionGroup, SWT.FLAT);
		myButtonAddExtensionWithoutToken.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				createFromAddExtensionWithoutToken();
			}			
		});
		myButtonAddExtensionWithoutToken.setText("Add New View without userToken");
		
		Group addContributionGroup = new Group(parent, SWT.NONE);
		addContributionGroup.setLayout(new GridLayout(1,true));
		addContributionGroup.setText("Add Contribution");
		
		Button myButtonAddContributionWithXMLString = new Button(addContributionGroup, SWT.FLAT);
		myButtonAddContributionWithXMLString.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				createFromAddContributionWithXMLString();
			}
		});
		myButtonAddContributionWithXMLString.setText("Add New View with XML String");
		
		Button myButtonAddContributionWithXMLFile = new Button(addContributionGroup, SWT.FLAT);
		myButtonAddContributionWithXMLFile.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				createFromAddContributionWithXMLFile();
			}
		});
		myButtonAddContributionWithXMLFile.setText("Add New View with XML File");

		Button myButtonAddContributionExtensionPoint = new Button(addContributionGroup, SWT.FLAT);
		myButtonAddContributionExtensionPoint.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				createFromAddContributionExtensionPoint();
			}
		});
		myButtonAddContributionExtensionPoint.setText("Add binaryoperator extension point");
	}

	private void createFromAddContributionExtensionPoint() {
		IExtensionRegistry registry = RegistryFactory.getRegistry();
		
		Bundle bundle = Activator.getDefault().getBundle();
		IContributor contributor = ContributorFactoryOSGi.createContributor(bundle);
		String extensionPoint = "<plugin><extension-point" + 
			" id=\"eclipse.extension.dynamicextension.test\"" + 
			" name=\"DynamicExtensionPoint\"" + 
			" schema=\"schema/eclipse.extension.dynamicextension.test.exsd\"/></plugin>";
		
		InputStream is = new ByteArrayInputStream(extensionPoint.getBytes());
		registry.addContribution(is, contributor, false, null, null, null);
		
		IExtensionPoint[] extensionPoints = registry.getExtensionPoints();
		for (IExtensionPoint current : extensionPoints) {
			System.out.println(current.getUniqueIdentifier());
		}
	}
	
	private void createFromAddContributionWithXMLString() {
		IExtensionRegistry registry = RegistryFactory.getRegistry();
				
		Bundle bundle = Activator.getDefault().getBundle();
		IContributor contributor = ContributorFactoryOSGi.createContributor(bundle);
		String extension = "<plugin><extension point=\"org.eclipse.ui.views\">" +
			" <view category=\"eclipse.extension.DynamicExtensionExamples\"" + 
			" class=\"eclipse.extension.dynamicextensionexamples.views.GenericView\"" +
			" icon=\"icons/sample.gif\"" +
			" id=\"genericViewId" + sequenceId + "\"" +
			" name=\"GenericView" + sequenceId + "\">" +
			" </view></extension></plugin>";
		InputStream is = new ByteArrayInputStream(extension.getBytes());
		registry.addContribution(is, contributor, false, null, null, null);
		sequenceId++;
	}

	private void createFromAddContributionWithXMLFile() {
		IExtensionRegistry registry = RegistryFactory.getRegistry( );
				
		Bundle bundle = Activator.getDefault().getBundle();
		IContributor contributor = ContributorFactoryOSGi.createContributor(bundle);
		try {
			InputStream is = FileLocator.openStream(bundle,new Path("newextension.xml"),true);
			registry.addContribution(is, contributor, false, null, null, null);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void createFromAddExtensionWithoutToken() {
		Bundle bundle = Activator.getDefault().getBundle();
		IContributor contributor = ContributorFactoryOSGi.createContributor(bundle);
		
		ConfigurationElementAttribute[] conf = new ConfigurationElementAttribute[6];
		conf[0] = new ConfigurationElementAttribute("id", "genericViewId" + sequenceId);
		conf[1] = new ConfigurationElementAttribute("name", "GenericView" + sequenceId);
		conf[2] = new ConfigurationElementAttribute("class", "eclipse.extension.dynamicextensionexamples.views.GenericView");
		conf[3] = new ConfigurationElementAttribute("category", "eclipse.extension.DynamicExtensionExamples");
		conf[4] = new ConfigurationElementAttribute("restorable", "true");
		conf[5] = new ConfigurationElementAttribute("allowMultiple", "true");

		String extensionPointId = "org.eclipse.ui.views";
		ConfigurationElementDescription configurationElements = new	ConfigurationElementDescription("view", conf, null, null);

		ExtensionRegistry reg = (ExtensionRegistry)Platform.getExtensionRegistry();
		reg.addExtension("", contributor, false, "", extensionPointId, configurationElements, null);
		sequenceId++;
	}
	
	private void createFromAddExtension() {
		ExtensionRegistry reg = (ExtensionRegistry)Platform.getExtensionRegistry();

		Bundle bundle = Activator.getDefault().getBundle();
		IContributor contributor = ContributorFactoryOSGi.createContributor(bundle);
		
		ConfigurationElementAttribute[] conf = new ConfigurationElementAttribute[6];
		conf[0] = new ConfigurationElementAttribute("id", "genericViewId" + sequenceId);
		conf[1] = new ConfigurationElementAttribute("name", "GenericView" + sequenceId);
		conf[2] = new ConfigurationElementAttribute("class", "eclipse.extension.dynamicextensionexamples.views.GenericView");
		conf[3] = new ConfigurationElementAttribute("category", "eclipse.extension.DynamicExtensionExamples");
		conf[4] = new ConfigurationElementAttribute("restorable", "true");
		conf[5] = new ConfigurationElementAttribute("allowMultiple", "true");

		String extensionPointId = "org.eclipse.ui.views";
		ConfigurationElementDescription configurationElements = new	ConfigurationElementDescription("view", conf, null, null);
		
		Object token = reg.getTemporaryUserToken();
		
		reg.addExtension("", contributor, false, "", extensionPointId, configurationElements, token);
		sequenceId++;
	}
	
	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
	}
}