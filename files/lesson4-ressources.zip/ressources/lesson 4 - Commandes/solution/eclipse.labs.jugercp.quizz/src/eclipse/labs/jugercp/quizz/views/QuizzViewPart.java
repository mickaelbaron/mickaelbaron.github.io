package eclipse.labs.jugercp.quizz.views;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.ui.part.ViewPart;

import eclipse.labs.jugercp.attendees.Activator;
import eclipse.labs.jugercp.attendees.IAttendee;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2009
 */
public class QuizzViewPart extends ViewPart {

	@Override
	public void dispose() {
		t.cancel();
		super.dispose();
	}

	private Timer t;

	private Label myCountLabel;

	public QuizzViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		GridLayout currentGridLayout = new GridLayout();

		parent.setLayout(currentGridLayout);

		myCountLabel = new Label(parent, SWT.CENTER);
		Font font = new Font(Display.getDefault(), "Arial", 50, SWT.NORMAL);
		myCountLabel.setFont(font);
		myCountLabel.setBackground(Display.getDefault().getSystemColor(
				SWT.COLOR_WHITE));
		myCountLabel.setForeground(Display.getDefault().getSystemColor(
				SWT.COLOR_BLACK));

		GridData myGridData = new GridData(GridData.FILL_BOTH);
		myCountLabel.setLayoutData(myGridData);

		Button goButton = new Button(parent, SWT.FLAT);
		goButton.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				launchQuizz();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});
		goButton.setText("JUGeRCP Quizz");
		myGridData = new GridData(GridData.FILL_HORIZONTAL);
		goButton.setLayoutData(myGridData);
	}

	public void launchQuizz() {
		if (t != null) {
			t.cancel();
		}

		myCountLabel.setBackground(Display.getDefault().getSystemColor(
				SWT.COLOR_WHITE));
		myCountLabel.setForeground(Display.getDefault().getSystemColor(
				SWT.COLOR_BLACK));

		final int attendeesCount = Activator.getDefault().getAttendeesManager()
				.getAttendeesCount();

		if (attendeesCount < 1) {
			MessageBox mb = new MessageBox(QuizzViewPart.this.getSite()
					.getShell(), SWT.ICON_ERROR | SWT.OK);
			mb
					.setMessage("Il faut au moins deux participants pour d�marrer le JUGeRCP Quizz !!!");
			mb.setText("Quizz Erreur ...");
			mb.open();
			return;
		}

		final int winner = (int) (Math.random() * attendeesCount);

		t = new Timer();
		t.schedule(new TimerTask() {
			int nbrRepetitions = 0;
			int stepQuizz = 0; // 0 -> FirstLoop; 1 -> SecondLoop with firstLoop
								// color; 2 -> Second loop with secondLoop
								// color; 3 -> finish.

			public void run() {
				Display.getDefault().syncExec(new Runnable() {
					public void run() {
						if (myCountLabel != null && !myCountLabel.isDisposed()) {
							myCountLabel.setText(Integer
									.toString(nbrRepetitions));

							if (stepQuizz == 1) {
								myCountLabel.setBackground(Display.getDefault()
										.getSystemColor(SWT.COLOR_BLUE));
								myCountLabel.setForeground(Display.getDefault()
										.getSystemColor(SWT.COLOR_WHITE));
								stepQuizz = 2;
							}
						}
					}
				});

				if (stepQuizz == 2 && nbrRepetitions == winner) {
					t.cancel();
					Display.getDefault().syncExec(new Runnable() {
						public void run() {
							MessageBox mb = new MessageBox(QuizzViewPart.this
									.getSite().getShell(), SWT.ICON_INFORMATION
									| SWT.OK);
							IAttendee attendeeAt = Activator.getDefault()
									.getAttendeesManager()
									.getAttendeeAt(winner);
							String attendeeName = attendeeAt.getName();
							String companyName = attendeeAt.getCompany();
							mb.setMessage("Le gagnant du Quizz JUGeRCP est : "
									+ attendeeName + " de la soci�t� : "
									+ companyName);
							mb.setText("Quizz Winner !!!!");
							mb.open();
						}
					});
				}

				if (nbrRepetitions < attendeesCount) {
					nbrRepetitions++;
				} else if (stepQuizz == 0) {
					stepQuizz = 1;
					nbrRepetitions = 0;
				}
			}
		}, 0, 50);
	}

	@Override
	public void setFocus() {
	}
}
