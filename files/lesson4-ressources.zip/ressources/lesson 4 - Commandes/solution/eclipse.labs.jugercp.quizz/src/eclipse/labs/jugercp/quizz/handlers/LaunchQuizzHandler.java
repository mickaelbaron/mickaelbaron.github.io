package eclipse.labs.jugercp.quizz.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import eclipse.labs.jugercp.quizz.views.QuizzViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2009
 */
public class LaunchQuizzHandler extends AbstractHandler {
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		try {
			IViewPart showView = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().showView(
					"eclipse.labs.jugercp.quizz.quizzid");
			
			if (showView != null) {
				((QuizzViewPart)showView).launchQuizz();
			}
		} catch (PartInitException e) {
			e.printStackTrace();
		}
		return null;
	}
}
