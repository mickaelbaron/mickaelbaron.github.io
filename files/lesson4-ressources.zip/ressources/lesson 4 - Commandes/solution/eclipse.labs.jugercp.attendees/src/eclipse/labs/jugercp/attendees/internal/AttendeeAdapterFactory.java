package eclipse.labs.jugercp.attendees.internal;

import org.eclipse.core.runtime.IAdapterFactory;
import org.eclipse.ui.views.properties.IPropertySource;

import eclipse.labs.jugercp.attendees.IAttendee;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2009
 */
public class AttendeeAdapterFactory implements IAdapterFactory {

	@SuppressWarnings("unchecked")
	private static final Class[] TYPES = { IPropertySource.class };

	@SuppressWarnings("unchecked")
	public Object getAdapter(Object adaptableObject, Class adapterType) {
		if (adapterType == IPropertySource.class) {
			if (adaptableObject instanceof IAttendee) {
				return new AttendeePropertySourceAdapter((IAttendee) adaptableObject);
			}
		}
		
		return null;
	}

	@SuppressWarnings("unchecked")
	public Class[] getAdapterList() {
		return TYPES;
	}
}
