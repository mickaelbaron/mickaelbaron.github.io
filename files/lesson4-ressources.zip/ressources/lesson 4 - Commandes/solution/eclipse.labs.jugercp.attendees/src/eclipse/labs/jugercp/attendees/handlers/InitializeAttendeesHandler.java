package eclipse.labs.jugercp.attendees.handlers;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;

import eclipse.labs.jugercp.attendees.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2009
 */
public class InitializeAttendeesHandler extends AbstractHandler {
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		Activator.getDefault().getAttendeesManager().removeAllAttendees();
		
		return null;
	}
}



