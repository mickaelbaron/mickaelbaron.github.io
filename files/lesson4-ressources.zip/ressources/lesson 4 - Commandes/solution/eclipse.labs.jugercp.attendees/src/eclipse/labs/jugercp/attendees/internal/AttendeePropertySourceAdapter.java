package eclipse.labs.jugercp.attendees.internal;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import eclipse.labs.jugercp.attendees.IAttendee;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : september 2009
 */
public class AttendeePropertySourceAdapter implements IPropertySource {

	private IAttendee attendee;

	public AttendeePropertySourceAdapter(IAttendee attendee) {
		this.attendee = attendee;
	}

	@Override
	public Object getEditableValue() {
		return this;
	}

	@Override
	public IPropertyDescriptor[] getPropertyDescriptors() {
		List<PropertyDescriptor> descriptors = new ArrayList<PropertyDescriptor>();

		PropertyDescriptor descriptorId = new PropertyDescriptor("id", "Identifiant");
		descriptorId.setAlwaysIncompatible(true);
		PropertyDescriptor descriptorName = new PropertyDescriptor("name", "Nom");
		descriptorName.setAlwaysIncompatible(true);
		PropertyDescriptor descriptorCompany = new PropertyDescriptor("company", "Soci�t�");
		descriptorCompany.setAlwaysIncompatible(true);
		descriptors.add(descriptorId);
		descriptors.add(descriptorName);
		descriptors.add(descriptorCompany);

		return descriptors.toArray(new IPropertyDescriptor[0]);
	}

	@Override
	public Object getPropertyValue(Object id) {
		if (id instanceof String) {
			String idString = (String) id;
			
			if (idString.equals("id")) {
				return this.attendee.getId();	
			} else if (idString.equals("name")) {
				return this.attendee.getName();				
			} else if (idString.equals("company")) {
				return this.attendee.getCompany();				
			} else {
				return "...";
			}
		} else {
			return null;
		}
	}

	@Override
	public boolean isPropertySet(Object id) {
		return false;
	}
	@Override
	public void resetPropertyValue(Object id) {
	}
	@Override
	public void setPropertyValue(Object id, Object value) {
	}
}
