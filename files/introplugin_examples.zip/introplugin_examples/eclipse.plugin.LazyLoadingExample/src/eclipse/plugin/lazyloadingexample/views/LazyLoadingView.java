package eclipse.plugin.lazyloadingexample.views;

import java.io.FileNotFoundException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import eclipse.plugin.exportexample.Activator;
import eclipse.plugin.exportexample.ISerializeName;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class LazyLoadingView extends ViewPart {

	private boolean isCreated = false;

	private Button createButton;

	private Button saveSerialization;

	private Button loadSerialization;

	private ISerializeName currentSerializeFactory;

	public LazyLoadingView() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout(SWT.VERTICAL));
		createButton = new Button(parent, SWT.NONE);
		createButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				if (!isCreated) {
					saveSerialization.setEnabled(true);
					loadSerialization.setEnabled(true);
					createButton.setEnabled(false);
					isCreated = true;
					currentSerializeFactory = Activator.getDefault()
							.getSerializeInstance();
				}
			}
		});
		createButton.setText("Creation");

		saveSerialization = new Button(parent, SWT.NONE);
		saveSerialization.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				currentSerializeFactory.setName("LazyLoadingView");
				currentSerializeFactory
						.setDescription("This is a sample message");
				try {
					currentSerializeFactory.saveFromXML();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
			}
		});
		saveSerialization.setEnabled(false);
		saveSerialization.setText("Sauvegarde");

		loadSerialization = new Button(parent, SWT.NONE);
		loadSerialization.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				try {
					currentSerializeFactory.loadFromXML();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				System.out.println(currentSerializeFactory.toString());
			}
		});
		loadSerialization.setEnabled(false);
		loadSerialization.setText("Chargement");
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
	}
}