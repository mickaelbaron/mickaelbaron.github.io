package eclipse.plugin.platformcommandparamsexample.views;

import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class PlatformCommandParams extends ViewPart {

	public PlatformCommandParams() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, true));
		Button myParameterAction = new Button(parent, SWT.NONE);
		myParameterAction.setText("Informations Parametre Commandes");
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		myParameterAction.setLayoutData(gd);

		final Text myText = new Text(parent, SWT.WRAP);
		gd = new GridData(GridData.FILL_BOTH);
		myText.setLayoutData(gd);

		myParameterAction.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				String[] applicationArgs = Platform.getApplicationArgs();
				myText.append("Application Args" + "\n");
				for (int i = 0; i < applicationArgs.length; i++) {
					myText.append(applicationArgs[i].toString() + "\n");
				}

				myText.append("\n\n" + "CommandLine Args" + "\n");
				String[] commandArgs = Platform.getCommandLineArgs();
				for (int i = 0; i < commandArgs.length; i++) {
					myText.append(commandArgs[i].toString() + "\n");
				}
			}
		});
	}

	public void setFocus() {
	}
}