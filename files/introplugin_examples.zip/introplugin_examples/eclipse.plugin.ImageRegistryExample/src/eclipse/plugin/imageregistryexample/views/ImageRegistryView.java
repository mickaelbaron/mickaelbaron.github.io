package eclipse.plugin.imageregistryexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

import eclipse.plugin.imageregistryexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class ImageRegistryView extends ViewPart {

	public ImageRegistryView() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, false));
		Label myImage = new Label(parent, SWT.NONE);
		GridData gd = new GridData(GridData.FILL_BOTH);
		myImage.setLayoutData(gd);

		myImage.setImage(Activator.getDefault().getImageRegistry().get(
				Activator.SUPERSTAR));
	}

	public void setFocus() {
	}
}