package eclipse.plugin.platformlogexample.views;

import org.eclipse.core.runtime.ILogListener;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import eclipse.plugin.platformlogexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class PlatformLog extends ViewPart {

	public PlatformLog() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, true));
		Button myLogAction = new Button(parent, SWT.NONE);
		myLogAction.setText("Creation d'un Log");
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		myLogAction.setLayoutData(gd);

		final Text myText = new Text(parent, SWT.WRAP);
		gd = new GridData(GridData.FILL_BOTH);
		myText.setLayoutData(gd);

		Platform.addLogListener(new ILogListener() {
			public void logging(IStatus status, String plugin) {
				myText.append("Message envoyé : (" + status.getMessage()
						+ ") par le plug-in : " + plugin);
			}
		});

		myLogAction.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Activator.getDefault().getLog().log(
						new Status(IStatus.INFO, Activator.PLUGIN_ID, 0,
								"Action sur le Bouton a l'instant : "
										+ System.currentTimeMillis(), null));
			}
		});
	}

	public void setFocus() {
	}
}