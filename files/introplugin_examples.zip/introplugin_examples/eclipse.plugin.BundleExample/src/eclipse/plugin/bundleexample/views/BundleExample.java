package eclipse.plugin.bundleexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;
import org.osgi.framework.Bundle;

import eclipse.plugin.bundleexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class BundleExample extends ViewPart {

	public BundleExample() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, true));
		Button myBundleInformation = new Button(parent, SWT.NONE);
		myBundleInformation.setText("Informations Bundle");
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		myBundleInformation.setLayoutData(gd);

		final Text myText = new Text(parent, SWT.WRAP);
		gd = new GridData(GridData.FILL_BOTH);
		myText.setLayoutData(gd);

		myBundleInformation.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Bundle bundle = Activator.getDefault().getBundle();
				long bundleId = bundle.getBundleId();
				String bundleState = "";
				switch (bundle.getState()) {
				case Bundle.INSTALLED:
					bundleState = "INSTALLED";
					break;
				case Bundle.ACTIVE:
					bundleState = "ACTIVE";
					break;
				case Bundle.RESOLVED:
					bundleState = "RESOLVED";
					break;
				case Bundle.STARTING:
					bundleState = "STARTING";
					break;
				case Bundle.STOPPING:
					bundleState = "STOPPING";
					break;
				case Bundle.UNINSTALLED:
					bundleState = "UNINSTALLED";
					break;
				default:
					break;
				}
				String bundleSymbolicName = bundle.getSymbolicName();
				myText.append("Bundle ID : " + bundleId + "\n");
				myText.append("Etat du bundle : " + bundleState + "\n");
				myText.append("Nom Symbolic : " + bundleSymbolicName + "\n");
			}
		});
	}

	public void setFocus() {
	}
}