package eclipse.plugin.preferenceexample;

import org.eclipse.core.runtime.Preferences;
import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class PreferenceInitializer extends AbstractPreferenceInitializer {

	public PreferenceInitializer() {
	}

	public void initializeDefaultPreferences() {
		Preferences preferences = Activator.getDefault().getPluginPreferences();
		preferences.setDefault("NAME", "Default John");
		preferences.setDefault("DESCRIPTION", "Ceci est un nom par defaut");
	}
}
