package eclipse.plugin.preferenceexample.views;

import org.eclipse.core.runtime.Preferences;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import eclipse.plugin.preferenceexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class PreferenceView extends ViewPart {

	private Text displayPreferences;

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout());
		Button loadPreference = new Button(parent, SWT.FLAT);
		loadPreference.setText("Afficher");
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		loadPreference.setLayoutData(gd);

		Button savePreference = new Button(parent, SWT.FLAT);
		savePreference.setText("Sauvegarde et Afficher");
		gd = new GridData(GridData.FILL_HORIZONTAL);
		savePreference.setLayoutData(gd);

		displayPreferences = new Text(parent, SWT.WRAP);
		gd = new GridData(GridData.FILL_BOTH);
		displayPreferences.setLayoutData(gd);

		loadPreference.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				loadPreferences();
			}
		});

		savePreference.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Preferences preferences = Activator.getDefault()
						.getPluginPreferences();
				preferences.setValue("NAME", "BARON Mickael");
				preferences.setValue("DESCRIPTION",
						"Ceci est une description donnee vers "
								+ Long.toString(System.currentTimeMillis()));
				Activator.getDefault().savePluginPreferences();
				loadPreferences();
			}
		});
	}

	private void loadPreferences() {
		Preferences preferences = Activator.getDefault().getPluginPreferences();
		String name = preferences.getString("NAME");
		String description = preferences.getString("DESCRIPTION");
		displayPreferences.append(name + " ");
		displayPreferences.append(description);
	}

	public void setFocus() {
	}
}