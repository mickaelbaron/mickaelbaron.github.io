package eclipse.plugin.exportexample;

import java.io.FileNotFoundException;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public interface ISerializeName {
	String getName();
	
	void setName(String pName);
	
	String getDescription();
	
	void setDescription(String pDescription);
	
	void loadFromXML() throws FileNotFoundException;
	
	void saveFromXML() throws FileNotFoundException;
}
