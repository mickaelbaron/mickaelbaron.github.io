package eclipse.plugin.exportexample.internal;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import eclipse.plugin.exportexample.ISerializeName;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class SerializeName implements ISerializeName {

	private String name = "";
	
	private String description = "";
		
	public String getName() {
		return name;
	}

	public void saveFromXML() throws FileNotFoundException {
		XStream xstream = new XStream(new DomDriver()); 
		FileOutputStream out = new FileOutputStream("serial.xml");
		xstream.toXML(this, out);
	}

	public void loadFromXML() throws FileNotFoundException {
		try {
		XStream xstream = new XStream(new DomDriver()); 
		FileInputStream in = new FileInputStream("serial.xml");
		SerializeName temp = (SerializeName)xstream.fromXML(in);
		this.setName(temp.getName());
		this.setDescription(temp.getDescription());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setName(String pName) {
		this.name = pName; 
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String pDescription) {
		this.description = pDescription;
	}
	
	public String toString() {
		return name + " " + description;
	}
}
