package eclipse.plugin.logexample.views;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import eclipse.plugin.logexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class LogView extends ViewPart {

	public LogView() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new FillLayout());
		Button myCurrentButton = new Button(parent, SWT.FLAT);
		myCurrentButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Activator.getDefault().getLog().log(
						new Status(IStatus.INFO, Activator.PLUGIN_ID, 0,
								"Action sur le Bouton a l'instant : "
										+ System.currentTimeMillis(), null));
			}
		});
		myCurrentButton.setText("Action to Log");
	}

	public void setFocus() {
	}
}