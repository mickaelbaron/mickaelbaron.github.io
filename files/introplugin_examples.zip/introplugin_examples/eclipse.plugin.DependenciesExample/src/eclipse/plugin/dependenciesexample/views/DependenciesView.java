package eclipse.plugin.dependenciesexample.views;

import java.io.FileNotFoundException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import eclipse.plugin.exportexample.Activator;
import eclipse.plugin.exportexample.ISerializeName;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class DependenciesView extends ViewPart {

	private ISerializeName currentSerializeFactory;

	public DependenciesView() {
		currentSerializeFactory = Activator.getDefault().getSerializeInstance();
	}

	public void createPartControl(Composite parent) {
		// Le nom
		parent.setLayout(new GridLayout(2, false));
		Label myNameLabel = new Label(parent, SWT.NONE);
		myNameLabel.setText("Nom");
		final Text myNameText = new Text(parent, SWT.BORDER);
		GridData myGD = new GridData(GridData.FILL_HORIZONTAL);
		myNameText.setLayoutData(myGD);
		
		// La description
		final Text myFillText = new Text(parent, SWT.BORDER | SWT.WRAP);
		myGD = new GridData(GridData.FILL_BOTH);
		myGD.horizontalSpan = 2;
		myFillText.setLayoutData(myGD);
		
		Composite actionComposite = new Composite(parent, SWT.NONE);
		actionComposite.setLayout(new GridLayout(2, false));
		Button myLoadAction = new Button(actionComposite, SWT.FLAT);
		myLoadAction.setText("Chargement");
		myLoadAction.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				try {
					currentSerializeFactory.loadFromXML();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				myNameText.setText(currentSerializeFactory.getName());
				myFillText.setText(currentSerializeFactory.getDescription());
			}			
		});
		myGD = new GridData(GridData.FILL_HORIZONTAL);
		myLoadAction.setLayoutData(myGD);
		
		Button mySaveAction = new Button(actionComposite, SWT.FLAT);
		mySaveAction.setText("Sauvegarde");
		mySaveAction.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				currentSerializeFactory.setName(myNameText.getText());
				currentSerializeFactory.setDescription(myFillText.getText());
				try {
					currentSerializeFactory.saveFromXML();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
			}	
		});
		myGD = new GridData(GridData.FILL_HORIZONTAL);
		mySaveAction.setLayoutData(myGD);
		
		myGD = new GridData(GridData.FILL_HORIZONTAL);
		myGD.horizontalSpan = 2;
		actionComposite.setLayoutData(myGD);
	}

	public void setFocus() {
	}
}