package eclipse.plugin.platformosexample.views;

import org.eclipse.core.runtime.Platform;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2008
 */
public class PlatformOS extends ViewPart {

	public PlatformOS() {
	}

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, true));
		Button myOSInformation = new Button(parent, SWT.NONE);
		myOSInformation.setText("Informations sur l'OS");
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		myOSInformation.setLayoutData(gd);

		final Text myText = new Text(parent, SWT.WRAP);
		gd = new GridData(GridData.FILL_BOTH);
		myText.setLayoutData(gd);

		myOSInformation.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				myText.append(Platform.getNL() + "\n");
				myText.append(Platform.getOS() + "\n");
				myText.append(Platform.getOSArch() + "\n");
				myText.append(Platform.getWS() + "\n");
				myText.append("Repertoire utilisateur : "
						+ Platform.getUserLocation().getURL().toString());
				myText.append("Repertoire d'installation : "
						+ Platform.getInstallLocation().getURL().toString());
				myText.append("Repertoire du workspace : "
						+ Platform.getInstanceLocation().getURL().toString());
			}
		});
	}

	public void setFocus() {
	}
}