package eclipse.swt.TransformExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Pattern;
import org.eclipse.swt.graphics.Transform;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class ReflectionExample {
	private static final String IMAGE_FILE = "/images/logo.bmp";

	public static void main(String... args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell(display, SWT.SHELL_TRIM);

		final Image image = new Image(display, ReflectionExample.class
				.getResourceAsStream(IMAGE_FILE));

		shell.setText("Reflection");
		shell.setSize(300, 200);
		shell.setLayout(new FillLayout());

		Canvas baseCanvas = new Canvas(shell, SWT.DOUBLE_BUFFERED);
		baseCanvas.addPaintListener(new PaintListener() {

			public void paintControl(PaintEvent e) {
				Pattern pattern = new Pattern(display, 0, 0, 0, e.height,
						display.getSystemColor(SWT.COLOR_GRAY), display
								.getSystemColor(SWT.COLOR_BLACK));

				e.gc.setBackgroundPattern(pattern);
				e.gc.fillRectangle(e.x, e.y, e.width, e.height);
				int posX = (e.width - image.getImageData().width) / 2;
				int posY = 10;
				e.gc.drawImage(image, posX, posY);
				Transform transform = new Transform(e.gc.getDevice());
				int primaryHeight = image.getImageData().height + 10;
				transform.setElements(1, 0, 0, -.5f, 0, primaryHeight
						+ (primaryHeight / 2));

				e.gc.setAlpha(100);
				e.gc.setTransform(transform);
				e.gc.drawImage(image, posX, posY);

				transform.dispose();
				pattern.dispose();
			}
		});

		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
}
