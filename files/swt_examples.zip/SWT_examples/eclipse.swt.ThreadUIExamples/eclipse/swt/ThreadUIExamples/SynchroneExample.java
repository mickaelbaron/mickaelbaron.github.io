package eclipse.swt.ThreadUIExamples;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class SynchroneExample {

	private Timer t;

	public SynchroneExample() {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		shell.setText("SynchroneExample");
		Button myButton = new Button(shell, SWT.FLAT);
		myButton.setText("Go");

		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				if (t != null) {
					t.cancel();
				}

				t = new Timer();
				t.schedule(new TimerTask() {
					int nbrRepetitions = 3;

					public void run() {
						if (nbrRepetitions > 0) {
							System.out.println("Ca bosse dur!");
							nbrRepetitions--;
							display.syncExec(new Runnable() {
								public void run() {
									MessageBox d = new MessageBox(shell,
											SWT.YES);
									d.setText("Mon Titre");
									d.setMessage("Mon message qui bloque tout");
									d.open();
								}
							});
							System.out.println("Ici");
						} else {
							System.out.println("Terminé!");
							t.cancel();
						}
					}
				}, 0, 1 * 1000);
			}
		});

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new SynchroneExample();
	}
}
