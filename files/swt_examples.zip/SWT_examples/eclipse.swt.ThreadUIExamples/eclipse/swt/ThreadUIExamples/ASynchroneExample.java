package eclipse.swt.ThreadUIExamples;

import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;

/**
 * Copyright (C) 2007 Mickaël BARON
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 * 
 * @author Mickaël BARON (baron.mickael@gmail.com)
 */
public class ASynchroneExample {

	private Timer t;

	public ASynchroneExample() {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		shell.setText("ASynchroneExample");
		Button myButton = new Button(shell, SWT.FLAT);

		final ProgressBar myProgressBar = new ProgressBar(shell, SWT.NONE);
		myProgressBar.setMaximum(100);
		myProgressBar.setMinimum(0);
		myProgressBar.setSelection(100);

		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				if (t != null) {
					t.cancel();
				}

				t = new Timer();
				t.schedule(new TimerTask() {
					int nbrRepetitions = 100;

					public void run() {
						display.asyncExec(new Runnable() {
							public void run() {
								myProgressBar.setSelection(nbrRepetitions);
							}
						});

						if (nbrRepetitions > 0) {
							nbrRepetitions--;
						} else {
							System.out.println("Terminé");
							t.cancel();
						}
					}
				}, 0, 1 * 10);
			}
		});
		myButton.setText("Go");

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new ASynchroneExample();
	}
}
