package eclipse.swt.LayoutExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class StackLayoutExample {
	public StackLayoutExample() {
		Display display = new Display();
		final Shell shell = new Shell(display);
		final StackLayout stackLayout = new StackLayout();
		shell.setLayout(stackLayout);

		Button button1 = new Button(shell, SWT.PUSH);
		button1.setText("Button 1");

		final Button button2 = new Button(shell, SWT.PUSH);
		button2.setText("Button 2");

		button1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				stackLayout.topControl = button2;
				shell.redraw();
			}

		});

		stackLayout.topControl = button1;

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new StackLayoutExample();
	}
}
