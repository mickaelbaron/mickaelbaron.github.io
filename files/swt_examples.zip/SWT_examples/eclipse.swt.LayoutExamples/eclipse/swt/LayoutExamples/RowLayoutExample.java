package eclipse.swt.LayoutExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class RowLayoutExample {
	public RowLayoutExample() {
		Display display = new Display();
		Shell shell = new Shell(display);

		RowLayout myLayout = new RowLayout(SWT.HORIZONTAL);
		myLayout.justify = true;
		myLayout.pack = true;
		myLayout.wrap = true;
		myLayout.marginBottom = 150;
		shell.setLayout(myLayout);
		Button myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 1");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 2");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 3");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 4");
		myButton.setLayoutData(new RowData(100, 100));

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new RowLayoutExample();
	}
}
