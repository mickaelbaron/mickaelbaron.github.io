package eclipse.swt.LayoutExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class NullLayoutExample {
	public NullLayoutExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("NullLayoutExample");
		shell.setLayout(null);

		Button button = new Button(shell, SWT.PUSH);
		button.setText("Button 1");
		button.setBounds(0, 0, 250, 50);

		button = new Button(shell, SWT.FLAT);
		button.setText("Button 2");
		button.setBounds(0, 50, 250, 50);

		button = new Button(shell, SWT.FLAT);
		button.setText("Button 3");
		button.setBounds(0, 100, 250, 50);

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new NullLayoutExample();
	}
}
