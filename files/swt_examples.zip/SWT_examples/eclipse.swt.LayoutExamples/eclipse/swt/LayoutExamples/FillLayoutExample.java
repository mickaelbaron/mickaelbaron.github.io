package eclipse.swt.LayoutExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class FillLayoutExample {
	public FillLayoutExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Buttons Example");
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		Button myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 1");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 2");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 3");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 4");

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] args) {
		new FillLayoutExample();
	}
}
