package eclipse.swt.LayoutExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class FormLayoutExample2 {
	public FormLayoutExample2() {
		Display display = new Display();
		Shell shell = new Shell(display);
		FormLayout formLayout = new FormLayout();
		shell.setLayout(formLayout);
		FormData formData = new FormData();
		formData.height = 120;
		formData.width = 120;
		formData.left = new FormAttachment(0, 20);
		formData.right = new FormAttachment(100, -20);
		formData.top = new FormAttachment(0, 20);
		formData.bottom = new FormAttachment(100, -20);

		Button button = new Button(shell, SWT.PUSH);
		button.setLayoutData(formData);
		button.setText("Button 1");

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new FormLayoutExample2();
	}
}
