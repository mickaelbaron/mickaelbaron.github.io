package eclipse.swt.LayoutExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class GridLayoutExample {
	public GridLayoutExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		GridLayout myLayout = new GridLayout(3, true);
		myLayout.numColumns = 3;
		shell.setLayout(myLayout);
		Button myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 1");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 2");
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 3");
		GridData myData = new GridData(GridData.FILL_BOTH);
		myData.horizontalSpan = 3;
		myButton = new Button(shell, SWT.NONE);
		myButton.setText("Bouton 4");
		myButton.setLayoutData(myData);

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] agrv) {
		new GridLayoutExample();
	}
}
