package eclipse.swt.LayoutExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class FormLayoutExample3 {
	public FormLayoutExample3() {
		Display display = new Display();
		Shell shell = new Shell(display);
		FormLayout formLayout = new FormLayout();
		shell.setLayout(formLayout);

		Button button1 = new Button(shell, SWT.PUSH);
		button1.setText("Button 1");

		Button button2 = new Button(shell, SWT.PUSH);
		button2.setText("Button 2");

		FormData formData = new FormData();
		formData.left = new FormAttachment(0, 20);
		formData.right = new FormAttachment(100, -20);
		formData.top = new FormAttachment(0, 20);
		formData.bottom = new FormAttachment(button2, 0, SWT.TOP);
		button1.setLayoutData(formData);

		formData = new FormData();
		formData.left = new FormAttachment(0, 20);
		formData.right = new FormAttachment(100, -20);
		formData.bottom = new FormAttachment(100, -20);
		formData.top = new FormAttachment(1, 2, 0);
		button2.setLayoutData(formData);

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new FormLayoutExample3();
	}
}
