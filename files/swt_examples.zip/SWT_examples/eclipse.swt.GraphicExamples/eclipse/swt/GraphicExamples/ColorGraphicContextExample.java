package eclipse.swt.GraphicExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class ColorGraphicContextExample {
	public ColorGraphicContextExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		Canvas myCanvas = new Canvas(shell, SWT.NONE);
		shell.setText("ColorGraphicContextExample");
		myCanvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent event) {
				Color myColor = new Color(Display.getDefault(), new RGB(200,
						212, 123));
				event.gc.setBackground(myColor);
				event.gc.setAlpha(100);
				event.gc.fillRectangle(0, 0, 200, 200);
				event.gc.setForeground(Display.getDefault().getSystemColor(
						SWT.COLOR_BLUE));
				event.gc.drawText("Message à afficher", 20, 20, true);
				myColor.dispose();
			}
		});

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new ColorGraphicContextExample();
	}
}
