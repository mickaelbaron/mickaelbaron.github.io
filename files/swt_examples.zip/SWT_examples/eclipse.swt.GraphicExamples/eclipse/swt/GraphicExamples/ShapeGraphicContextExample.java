package eclipse.swt.GraphicExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class ShapeGraphicContextExample {
	public ShapeGraphicContextExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		Canvas myCanvas = new Canvas(shell, SWT.NONE);
		shell.setText("ShapeGraphicContextExample");
		myCanvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent event) {
				event.gc.setForeground(Display.getDefault().getSystemColor(SWT.COLOR_BLUE));
				event.gc.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_CYAN));
				event.gc.drawRectangle(0, 0, 150, 100);
				
				event.gc.setLineStyle(SWT.LINE_DASHDOT);
				event.gc.setLineWidth(20);				
				event.gc.drawOval(10, 10, 160, 110);
				
				event.gc.setAlpha(150);
				event.gc.fillRectangle(20, 20, 250, 150);
			}
		});
				
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new ShapeGraphicContextExample();
	}
}
