package eclipse.swt.GraphicExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class ImagaDataAlphaColorExample {
	private Image image;

	public ImagaDataAlphaColorExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new FillLayout());
		shell.setText("ImagaDataAlphaColorExample");
		ImageData data = new ImageData("images/example.jpg");
		for (int i = 0; i < data.width; i++) {
			for (int j = 0; j < data.height; j++) {
				data.setPixel(i, j, (data.getPixel(i, j) + 110) % 255);
				data.setAlpha(i, j, (data.height - j) % 254);
			}
		}
		image = new Image(display, data);
		new Label(shell, SWT.NONE).setImage(image);

		shell.setSize(430, 200);
		shell.open();
		// textUser.forceFocus();

		// Set up the event loop.
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				// If no more entries in event queue
				display.sleep();
			}
		}

		display.dispose();
	}

	public static void main(String[] args) {
		new ImagaDataAlphaColorExample();
	}
}
