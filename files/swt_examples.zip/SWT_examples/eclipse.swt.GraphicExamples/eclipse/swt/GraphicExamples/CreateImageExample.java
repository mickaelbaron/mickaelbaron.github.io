package eclipse.swt.GraphicExamples;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class CreateImageExample {
	public CreateImageExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));

		shell.setText("CreateImageExample");
		Image image1 = new Image(Display.getDefault(), "D:/Documents Mickey/Java/eclipse.swt.GraphicExamples/images/example.jpg");

		Image image2 = null;
		try {
			image2 = new Image(Display.getDefault(), new FileInputStream("D:/Documents Mickey/Java/eclipse.swt.GraphicExamples/images/example.jpg"));
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		}

		Image image3 = new Image(Display.getDefault(), CreateImageExample.class.getResourceAsStream("/images/example.jpg"));

		new Label(shell, SWT.NONE).setImage(image1);
		new Label(shell, SWT.NONE).setImage(image2);
		new Label(shell, SWT.NONE).setImage(image3);
		
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] argv) {
		new CreateImageExample();
	}
}
