package eclipse.swt.GraphicExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class TextSizeGraphicContextExample {
	private final String maChaine = "Voici un texte \nutilisé par deux \t\tméthodes";

	public TextSizeGraphicContextExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		Canvas myCanvas = new Canvas(shell, SWT.NONE);
		shell.setText("TextSizeGraphicContextExample");
		myCanvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent event) {
				event.gc.setForeground(Display.getDefault().getSystemColor(
						SWT.COLOR_BLUE));
				event.gc.drawString(maChaine, 0, 20);
				event.gc.drawText(maChaine, 0, 40, SWT.DRAW_MNEMONIC
						| SWT.DRAW_TAB | SWT.DRAW_DELIMITER);

				Point maChainePoint = event.gc.textExtent(maChaine);
				event.gc.setForeground(Display.getDefault().getSystemColor(
						SWT.COLOR_BLACK));
				event.gc.drawRectangle(0, 40, maChainePoint.x, maChainePoint.y);
			}
		});

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new TextSizeGraphicContextExample();
	}
}
