package eclipse.swt.GraphicExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class CopyImageExample {

	public CopyImageExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));
		shell.setText("CopyImageExample");
		final Image image = new Image(Display.getDefault(), CreateImageExample.class.getResourceAsStream("/images/example.jpg"));
		
		Image copyImage = new Image(Display.getDefault(), image, SWT.IMAGE_COPY);
				
		Image disableImage = new Image(Display.getDefault(), image, SWT.IMAGE_DISABLE);

		Image grayImage = new Image(Display.getDefault(), image, SWT.IMAGE_GRAY);
				
		
		new Label(shell, SWT.NONE).setImage(copyImage);
		new Label(shell, SWT.NONE).setImage(disableImage);
		new Label(shell, SWT.NONE).setImage(grayImage);
		
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] argv) {
		new CopyImageExample();
	}
}
