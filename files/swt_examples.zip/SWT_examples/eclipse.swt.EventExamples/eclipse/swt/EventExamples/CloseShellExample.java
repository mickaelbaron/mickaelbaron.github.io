package eclipse.swt.EventExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class CloseShellExample {
	public CloseShellExample() {
		Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setLayout(new FillLayout());
		shell.setText("CloseShellExample");
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent event) {
				event.doit = false;
			}
		});

		Button myButton = new Button(shell, SWT.FLAT);
		myButton.setText("Une fenêtre qui ne se ferme pas comme d'habitude");
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				shell.dispose();
			}
		});

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new CloseShellExample();
	}
}
