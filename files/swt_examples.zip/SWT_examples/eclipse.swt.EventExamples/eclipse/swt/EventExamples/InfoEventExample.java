package eclipse.swt.EventExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class InfoEventExample {
	public InfoEventExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Buttons Example");
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		Button myButton = new Button(shell, SWT.FLAT);
		myButton.setText("Click To Get Event Info");
		myButton.addListener(SWT.MouseDoubleClick, new Listener() {
			public void handleEvent(Event event) {
				System.out.println("Type de l'événement : " + event.type);
				((Button)event.widget).setText("DoubleClick");
				System.out.println("Date de déclenchement : " + event.time);
				System.out.println("Position x et y : " + event.x + " / " + event.y);
				System.out.println("Quel bouton ? : " + event.button);
			}			
		});
		
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] args) {
		new InfoEventExample();
	}
}
