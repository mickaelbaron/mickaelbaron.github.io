package eclipse.swt.EventExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class CompteurWithEvent {
	private int i = 0;
	private Label myLabel;

	public CompteurWithEvent() {
		Display display = new Display();
		Shell myShell = new Shell(display);
		myShell.setText("Compteur");
		myShell.setLayout(new FillLayout(SWT.VERTICAL));
		Button myButton = new Button(myShell, SWT.NONE);
		myButton.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				i++;
				myLabel.setText("i = " + i);
			}
		});
		myButton.setText("i->i+1");
		myLabel = new Label(myShell, SWT.CENTER);
		myLabel.setText("i = 0");
	}

	public static void main(String args[]) {
		new CompteurWithEvent();
	}
}