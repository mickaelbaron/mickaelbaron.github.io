package eclipse.swt.DialogExamples;

import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class DirectoryDialogExample {
	public DirectoryDialogExample(Shell shell) {
		DirectoryDialog mb = new DirectoryDialog(shell);
		mb.setText("Choisir un r�pertoire");
		mb.setMessage("Veuillez s�lectioner un répertoire");
		String value = mb.open();
		System.out.println(value);
	}
}
