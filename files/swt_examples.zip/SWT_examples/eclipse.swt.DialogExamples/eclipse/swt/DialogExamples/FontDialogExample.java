package eclipse.swt.DialogExamples;

import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.widgets.FontDialog;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class FontDialogExample {
	public FontDialogExample(Shell shell) {
		FontDialog mb = new FontDialog(shell);
		mb.setText("Choisir une fonte");
		FontData value = mb.open();
		System.out.println(value.getName());
	}
}
