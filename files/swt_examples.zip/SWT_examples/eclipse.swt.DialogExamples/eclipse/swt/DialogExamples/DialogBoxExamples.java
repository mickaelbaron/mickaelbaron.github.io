package eclipse.swt.DialogExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class DialogBoxExamples {
	public DialogBoxExamples() {
		Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(3, true));

		Button button = new Button(shell, SWT.PUSH);
		button.setText("Message");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				new MessageDialogExample(shell);
			}
		});

		button = new Button(shell, SWT.PUSH);
		button.setText("Couleur");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				new ColorDialogExample(shell, event);
			}
		});

		button = new Button(shell, SWT.PUSH);
		button.setText("Répertoire");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				new DirectoryDialogExample(shell);
			}
		});

		button = new Button(shell, SWT.PUSH);
		button.setText("Fichier");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				new FileDialogExample(shell);
			}
		});

		button = new Button(shell, SWT.PUSH);
		button.setText("Sélection de fonte");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				new FontDialogExample(shell);
			}
		});

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new DialogBoxExamples();
	}
}
