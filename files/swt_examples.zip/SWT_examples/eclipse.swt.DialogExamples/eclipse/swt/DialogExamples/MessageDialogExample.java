package eclipse.swt.DialogExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class MessageDialogExample {
	public MessageDialogExample(Shell shell) {
		MessageBox mb = new MessageBox(shell, SWT.ICON_QUESTION
				| SWT.YES | SWT.NO | SWT.CANCEL);
		mb.setMessage("Voulez-vous apprendre SWT?");
		mb.setText("Question a 2 sous");
		int value = mb.open();
		if (value == SWT.YES) {
			System.out.println("Yes");
		} else if (value == SWT.NO) {
			System.out.println("No");
		} else {
			System.out.println("Cancel");
		}
	}
}
