package eclipse.swt.DialogExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class FileDialogExample {
	public FileDialogExample(Shell shell) {
		FileDialog mb = new FileDialog(shell, SWT.OPEN);
		mb.setFilterNames(new String[] { "Image BMP (*.bmp)",
				"Image JPG (*.jpg)" });

		mb.setFilterExtensions(new String[] { "*.bmp", "*.jpg" });

		mb.setText("Choisir un fichier");
		String value = mb.open();
		System.out.println(value);
	}
}
