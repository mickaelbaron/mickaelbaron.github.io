package eclipse.swt.DialogExamples;

import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class ColorDialogExample {
	public ColorDialogExample(Shell shell, SelectionEvent event) {
		ColorDialog mb = new ColorDialog(shell);
		mb.setText("Choisir une couleur");
		RGB value = mb.open();
		Color colorBackGround = new Color(shell.getDisplay(), value);
		((Button) event.getSource()).setBackground(colorBackGround);
		colorBackGround.dispose();
	}
}
