package eclipse.swt.SWTAndSwingExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class SWTAWTExample {
	public SWTAWTExample() {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		GridLayout layout = new GridLayout(1, false);
		shell.setLayout(layout);
		shell.setText("SWT and Swing/AWT Example");
		Label separator1 = new Label(shell, SWT.NONE);
		separator1.setText("Mon Message en SWT");

		Composite awtComp = new Composite(shell, SWT.EMBEDDED);
		GridData myGridData = new GridData(GridData.FILL_BOTH);
		awtComp.setLayoutData(myGridData);
		java.awt.Frame awtFrame = SWT_AWT.new_Frame(awtComp);

		final java.awt.TextField textField = new java.awt.TextField();
		awtFrame.add(textField);
		textField.setText("Saisir une valeur dans du Swing");

		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] argv) {
		new SWTAWTExample();
	}
}
