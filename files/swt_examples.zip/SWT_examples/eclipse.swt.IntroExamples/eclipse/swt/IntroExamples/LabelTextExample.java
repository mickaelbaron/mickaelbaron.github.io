package eclipse.swt.IntroExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class LabelTextExample {
	public LabelTextExample() {
		Display display = new Display ();
		Shell shell = new Shell (display);
		shell.setText("Label & Text Example");
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		Label myLabel = new Label(shell, SWT.BORDER);
		myLabel.setText("Message");
		Text myText = new Text(shell, SWT.BORDER | SWT.MULTI);
		myText.setText("Coucou");
		
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] args) {
		new LabelTextExample();
	}
}
