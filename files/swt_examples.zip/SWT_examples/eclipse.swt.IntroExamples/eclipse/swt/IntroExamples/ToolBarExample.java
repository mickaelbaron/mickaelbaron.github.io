package eclipse.swt.IntroExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class ToolBarExample {
	public ToolBarExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("ToolBar");
		ToolBar bar = new ToolBar(shell, SWT.HORIZONTAL);
		ToolItem item = new ToolItem(bar, SWT.PUSH);
		item.setText("Item 1");
		Button myButton = new Button(bar, SWT.NONE);
		myButton.setText("Ici");
		item = new ToolItem(bar, SWT.SEPARATOR);
		myButton.pack();
		item.setWidth(myButton.getSize().x);
		item.setControl(myButton);
		bar.pack();
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	
	public static void main(String[] args) {
		new ToolBarExample();
	}
}