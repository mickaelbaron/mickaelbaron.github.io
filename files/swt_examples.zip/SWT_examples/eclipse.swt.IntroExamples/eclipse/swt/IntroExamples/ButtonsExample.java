package eclipse.swt.IntroExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class ButtonsExample {
	public ButtonsExample() {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Buttons Example");
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		Button myButton = new Button(shell, SWT.PUSH);
		myButton.setText("Push Me");
		myButton = new Button(shell, SWT.CHECK);
		myButton.setText("Check Me");
		myButton = new Button(shell, SWT.RADIO);
		myButton.setText("Radio Me");
		myButton = new Button(shell, SWT.RADIO);
		myButton.setText("Radio Me");
		myButton = new Button(shell, SWT.TOGGLE);
		myButton.setText("Select Me");
		myButton = new Button(shell, SWT.ARROW);
		myButton.setText("Turn Me");

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] args) {
		new ButtonsExample();
	}
}
