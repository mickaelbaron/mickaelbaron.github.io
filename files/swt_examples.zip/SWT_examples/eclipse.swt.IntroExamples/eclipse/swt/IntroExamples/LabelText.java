package eclipse.swt.IntroExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class LabelText extends Composite {
	public LabelText(Composite parent, String label, String textf) {
		super(parent, SWT.NONE);
		GridLayout myGL = new GridLayout(2, false);
		this.setLayout(myGL);
		Label myLabel = new Label(this, SWT.NONE);
		myLabel.setText(label);
		Text myText = new Text(this, SWT.BORDER);
		myText.setText(textf);
		GridData myGD = new GridData(GridData.FILL_BOTH);
		myText.setLayoutData(myGD);
	}
}
