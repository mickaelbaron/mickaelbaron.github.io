package eclipse.swt.IntroExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class CompositeWidgets extends Composite {
	public CompositeWidgets(Composite parent, String label, String textf) {
		super(parent, SWT.NONE);

		GridLayout myGL = new GridLayout(2, false);
		this.setLayout(myGL);
		Label myLabel = new Label(this, SWT.NONE);
		myLabel.setText(label);
		Text myText = new Text(this, SWT.BORDER);
		myText.setText(textf);
		GridData myGD = new GridData(GridData.FILL_BOTH);
		myText.setLayoutData(myGD);
	}

	public static void main(String[] argv) {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new FillLayout(SWT.VERTICAL));
		new CompositeWidgets(shell, "Saisissez le nom", "");

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
