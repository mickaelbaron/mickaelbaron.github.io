package eclipse.swt.IntroExamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class CompteurLayout {
	public CompteurLayout() {
		Display display = new Display();
		Shell myShell = new Shell(display);
		myShell.setText("Compteur");
		myShell.setLayout(new RowLayout(SWT.VERTICAL));
		Button myButton = new Button(myShell, SWT.NONE);
		myButton.setText("i->i+1");
		Label myLabel = new Label(myShell, SWT.CENTER);
		myLabel.setText("i = 0");
		myShell.pack();
		myShell.open();
		while (!myShell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String args[]) {
		new CompteurLayout();
	}
}