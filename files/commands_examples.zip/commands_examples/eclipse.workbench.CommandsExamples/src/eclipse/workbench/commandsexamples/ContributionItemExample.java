package eclipse.workbench.commandsexamples;

import org.eclipse.jface.action.IContributionItem;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.CompoundContributionItem;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class ContributionItemExample extends CompoundContributionItem {

	@Override
	protected IContributionItem[] getContributionItems() {
		IContributionItem[] tab = new IContributionItem[2];

		CommandContributionItemParameter commandParameter = new CommandContributionItemParameter(
				PlatformUI.getWorkbench(), "contributionfirstitem",
				"eclipse.workbench.commandsexample.firstcommand",
				CommandContributionItem.STYLE_PUSH);
		IContributionItem ref = new CommandContributionItem(commandParameter);
		tab[0] = ref;
		
		commandParameter = new CommandContributionItemParameter(
				PlatformUI.getWorkbench(), "contributionseconditem",
				"eclipse.workbench.commandsexample.secondcommand",
				CommandContributionItem.STYLE_PUSH);
		ref = new CommandContributionItem(commandParameter);
		tab[1] = ref;
		
		return tab;
	}
}
