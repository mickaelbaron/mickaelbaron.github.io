package eclipse.workbench.commandsexamples.views;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.Category;
import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IExecutionListener;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.NotHandledException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class ViewCommandPart extends ViewPart {

	public ViewCommandPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		ICommandService cs = (ICommandService) PlatformUI.getWorkbench()
				.getService(ICommandService.class);
		final Category category = cs
				.getCategory("eclipse.workbench.commandsexample.commandscategory");

		Command thirdCommand = cs
				.getCommand("eclipse.workbench.commandsexample.thirdcommand");
		thirdCommand.define("Third Command", "", category);
		thirdCommand.addExecutionListener(new IExecutionListener() {

			@Override
			public void notHandled(String commandId,
					NotHandledException exception) {
				System.out.println(".notHandled()");
			}

			@Override
			public void postExecuteFailure(String commandId,
					ExecutionException exception) {
				System.out.println(".postExecuteFailure()");
			}

			@Override
			public void postExecuteSuccess(String commandId, Object returnValue) {
				System.out.println(".postExecuteSuccess()");
			}

			@Override
			public void preExecute(String commandId, ExecutionEvent event) {
				System.out.println(".preExecute()");
			}

		});

		IHandlerService handlerService = (IHandlerService) PlatformUI
				.getWorkbench().getService(IHandlerService.class);
		IHandler handler = new AbstractHandler() {
			public Object execute(ExecutionEvent event)
					throws ExecutionException {
				MessageDialog.openInformation(Display.getDefault()
						.getActiveShell(), "CommandsExamples Plug-in",
						"Hello, Eclipse world with Third Handler");
				return null;
			}
		};
		handlerService.activateHandler("eclipse.workbench.commandsexample.thirdcommand", handler);

		parent.setLayout(new GridLayout(1, true));

		Button callCommand = new Button(parent, SWT.PUSH);
		callCommand.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {
					executeCommand();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		callCommand.setText("Call Third Command");

		cs.addExecutionListener(new IExecutionListener() {

			@Override
			public void notHandled(String commandId,
					NotHandledException exception) {
				System.out.println(".notHandled()");
			}

			@Override
			public void postExecuteFailure(String commandId,
					ExecutionException exception) {
				System.out.println(".postExecuteFailure()");
			}

			@Override
			public void postExecuteSuccess(String commandId, Object returnValue) {
				System.out.println(".postExecuteSuccess() : " + commandId);
			}

			@Override
			public void preExecute(String commandId, ExecutionEvent event) {
				System.out.println(".preExecute()");
			}

		});
	}

	@Override
	public void setFocus() {
	}

	private void executeCommand() throws Exception {
		IHandlerService handlerservice = (IHandlerService) PlatformUI
				.getWorkbench().getService(IHandlerService.class);

		handlerservice.executeCommand(
				"eclipse.workbench.commandsexample.thirdcommand", null);
	}

}
