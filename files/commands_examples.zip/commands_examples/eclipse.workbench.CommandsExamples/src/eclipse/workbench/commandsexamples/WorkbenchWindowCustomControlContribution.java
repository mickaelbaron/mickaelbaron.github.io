package eclipse.workbench.commandsexamples;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.menus.WorkbenchWindowControlContribution;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class WorkbenchWindowCustomControlContribution extends
		WorkbenchWindowControlContribution {

	@Override
	protected Control createControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout(2, false);
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		composite.setLayout(layout);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		final Label label = new Label(composite, SWT.NONE);
		label.setText("Click");

		Button button = new Button(composite, SWT.PUSH);
		button.setText("Call");
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IHandlerService hs = (IHandlerService)PlatformUI.getWorkbench().getService(IHandlerService.class);
				try {
					hs.executeCommand("eclipse.workbench.commandsexample.firstcommand", null);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		return composite;
	}
}
