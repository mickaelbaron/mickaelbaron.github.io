package eclipse.workbench.commandsexamples.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class SecondHandler extends AbstractHandler implements IHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		MessageDialog.openInformation(Display.getDefault().getActiveShell(),
				"CommandsExamples Plug-in","Hello, Eclipse world with Second Handler");
		return "";
	}
}
