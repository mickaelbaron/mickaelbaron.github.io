package eclipse.workbench.commandsexpressionsvariableexamples;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.ui.AbstractSourceProvider;
import org.eclipse.ui.ISources;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class AnimationSourceProvider extends AbstractSourceProvider {

	public final static String ANIMATION_STATE = "eclipse.workbench.CommandsExpressionsVariableExamples.animation";
	
	private final static String MENU_STATE = "menu";
	
	private final static String TOOLBAR_STATE = "toolbar";
	
	private final static String TOOLBAR_VIEW_STATE = "toolbarview";

	/**
	 * 0 = Menu, 1 = toolbar, 2 = toolbarview.
	 */
	private int state;
	
	public AnimationSourceProvider() {
		state = 0;
	}

	@Override
	public Map<String, String> getCurrentState() {
		Map<String, String> currentState = new HashMap<String, String>(1);
		if (state == 0) {
			currentState.put(ANIMATION_STATE, MENU_STATE);
		} else if (state == 1) {
			currentState.put(ANIMATION_STATE, TOOLBAR_STATE);
		} else {
			currentState.put(ANIMATION_STATE, TOOLBAR_VIEW_STATE);			
		}
        return currentState; 
	}

	@Override
	public String[] getProvidedSourceNames() {
		return new String[] {ANIMATION_STATE}; 
	}

	public void setState(int pValue) {
		if (this.state == pValue) {
			return;
		}
		this.state = pValue;
		
		String currentState = "";
		if (state == 0) {
			currentState =  MENU_STATE;
		} else if (state == 1) {
			currentState = TOOLBAR_STATE;
		} else {
			currentState = TOOLBAR_VIEW_STATE;			
		}
		fireSourceChanged(ISources.WORKBENCH, ANIMATION_STATE, currentState); 
	}

	@Override
	public void dispose() {
	}
}
