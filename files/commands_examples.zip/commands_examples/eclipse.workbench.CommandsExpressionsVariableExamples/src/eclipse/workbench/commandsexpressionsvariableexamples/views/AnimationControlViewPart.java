package eclipse.workbench.commandsexpressionsvariableexamples.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.ui.services.ISourceProviderService;

import eclipse.workbench.commandsexpressionsvariableexamples.AnimationSourceProvider;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class AnimationControlViewPart extends ViewPart {

	public AnimationControlViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(3,true));
		
		// Get the service
		ISourceProviderService spc = (ISourceProviderService) PlatformUI.getWorkbench().getService(ISourceProviderService.class);
		// Get our source provider by querying by the variable name
		final AnimationSourceProvider myPro = (AnimationSourceProvider) spc.getSourceProvider(AnimationSourceProvider.ANIMATION_STATE);
				
		Button menu = new Button(parent, SWT.FLAT);
		menu.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				myPro.setState(0); 
			}			
		});
		menu.setLayoutData(new GridData(GridData.FILL_BOTH));
		menu.setText("Menu");
		
		Button toolbar = new Button(parent, SWT.FLAT);
		toolbar.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				myPro.setState(1); 
			}			
		});
		toolbar.setLayoutData(new GridData(GridData.FILL_BOTH));
		toolbar.setText("Toolbar");
		
		Button view = new Button(parent, SWT.FLAT);
		view.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				myPro.setState(2); 
			}			
		});
		view.setLayoutData(new GridData(GridData.FILL_BOTH));
		view.setText("ToolbarView");
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
	}
}
