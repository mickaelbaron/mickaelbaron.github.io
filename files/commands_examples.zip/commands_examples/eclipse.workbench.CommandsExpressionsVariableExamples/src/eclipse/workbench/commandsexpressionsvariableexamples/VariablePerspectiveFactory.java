package eclipse.workbench.commandsexpressionsvariableexamples;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class VariablePerspectiveFactory implements IPerspectiveFactory {

	@Override
	public void createInitialLayout(IPageLayout layout) {
		layout.setEditorAreaVisible(false);
		layout.addView("eclipse.workbench.commandsexpressionsvariableexamples.animationcontrolid", IPageLayout.LEFT, 1.0f, layout.getEditorArea());
	}
}
