package eclipse.workbench.actionsexamples.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class HelloWorldViewAction implements IViewActionDelegate {

	private IViewPart view;

	public HelloWorldViewAction() {
	}

	@Override
	public void init(IViewPart view) {
		this.view = view;
	}

	@Override
	public void run(IAction action) {
		MessageDialog.openInformation(view.getSite().getShell(),
				"ActionsExamples Plug-in", "Hello, Eclipse world from View");
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
	}
}
