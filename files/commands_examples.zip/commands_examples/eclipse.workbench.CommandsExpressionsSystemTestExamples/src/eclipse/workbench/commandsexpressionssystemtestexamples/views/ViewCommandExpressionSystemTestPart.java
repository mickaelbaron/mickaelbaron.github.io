package eclipse.workbench.commandsexpressionssystemtestexamples.views;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class ViewCommandExpressionSystemTestPart extends ViewPart {

	public ViewCommandExpressionSystemTestPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
	}

	@Override
	public void setFocus() {
	}
}
