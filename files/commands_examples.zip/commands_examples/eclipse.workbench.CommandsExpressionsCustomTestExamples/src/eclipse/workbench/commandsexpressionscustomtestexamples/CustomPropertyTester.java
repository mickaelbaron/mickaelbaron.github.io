package eclipse.workbench.commandsexpressionscustomtestexamples;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.jface.text.TextSelection;
import org.eclipse.jface.viewers.ISelection;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class CustomPropertyTester extends PropertyTester {

	public CustomPropertyTester() {
	}

	@Override
	public boolean test(Object receiver, String property, Object[] args,
			Object expectedValue) {
		ISelection selection = (ISelection) receiver;

		if ("isAllLetters".equals(property)) {
			if (selection instanceof TextSelection) {
				TextSelection ts = (TextSelection) selection;
				String text = (String) ts.getText();

				if (text == null || text.length() == 0) {
					return false;
				}
				for (Character ch : text.toCharArray())
					if (!Character.isLetter(ch)) {
						return false;
					}
				return true;
			}
		}
		
		if ("isAllDigits".equals(property)) {
			if (selection instanceof TextSelection) {
				TextSelection ts = (TextSelection) selection;
				String text = (String) ts.getText();

				if (text == null || text.length() == 0) {
					return false;
				}
				for (Character ch : text.toCharArray())
					if (!Character.isDigit(ch)) {
						return false;
					}
				return true;
			}
		}
		return false;
	}
}
