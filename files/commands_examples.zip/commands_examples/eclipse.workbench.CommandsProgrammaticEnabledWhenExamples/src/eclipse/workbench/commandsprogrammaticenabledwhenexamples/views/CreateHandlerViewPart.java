package eclipse.workbench.commandsprogrammaticenabledwhenexamples.views;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.expressions.EvaluationResult;
import org.eclipse.core.expressions.Expression;
import org.eclipse.core.expressions.ExpressionInfo;
import org.eclipse.core.expressions.IEvaluationContext;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class CreateHandlerViewPart extends ViewPart {

	private boolean isEnabled = true;
	
	public CreateHandlerViewPart() {
	}
	
	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(2, true));
		GridData myData = new GridData(GridData.FILL_BOTH);
		myData.horizontalSpan = 2;
		
		final Button createButton = new Button(parent, SWT.NONE);
		createButton.setText("Create");
		createButton.setLayoutData(myData);
		
		createButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IHandlerService hs = (IHandlerService) PlatformUI.getWorkbench().getService(IHandlerService.class);
				IHandler handler = new AbstractHandler() {
					@Override
					public Object execute(ExecutionEvent event) throws ExecutionException {
						MessageDialog.openInformation(Display.getDefault().getActiveShell(), "CommandsExamples Plug-in", "Hello, Eclipse world with Third Handler");

						return null;
					}		
				};
				
				Expression enabledWhen = new Expression() {
					@Override
					public void collectExpressionInfo(ExpressionInfo info) {
						info.markDefaultVariableAccessed();
					}

					public EvaluationResult evaluate(IEvaluationContext context)
							throws CoreException {
						context.getVariable("selection");
						if (isEnabled) 
							return EvaluationResult.TRUE;
						else
							return EvaluationResult.FALSE;
					}
					
					
				};
				
				hs.activateHandler("eclipse.workbench.commandsprogrammaticenabledwhenexamples.helloworldcommandid", handler,enabledWhen);	
				createButton.setEnabled(false);
			}			
		});

		myData = new GridData(GridData.FILL_BOTH);
 
		Button disabledHandler = new Button(parent, SWT.NONE);
		disabledHandler.setText("Disabled");
		disabledHandler.setLayoutData(myData);
		disabledHandler.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				isEnabled = false;				
			}
		});
		
		Button enabledHandler = new Button(parent, SWT.NONE);
		enabledHandler.setText("Enabled");
		enabledHandler.setLayoutData(myData);
		enabledHandler.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				isEnabled = true;
			}
		});
		
	}

	@Override
	public void setFocus() {
	}
}
