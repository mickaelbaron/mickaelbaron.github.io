package eclipse.workbench.commandsparametersexamples.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class OpenDialogValuesHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		String openDialogParameter = event.getParameter("eclipse.workbench.commandsparametersexamples.opendialogvaluesparameterid");
		
		MessageDialog.openInformation(Display.getDefault().getActiveShell(),
				"CommandsParametersExamples Plug-in","opendialogvaluesparameterid parameter value : " + openDialogParameter);
		
	    return null; 		
	}

}
