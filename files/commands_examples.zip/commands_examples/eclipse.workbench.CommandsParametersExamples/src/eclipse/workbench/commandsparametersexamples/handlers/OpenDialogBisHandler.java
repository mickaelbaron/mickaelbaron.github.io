package eclipse.workbench.commandsparametersexamples.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class OpenDialogBisHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		String openDialogBisParameterOne = event
				.getParameter("eclipse.workbench.commandsparametersexamples.opendialogbisparameteroneid");
		String openDialogBisParameterTwo = event
				.getParameter("eclipse.workbench.commandsparametersexamples.opendialogbisparametertwoid");

		MessageDialog.openInformation(Display.getDefault().getActiveShell(),
				"CommandsParametersExamples Plug-in",
				"opendialogbisparameteroneid : " + openDialogBisParameterOne
						+ "opendialogbisparametertwoid : "
						+ openDialogBisParameterTwo);

		return null;
	}
}
