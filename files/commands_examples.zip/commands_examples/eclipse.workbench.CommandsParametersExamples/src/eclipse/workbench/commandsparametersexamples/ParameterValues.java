package eclipse.workbench.commandsparametersexamples;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.commands.IParameterValues;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
public class ParameterValues implements IParameterValues {

	@Override
	public Map<String, String> getParameterValues() {
		Map<String, String> params = new HashMap<String, String>();
		
        params.put("toolbar", "In Toolbar");
        params.put("menu", "In Menu");
 
        return params; 
	}

}
