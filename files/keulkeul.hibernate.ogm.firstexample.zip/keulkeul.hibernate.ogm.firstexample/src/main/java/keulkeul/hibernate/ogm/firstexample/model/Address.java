package keulkeul.hibernate.ogm.firstexample.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2011
 */
@Entity
public class Address {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "RID", nullable = false)
	private Long id;

	private String description;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
