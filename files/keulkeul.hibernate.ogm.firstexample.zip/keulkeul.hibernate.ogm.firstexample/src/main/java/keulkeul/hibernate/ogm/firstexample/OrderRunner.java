package keulkeul.hibernate.ogm.firstexample;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.TransactionManager;

import keulkeul.hibernate.ogm.firstexample.model.Address;
import keulkeul.hibernate.ogm.firstexample.model.Category;
import keulkeul.hibernate.ogm.firstexample.model.Order;
import keulkeul.hibernate.ogm.firstexample.model.Product;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.SessionFactoryObserver;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.ogm.metadata.GridMetadataManager;
import org.hibernate.ogm.metadata.GridMetadataManagerHelper;
import org.hibernate.transaction.JBossTSStandaloneTransactionManagerLookup;
import org.infinispan.Cache;
import org.infinispan.atomic.AtomicHashMap;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2011
 */
public class OrderRunner {

	/**
	 * @param args
	 * @throws SystemException 
	 * @throws NotSupportedException 
	 * @throws HeuristicRollbackException 
	 * @throws HeuristicMixedException 
	 * @throws RollbackException 
	 * @throws IllegalStateException 
	 * @throws SecurityException 
	 */
	public static void main(String[] args) throws NotSupportedException, SystemException, SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException {
		// Accessing JBoss's Transaction can be done differently but this one
		// works nicely
		TransactionManager tm = new JBossTSStandaloneTransactionManagerLookup()
				.getTransactionManager(null);

		// Build the EntityManagerFactory as you would build in in Hibernate
		// Core
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("org.hibernate.ogm.tutorial.jpa");

		// Persist entities the way you are used to in plain JPA
		tm.begin();
		EntityManager em = emf.createEntityManager();
		Address compagny = new Address();
		compagny.setDescription("This is Address");
		em.persist(compagny);

		Category category = new Category();
		category.setDescription("Multimedia");
		em.persist(category);

		Product product1 = new Product();
		product1.setDescription("TV");
		product1.setCategory(category);
		em.persist(product1);

		Product product2 = new Product();
		product2.setDescription("Moto");
		product2.setCategory(category);
		em.persist(product2);

		Order myOrder = new Order();
		myOrder.setDeliveryAddress(compagny);
		List<Product> products = new ArrayList<Product>();
		products.add(product1);
		products.add(product2);
		myOrder.setProducts(products);
		em.persist(myOrder);

		em.flush();
		em.close();
		tm.commit();

		// Retrieve your entities the way you are used to in plain JPA
		tm.begin();
		em = emf.createEntityManager();
		product1 = em.find(Product.class, product1.getId());
		System.out.println(product1.getId());
		product2 = em.find(Product.class, product2.getId());
		System.out.println(product2.getId());
		myOrder = em.find(Order.class, myOrder.getId());
		System.out.println(myOrder.getId());
		compagny = em.find(Address.class, compagny.getId());
		System.out.println(compagny.getId());
		category = em.find(Category.class, category.getId());
		System.out.println(category.getId());

		Cache entityCache = getEntityCache(em.unwrap(Session.class));
		Set keySet = entityCache.keySet();
		for (Object object : keySet) {
			System.out.println(displayValue(entityCache, object));
		}

		em.flush();
		em.close();
		tm.rollback();

		emf.close();
	}

	public static Cache getEntityCache(Session session) {
		final SessionFactoryObserver observer = getObserver(session
				.getSessionFactory());
		return ((GridMetadataManager) observer).getCacheContainer().getCache(
				GridMetadataManagerHelper.ENTITY_CACHE);
	}

	private static SessionFactoryObserver getObserver(SessionFactory factory) {
		final SessionFactoryObserver observer = ((SessionFactoryImplementor) factory)
				.getFactoryObserver();
		if (observer == null) {
			throw new RuntimeException(
					"Wrong OGM configuration: observer not set");
		}
		return observer;
	}

	private static String displayValue(Cache currentCache, Object key) {
		String returnValue = key + " value";

		Object value = currentCache.get(key);

		if (value instanceof AtomicHashMap) {
			AtomicHashMap infinispanCache = (AtomicHashMap) value;

			returnValue += "{";
			Set keySet = infinispanCache.keySet();
			for (Object object : keySet) {
				returnValue += object + "=" + infinispanCache.get(object) + ",";
			}
			returnValue = returnValue.substring(0, returnValue.length() - 1);
			returnValue += "}";
		} else {
			returnValue += value;
		}

		return returnValue;
	}

}
