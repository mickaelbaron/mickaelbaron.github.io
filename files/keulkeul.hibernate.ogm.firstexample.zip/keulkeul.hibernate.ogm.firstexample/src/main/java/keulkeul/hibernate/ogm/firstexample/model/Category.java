package keulkeul.hibernate.ogm.firstexample.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2011
 */
@Entity
public class Category {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "RID", nullable = false)
    private Long id;
	
	@OneToMany(mappedBy = "category")
	private List<Product> products;

	private String description;
	
	public Category() {
		products = new ArrayList<Product>();
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}	
}
