package keulkeul.hibernate.ogm.firstexample.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2011
 */
@Entity
public class Order {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "RID", nullable = false)
    private Long id;

	@OneToOne
	@JoinColumn(name = "address_fk", nullable = false)
	private Address deliveryAddress;
	
	@OneToMany
	@JoinTable(name = "t_order_product", joinColumns = {@JoinColumn(name="order_fk")},
		inverseJoinColumns = {@JoinColumn(name = "products_fk")})
	private List<Product> products;
	
	public Address getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(Address deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
}
