package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.IDetailsPage;
import org.eclipse.ui.forms.IFormPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;
import org.eclipse.ui.forms.widgets.TableWrapData;
import org.eclipse.ui.forms.widgets.TableWrapLayout;

import eclipse.workbench.eclipseformsexample.data.TablePerson;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class MyDetailsPage implements IDetailsPage {

	private TablePerson input;

	private IManagedForm mform;

	private Text[] tabText;

	private TableViewer ref;
	
	private Button flag;
	
	public MyDetailsPage(TableViewer pRef) {
		this.ref = pRef;
	}
	
	@Override
	public void createContents(Composite parent) {
		TableWrapLayout layout = new TableWrapLayout();
		layout.topMargin = 5;
		layout.leftMargin = 5;
		layout.rightMargin = 2;
		layout.bottomMargin = 2;
		parent.setLayout(layout);

		FormToolkit toolkit = mform.getToolkit();
		Section s1 = toolkit.createSection(parent, Section.DESCRIPTION
				| Section.TITLE_BAR);
		s1.marginWidth = 10;
		s1.setText("Person Edit Details");
		s1.setDescription("Set the properties of the selected Person object.");

		TableWrapData td = new TableWrapData(TableWrapData.FILL,
				TableWrapData.TOP);
		td.grabHorizontal = true;
		s1.setLayoutData(td);
		Composite client = toolkit.createComposite(s1);
		GridLayout glayout = new GridLayout();
		glayout.marginWidth = glayout.marginHeight = 0;
		glayout.numColumns = 2;
		glayout.verticalSpacing = 5;
		client.setLayout(glayout);

		tabText = new Text[4];

		tabText[0] = addNewLabelText(client, "Name", new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				input.setName(tabText[0].getText());
				ref.refresh(input);
			}
		});
		
		tabText[1] = addNewLabelText(client, "FirstName", new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				input.setFirstName(tabText[1].getText());
				ref.refresh(input);
			}
		});

		tabText[2] = addNewLabelText(client, "SportName", new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				input.setSportName(tabText[2].getText());
				ref.refresh(input);
			}
		});

		tabText[3] = addNewLabelText(client, "Old", new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				input.setOld(Integer.parseInt(tabText[3].getText()));
				ref.refresh(input);
			}
		});

		flag = toolkit.createButton(client, "Is Vegetarian", SWT.CHECK);
		flag.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				input.setVegetarian(flag.getSelection());
				ref.refresh(input);
			}
		});
		GridData gd = new GridData();
		gd.horizontalSpan = 2;
		flag.setLayoutData(gd);

		toolkit.paintBordersFor(s1);
		s1.setClient(client);
	}

	private Text addNewLabelText(Composite client, String name,
			ModifyListener ref) {
		FormToolkit toolkit = mform.getToolkit();
		toolkit.createLabel(client, name);
		Text text = toolkit.createText(client, "", SWT.SINGLE); //$NON-NLS-1$
		text.addModifyListener(ref);

		GridData gd = new GridData(GridData.FILL_HORIZONTAL
				| GridData.VERTICAL_ALIGN_BEGINNING);
		gd.widthHint = 10;
		text.setLayoutData(gd);

		createSpacer(toolkit, client, 10);
		return text;
	}

	private void createSpacer(FormToolkit toolkit, Composite parent, int span) {
		Label spacer = toolkit.createLabel(parent, ""); //$NON-NLS-1$
		GridData gd = new GridData();
		gd.horizontalSpan = span;
		spacer.setLayoutData(gd);
	}
	
	private void update() {
		tabText[0].setText(input.getName());
		tabText[1].setText(input.getFirstName());
		tabText[2].setText(input.getSportName());
		tabText[3].setText(Integer.toString(input.getOld()));
		flag.setSelection(input.isVegetarian());
	}

	@Override
	public void commit(boolean onSave) {
	}

	@Override
	public void dispose() {
	}

	@Override
	public void initialize(IManagedForm form) {
		System.out.println("MyDetailPage.initialize()");
		this.mform = form;
	}

	@Override
	public boolean isDirty() {
		return false;
	}

	@Override
	public boolean isStale() {
		return false;
	}

	@Override
	public void refresh() {
	}

	@Override
	public void setFocus() {
	}

	@Override
	public boolean setFormInput(Object input) {
		return false;
	}

	@Override
	public void selectionChanged(IFormPart part, ISelection selection) {
		System.out.println(part);
		IStructuredSelection ssel = (IStructuredSelection) selection;
		if (ssel.size() == 1) {
			input = (TablePerson) ssel.getFirstElement();
		} else {
			input = null;
		}
		
		update();
	}
}
