package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.ManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class MasterDetailsBlockPart extends ViewPart {

	public MasterDetailsBlockPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("MasterDetails block Example");
		toolkit.decorateFormHeading(form.getForm());
		
		MyMasterDetailsBlock refMasterDetailsBlock = new MyMasterDetailsBlock();
		ManagedForm refManagedForm = new ManagedForm(toolkit, form);
		refMasterDetailsBlock.createContent(refManagedForm);
	}

	@Override
	public void setFocus() {
	}
}
