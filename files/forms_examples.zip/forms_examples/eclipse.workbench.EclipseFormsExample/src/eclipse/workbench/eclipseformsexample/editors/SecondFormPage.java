package eclipse.workbench.eclipseformsexample.editors;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.editor.FormPage;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class SecondFormPage extends FormPage {
	
	public SecondFormPage(FormEditor f) {
		super(f, "second","SecondPage");
	}

	@Override
	protected void createFormContent(IManagedForm managedForm) {
		FormToolkit toolkit = managedForm.getToolkit();
		
		final ScrolledForm form = managedForm.getForm();
		form.setText("Second Page Content");
		toolkit.decorateFormHeading(form.getForm());
		
		GridLayout layout = new GridLayout();
		layout.numColumns = 1;
		form.getBody().setLayout(layout);
		
		// Button component with push style.
		toolkit.createButton(form.getBody(), "Eclipse Form Button", SWT.PUSH);
	}	
}
