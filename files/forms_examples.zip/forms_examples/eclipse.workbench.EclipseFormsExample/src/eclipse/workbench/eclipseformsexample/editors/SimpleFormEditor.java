package eclipse.workbench.eclipseformsexample.editors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.editor.FormEditor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class SimpleFormEditor extends FormEditor {

	public SimpleFormEditor() {
	}

	@Override
	protected void addPages() {
		try {
			this.addPage(new FirstFormPage(this));
			this.addPage(new SecondFormPage(this));
		} catch (PartInitException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
	}

	@Override
	public void doSaveAs() {
	}

	@Override
	public boolean isSaveAsAllowed() {
		return false;
	}
}
