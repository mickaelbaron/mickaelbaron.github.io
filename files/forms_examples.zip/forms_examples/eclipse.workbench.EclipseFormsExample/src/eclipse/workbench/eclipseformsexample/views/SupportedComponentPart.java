package eclipse.workbench.eclipseformsexample.views;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.BaseLabelProvider;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Hyperlink;
import org.eclipse.ui.forms.widgets.ImageHyperlink;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.ViewPart;

import eclipse.workbench.eclipseformsexample.Activator;
import eclipse.workbench.eclipseformsexample.data.Job;
import eclipse.workbench.eclipseformsexample.data.TablePerson;
import eclipse.workbench.eclipseformsexample.data.TreePerson;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class SupportedComponentPart extends ViewPart {

	public SupportedComponentPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		
		ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("All Eclipse Form Supported Components");
		toolkit.decorateFormHeading(form.getForm());
				
		GridLayout layout = new GridLayout();
		layout.numColumns = 1;
		form.getBody().setLayout(layout);		

		// Button component with push style.
		toolkit.createButton(form.getBody(), "Eclipse Form Button", SWT.PUSH);
		
		// Hyperlink component.
		Hyperlink createHyperlink = toolkit.createHyperlink(form.getBody(), "Eclipse Hyperlink", SWT.WRAP);
		createHyperlink.setText("Eclipse Form Hyperlink");
		
		// ImageHyperlink component.
		ImageHyperlink createImageHyperlink = toolkit.createImageHyperlink(form.getBody(), SWT.WRAP);
		createImageHyperlink.setText("Eclipse Form ImageHyperlink");
		createImageHyperlink.setImage(Activator.getDefault().getImageRegistry().get(Activator.ECLIPSE_LOGO));
		
		// Label component.
		toolkit.createLabel(form.getBody(), "Eclipse Form Label");
	
		// Text component.
		toolkit.createText(form.getBody(), "Eclipse Form Text", SWT.BORDER);
		
		// Table component.
		Table createTable = toolkit.createTable(form.getBody(), SWT.FULL_SELECTION);
		createTableViewer(createTable);

		// Tree component.
	    Tree myTree = toolkit.createTree(form.getBody(), SWT.FULL_SELECTION);
		createTreeViewer(myTree);	 
	}

	private void createTreeViewer(Tree myTree) {
		final TreeViewer treeViewer = new TreeViewer(myTree);
		treeViewer.setContentProvider(new MyTreeContentProvider());
		treeViewer.setLabelProvider(new MyTreeLabelProvider());

		List<Job> myPersonWork = new ArrayList<Job>();

		Job currentWork = new Job("Informaticien");
		currentWork.addTreePerson(new TreePerson("Robert Glan", "Nancy", "25", "Voiture", "1600"));
		currentWork.addTreePerson(new TreePerson("John Rambo", "Limoges", "35", "Train", "1900"));
		currentWork.addTreePerson(new TreePerson("Antoine Ronba", "Niort", "40", "Avion", "5000"));
		myPersonWork.add(currentWork);
		
		currentWork = new Job("Medecin");
		currentWork.addTreePerson(new TreePerson("Jean Dupont", "Tours", "39", "Train", "1200"));
		currentWork.addTreePerson(new TreePerson("Guy Fregatte", "La Rochelle", "35", "Bateau", "2000"));
		currentWork.addTreePerson(new TreePerson("Olivier Huile", "Nantes", "45", "Avion", "12000"));
		currentWork.addTreePerson(new TreePerson("Tony Presson", "Paris", "43", "Cheval", "2000"));
		currentWork.addTreePerson(new TreePerson("Jean Mange", "Paris", "29", "Voiture", "9000"));
		myPersonWork.add(currentWork);
		
		Tree tree = treeViewer.getTree();
		tree.setLayoutData(new GridData(GridData.FILL_BOTH));
		treeViewer.setInput(myPersonWork);


		tree.setLinesVisible(true);
		treeViewer.expandAll();
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

	private void createTableViewer(Table createTable) {
		final TableViewer viewer = new TableViewer(createTable);
		viewer.setUseHashlookup(true);
		viewer.setContentProvider(new MyStructuredContentProvider());		
		viewer.setLabelProvider(new MyTableLabelProvider());
		
		ArrayList<TablePerson> myPersonList = new ArrayList<TablePerson>();
		myPersonList.add(new TablePerson("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new TablePerson("Motte","John", "Football", 15, false));
		myPersonList.add(new TablePerson("Pratdut","B�atrice", "Basketball", 25, true));
		myPersonList.add(new TablePerson("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new TablePerson("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new TablePerson("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new TablePerson("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new TablePerson("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new TablePerson("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new TablePerson("Rioux","Ren�", "Rugby", 61, false));
		myPersonList.add(new TablePerson("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new TablePerson("Motte","John", "Football", 15, false));
		myPersonList.add(new TablePerson("Pratdut","B�atrice", "Basketball", 25, true));
		myPersonList.add(new TablePerson("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new TablePerson("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new TablePerson("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new TablePerson("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new TablePerson("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new TablePerson("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new TablePerson("Rioux","Ren�", "Rugby", 61, false));
		
		viewer.setInput(myPersonList);

		Table table = viewer.getTable();
	    table.setLayoutData(new GridData(GridData.FILL_BOTH));
	    
	    new TableColumn(table, SWT.CENTER).setText("Nom");   
	    new TableColumn(table, SWT.CENTER).setText("Pr�nom");
	    new TableColumn(table, SWT.CENTER).setText("Sport");
	    new TableColumn(table, SWT.CENTER).setText("Age");
	    new TableColumn(table, SWT.CENTER).setText("V�g�tarien");
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	}
	
	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<TablePerson> localInputElement = (ArrayList<TablePerson>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
	
	static class MyTableLabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			TablePerson currentPerson = (TablePerson)element;
			switch(columnIndex) {
			case 0 : return currentPerson.getName();
			case 1 : return currentPerson.getFirstName();
			case 2 : return currentPerson.getSportName();
			case 3 : return Integer.toString(currentPerson.getOld());
			case 4 : return Boolean.toString(currentPerson.isVegetarian());
			default : return "";
			}
		}

		public void addListener(ILabelProviderListener listener) {
		}

		public void dispose() {
		}

		public boolean isLabelProperty(Object element, String property) {
			return false;
		}

		public void removeListener(ILabelProviderListener listener) {
		}
	}
	
	static class MyTreeLabelProvider extends BaseLabelProvider implements ILabelProvider {

		public Image getImage(Object element) {
			return null;
		}

		public String getText(Object element) {
			if (element instanceof TreePerson) {
				TreePerson current = (TreePerson)element;
				return current.getName();
			} else {
				return element.toString();					
			}
		}		
	}
	
	static class MyTreeContentProvider implements ITreeContentProvider {

		@SuppressWarnings("unchecked")
		public Object[] getElements(Object element) {
			final Object[] currentPersonWorks = ((List<Job>) element)
					.toArray();
			return currentPersonWorks;
		}

		public void dispose() {
		}

		public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		}

		public Object[] getChildren(Object element) {
			final Job currentPersonWork = (Job) element;
			return currentPersonWork.getTreePersons().toArray();
		}

		public Object getParent(Object element) {
			if (element instanceof TreePerson) {
				return ((TreePerson)element).getParent();
			} else {
				return null;
			}
		}

		public boolean hasChildren(Object element) {
			if (element instanceof Job) {
				Job current = (Job) element;
				return !current.isTreePersonEmpty();
			} else {
				return false;
			}
		}
	}
}
