package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IFormColors;
import org.eclipse.ui.forms.events.HyperlinkAdapter;
import org.eclipse.ui.forms.events.HyperlinkEvent;
import org.eclipse.ui.forms.widgets.FormText;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.TableWrapLayout;
import org.eclipse.ui.part.ViewPart;

import eclipse.workbench.eclipseformsexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class FormTextPart extends ViewPart {

	public FormTextPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("FormText Component");

		toolkit.decorateFormHeading(form.getForm());
		TableWrapLayout layout = new TableWrapLayout();
		form.getBody().setLayout(layout);

		StringBuffer buf = new StringBuffer();
		buf.append("<form>");
		buf.append("<p>");
		buf.append("Here is some plain text for the text to render; ");
		buf.append("this text is at <a href=\"http://www.eclipse.org\" "
				+ "nowrap=\"true\">http://www.eclipse.org</a> web site.");
		buf.append("</p>");
		buf.append("<p>");
		buf.append("<span color=\"header\" font=\"header\">"
				+ "This text is in header font and color.</span>");
		buf.append("</p>");
		buf.append("<p>This line will contain some <b>bold</b> and "
				+ "some <span font=\"code\">source</span> text. ");
		buf.append("We can also add <img href=\"image\"/> an image. ");
		buf.append("</p>");
		buf.append("<li>A default (bulleted) list item.</li>");
		buf.append("<li>Another bullet list item.</li>");
		buf
				.append("<li style=\"text\" value=\"1.\">A list item with text.</li>");
		buf
				.append("<li style=\"text\" value=\"2.\">Another list item with text</li>");
		buf
				.append("<li style=\"image\" value=\"image\">List item with an image bullet</li>");
		buf
				.append("<li style=\"text\" bindent=\"20\" indent=\"40\" value=\"3.\">"
						+ "A list item with text.</li>");
		buf
				.append("<li style=\"text\" bindent=\"20\" indent=\"40\" value=\"4.\">"
						+ "A list item with text.</li>");
		buf.append("<p>     leading blanks;      more white \n\n new "
				+ "lines   <br/>  \n   more <b>   bb   </b>  white  . </p>");
		buf.append("</form>");
		
		FormText formText = toolkit.createFormText(form.getBody(), true);
		formText.setWhitespaceNormalized(false);

		formText.setImage("image", Activator.getDefault().getImageRegistry()
				.get(Activator.TINY_ECLIPSE_LOGO));
		formText.setColor("header", toolkit.getColors().getColor(
				IFormColors.TITLE));
		formText.setFont("header", JFaceResources.getHeaderFont());
		formText.setFont("code", JFaceResources.getTextFont());
		formText.setText(buf.toString(), true, false);
		
		formText.addHyperlinkListener(new HyperlinkAdapter() {
			public void linkActivated(HyperlinkEvent e) {
				System.out.println("Link active: " + e.getHref());
			}
		});
	}

	@Override
	public void setFocus() {
	}
}
