package eclipse.workbench.eclipseformsexample.editors;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.editor.FormPage;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class FirstFormPage extends FormPage {
	
	public FirstFormPage(FormEditor f) {
		super(f, "first","FirstPage");
	}

	@Override
	protected void createFormContent(IManagedForm managedForm) {
		FormToolkit toolkit = managedForm.getToolkit();
		
		final ScrolledForm form = managedForm.getForm();
		form.setText("First Page Content");
		toolkit.decorateFormHeading(form.getForm());
		
		GridLayout layout = new GridLayout();
		layout.numColumns = 1;
		form.getBody().setLayout(layout);
		
		// Label component.
		toolkit.createLabel(form.getBody(), "Eclipse Form Label");
	}	
}
