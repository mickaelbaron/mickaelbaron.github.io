package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.Section;
import org.eclipse.ui.forms.widgets.TableWrapData;
import org.eclipse.ui.forms.widgets.TableWrapLayout;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class SectionCompositePart extends ViewPart {

	public SectionCompositePart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		
		final ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("Section Composite Example");
		toolkit.decorateFormHeading(form.getForm());
		
		TableWrapLayout layout = new TableWrapLayout();
		form.getBody().setLayout(layout);

		Section section = toolkit.createSection(form.getBody(),
				Section.DESCRIPTION | Section.TITLE_BAR | Section.TWISTIE
						| Section.EXPANDED);
		TableWrapData td = new TableWrapData(TableWrapData.FILL_GRAB);
		section.setLayoutData(td);

		section.setText("Section title");
		section
				.setDescription("This is the description that goes below the title");

		Composite sectionClient = toolkit.createComposite(section);
		sectionClient.setLayout(new GridLayout());
		toolkit.createButton(sectionClient, "Radio 1", SWT.RADIO);
		toolkit.createButton(sectionClient, "Radio 2", SWT.RADIO);
		section.setClient(sectionClient);	
	}

	@Override
	public void setFocus() {
	}
}
