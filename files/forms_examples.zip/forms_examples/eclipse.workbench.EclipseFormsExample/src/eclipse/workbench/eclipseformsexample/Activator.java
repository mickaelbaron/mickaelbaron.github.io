package eclipse.workbench.eclipseformsexample;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class Activator extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "eclipse.workbench.EclipseFormsExample";

	// The shared instance
	private static Activator plugin;
	
	public static final String ECLIPSE_LOGO = "ECLIPSE_LOGO";
	
	public static final String TINY_ECLIPSE_LOGO = "TINY_ECLIPSE_LOGO";
	
	public static final String IMG_HORIZONTAL = "HORIZONTAL";

	public static final String IMG_VERTICAL = "VERTICAL";

	
	/**
	 * The constructor
	 */
	public Activator() {
	}

	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given
	 * plug-in relative path
	 *
	 * @param path the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}
	
	protected void initializeImageRegistry(ImageRegistry registry) {
		this.getImageRegistry().put(ECLIPSE_LOGO, Activator.getImageDescriptor("icons/logo.jpg"));
		this.getImageRegistry().put(TINY_ECLIPSE_LOGO, Activator.getImageDescriptor("icons/sample.gif"));
		this.getImageRegistry().put(IMG_HORIZONTAL, Activator.getImageDescriptor("icons/th_horizontal.gif"));
		this.getImageRegistry().put(IMG_VERTICAL, Activator.getImageDescriptor("icons/th_vertical.gif"));
	}
}
