package eclipse.workbench.eclipseformsexample.data;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class TablePerson {
	private String name;
	
	private String firstName;
	
	private String sportName;

	private int old;
	
	private boolean vegetarian;

	public TablePerson(String name, String firstName, String sportName, int years,
			boolean vegetarian) {
		super();
		this.name = name;
		this.firstName = firstName;
		this.sportName = sportName;
		this.old = years;
		this.vegetarian = vegetarian;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSportName() {
		return sportName;
	}

	public void setSportName(String sportName) {
		this.sportName = sportName;
	}

	public int getOld() {
		return old;
	}

	public void setOld(int years) {
		this.old = years;
	}

	public boolean isVegetarian() {
		return vegetarian;
	}

	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}
}
