package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.events.ExpansionAdapter;
import org.eclipse.ui.forms.events.ExpansionEvent;
import org.eclipse.ui.forms.widgets.ExpandableComposite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.TableWrapLayout;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class ExpandableCompositePart extends ViewPart {

	public ExpandableCompositePart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());

		final ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("Expandable Composite Example");
		toolkit.decorateFormHeading(form.getForm());
		
		TableWrapLayout layout = new TableWrapLayout();		
		form.getBody().setLayout(layout);

		ExpandableComposite ec = toolkit.createExpandableComposite(form
				.getBody(), ExpandableComposite.CLIENT_INDENT | ExpandableComposite.TWISTIE);
		ec.setText("This is the first Expandable composite title");		

		Composite expandableClient = toolkit.createComposite(ec);
		expandableClient.setLayout(new GridLayout());
		toolkit.createButton(expandableClient, "Radio 1", SWT.RADIO);
		toolkit.createButton(expandableClient, "Radio 2", SWT.RADIO);
		
		ec.setClient(expandableClient);
		ec.addExpansionListener(new ExpansionAdapter() {
			@Override
			public void expansionStateChanged(ExpansionEvent e) {
				form.reflow(true);
			}
		});
	}

	@Override
	public void setFocus() {
	}
}
