package eclipse.workbench.eclipseformsexample.views;

import java.util.ArrayList;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.forms.widgets.FormText;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.TableWrapLayout;
import org.eclipse.ui.part.ViewPart;

import eclipse.workbench.eclipseformsexample.data.TablePerson;
import eclipse.workbench.eclipseformsexample.views.SupportedComponentPart.MyStructuredContentProvider;
import eclipse.workbench.eclipseformsexample.views.SupportedComponentPart.MyTableLabelProvider;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class FormTextWithSWTControl extends ViewPart {

	public FormTextWithSWTControl() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("FormText Component with SWT Controls");

		toolkit.decorateFormHeading(form.getForm());
		TableWrapLayout layout = new TableWrapLayout();
		form.getBody().setLayout(layout);

		StringBuffer buf = new StringBuffer();
		buf.append("<form>");
		buf.append("<p>");
		buf.append("Here is some plain text for the text to render; ");
		buf.append("this text is at <a href=\"http://www.eclipse.org\" "
				+ "nowrap=\"true\">http://www.eclipse.org</a> web site."
				+ "<control href=\"mybutton\"/></p>");
		buf.append("<p><control href=\"mytable\"/>");		
		buf.append("</p>");
		buf.append("</form>");
		
		FormText formText = toolkit.createFormText(form.getBody(), true);
		formText.setWhitespaceNormalized(false);

		Button myButton = new Button(formText, SWT.FLAT);
		myButton.setText("Bonjour");
		formText.setControl("mybutton", myButton);
		
		Table createTable = toolkit.createTable(formText, SWT.FULL_SELECTION);
		createTableViewer(createTable);
		formText.setControl("mytable", createTable);
		
		formText.setText(buf.toString(), true, false);
		
	}
	
	private void createTableViewer(Table createTable) {
		final TableViewer viewer = new TableViewer(createTable);
		viewer.setUseHashlookup(true);
		viewer.setContentProvider(new MyStructuredContentProvider());		
		viewer.setLabelProvider(new MyTableLabelProvider());
		
		ArrayList<TablePerson> myPersonList = new ArrayList<TablePerson>();
		myPersonList.add(new TablePerson("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new TablePerson("Motte","John", "Football", 15, false));
		myPersonList.add(new TablePerson("Pratdut","B�atrice", "Basketball", 25, true));
		myPersonList.add(new TablePerson("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new TablePerson("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new TablePerson("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new TablePerson("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new TablePerson("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new TablePerson("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new TablePerson("Rioux","Ren�", "Rugby", 61, false));
		myPersonList.add(new TablePerson("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new TablePerson("Motte","John", "Football", 15, false));
		myPersonList.add(new TablePerson("Pratdut","B�atrice", "Basketball", 25, true));
		myPersonList.add(new TablePerson("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new TablePerson("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new TablePerson("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new TablePerson("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new TablePerson("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new TablePerson("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new TablePerson("Rioux","Ren�", "Rugby", 61, false));
		
		viewer.setInput(myPersonList);

		Table table = viewer.getTable();
	    
	    new TableColumn(table, SWT.CENTER).setText("Nom");   
	    new TableColumn(table, SWT.CENTER).setText("Pr�nom");
	    new TableColumn(table, SWT.CENTER).setText("Sport");
	    new TableColumn(table, SWT.CENTER).setText("Age");
	    new TableColumn(table, SWT.CENTER).setText("V�g�tarien");
	    
	    for (int i = 0, n = table.getColumnCount(); i < n; i++) {
	        table.getColumn(i).setWidth(100);
	      }	    
	    
	    table.setHeaderVisible(true);
	    table.setLinesVisible(true);
	    	    
	    viewer.refresh();
	}

	@Override
	public void setFocus() {
	}
}
