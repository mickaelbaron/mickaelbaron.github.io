package eclipse.workbench.eclipseformsexample;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class EclipseFormsPerspectiveFactory implements IPerspectiveFactory {

	@Override
	public void createInitialLayout(IPageLayout layout) {
		layout.setEditorAreaVisible(false);
		String editorArea = layout.getEditorArea();

		layout.addView("eclipse.workbench.eclipseformsexample.views.helloworldpartid", IPageLayout.LEFT, 0.5f, editorArea);
		layout.addView("eclipse.workbench.eclipseformsexample.views.nativeswtpartid", IPageLayout.RIGHT, 0.30f, "eclipse.workbench.eclipseformsexample.views.helloworldpartid");		
		layout.addView("eclipse.workbench.EclipseFormsExample.views.nonativeswtpartid", IPageLayout.RIGHT, 0.5f, "eclipse.workbench.eclipseformsexample.views.nativeswtpartid");
		layout.addView("eclipse.workbench.EclipseFormsExample.views.supportedcomponentsid", IPageLayout.BOTTOM, 0.30f, "eclipse.workbench.eclipseformsexample.views.helloworldpartid");
		layout.addView("eclipse.workbench.EclipseFormsExample.views.expandablecompositeid", IPageLayout.BOTTOM, 0.5f, "eclipse.workbench.eclipseformsexample.views.nativeswtpartid");
		layout.addView("eclipse.workbench.EclipseFormsExample.views.sectioncompositeid", IPageLayout.BOTTOM, 0.5f, "eclipse.workbench.EclipseFormsExample.views.nonativeswtpartid");
		layout.addView("eclipse.workbench.EclipseFormsExample.views.formtextid", IPageLayout.BOTTOM, 0.5f, "eclipse.workbench.EclipseFormsExample.views.supportedcomponentsid");
		layout.addView("eclipse.workbench.EclipseFormsExample.views.formcustomizationid", IPageLayout.BOTTOM, 0.5f, "eclipse.workbench.EclipseFormsExample.views.expandablecompositeid");
	}
}
