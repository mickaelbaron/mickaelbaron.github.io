package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.events.HyperlinkAdapter;
import org.eclipse.ui.forms.events.HyperlinkEvent;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.ViewPart;

import eclipse.workbench.eclipseformsexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class FormCustomizationPart extends ViewPart {

	public FormCustomizationPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		final ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("Form Customization");
		
		toolkit.decorateFormHeading(form.getForm());
		form.setHeadClient(toolkit.createButton(form.getForm().getHead(), "This is the head client", SWT.PUSH));
		form.setImage(Activator.getDefault().getImageRegistry().get(Activator.TINY_ECLIPSE_LOGO));
		form.getForm().getToolBarManager().add(new Action("ToolBar Action", Activator.getDefault().getImageRegistry().getDescriptor(Activator.TINY_ECLIPSE_LOGO)) { });
		form.getForm().getToolBarManager().update(true);
		form.getForm().setToolBarVerticalAlignment(SWT.TOP);
		
		form.getForm().getMenuManager().add(new Action("MenuBar Action", Activator.getDefault().getImageRegistry().getDescriptor(Activator.TINY_ECLIPSE_LOGO)) { });
		form.getForm().getMenuManager().update(true);
		form.getForm().addMessageHyperlinkListener(new HyperlinkAdapter() {

			@Override
			public void linkActivated(HyperlinkEvent e) {
				System.out.println("Link active : " + e.getLabel());
				form.getForm().setMessage(null);
			}
		});
		form.getForm().setMessage("This is an error message", IMessageProvider.WARNING);
	}

	@Override
	public void setFocus() {
	}
}
