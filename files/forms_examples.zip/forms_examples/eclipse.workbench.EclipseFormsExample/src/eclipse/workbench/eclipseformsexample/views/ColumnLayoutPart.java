package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.forms.widgets.ColumnLayout;
import org.eclipse.ui.forms.widgets.ColumnLayoutData;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class ColumnLayoutPart extends ViewPart {

	public ColumnLayoutPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());

		ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("TableWrapLayout Layout Example");
		toolkit.decorateFormHeading(form.getForm());

		ColumnLayout layout = new ColumnLayout();
		layout.minNumColumns = 1;
		layout.maxNumColumns = 2;
		form.getBody().setLayout(layout);

		Label label;
		ColumnLayoutData cld = new ColumnLayoutData();

		label = toolkit.createLabel(form.getBody(), "First Content used to demonstrate ColumnLayout", SWT.WRAP);
		label.setLayoutData(cld);

		label = toolkit.createLabel(form.getBody(),
				"Second Content used to demonstrate ColumnLayout", SWT.WRAP);
		label = toolkit
				.createLabel(form.getBody(), "Third Content used to demonstrate ColumnLayout", SWT.WRAP);
		cld = new ColumnLayoutData();
		label.setLayoutData(cld);
	}

	@Override
	public void setFocus() {
	}
}
