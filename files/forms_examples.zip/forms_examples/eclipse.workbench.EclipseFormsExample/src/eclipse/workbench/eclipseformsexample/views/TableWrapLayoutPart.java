package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.TableWrapData;
import org.eclipse.ui.forms.widgets.TableWrapLayout;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class TableWrapLayoutPart extends ViewPart {

	public TableWrapLayoutPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());

		ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("TableWrapLayout Layout Example");
		toolkit.decorateFormHeading(form.getForm());

		TableWrapLayout layout = new TableWrapLayout();
		layout.verticalSpacing = 25;
		form.getBody().setLayout(layout);

		layout.numColumns = 3;
		Label label;
		TableWrapData td;

		label = toolkit
				.createLabel(
						form.getBody(),
						"What happened? Remember that we are using GridLayout. When it asked the link control to compute its size, it gave it the size needed to render the text in one long line. Although we instructed the control to wrap, it did not matter because GridLayout requires that a control return its size in isolation. The link itself -- as well as other SWT controls like Label -- is capable of computing the height given its width if you pass the width instead of SWT.DEFAULT in computeSize, but GridLayout is not passing the width as an argument.",
						SWT.WRAP);
		td = new TableWrapData();
		td.colspan = 3;
		label.setLayoutData(td);
		
		label = toolkit.createLabel(form.getBody(),
				"Some text to put in the first column", SWT.WRAP);
		label = toolkit
				.createLabel(
						form.getBody(),
						"Some text to put in the second column and make it a bit "
								+ "longer so that we can see what happens with column "
								+ "distribution. This text must be the longest so that it can "
								+ "get more space allocated to the columns it belongs to.",
						SWT.WRAP);
		td = new TableWrapData();
		td.colspan = 2;
		label.setLayoutData(td);
		label = toolkit.createLabel(form.getBody(),
				"This text will span two rows and should not grow the column.",
				SWT.WRAP);
		td = new TableWrapData();
		td.rowspan = 2;
		label.setLayoutData(td);
		label = toolkit.createLabel(form.getBody(),
				"This text goes into column 2 and consumes only one cell",
				SWT.WRAP);
		label.setLayoutData(new TableWrapData(TableWrapData.FILL_GRAB));
		label = toolkit.createLabel(form.getBody(),
				"This text goes into column 3 and consumes only one cell too",
				SWT.WRAP);
		label.setLayoutData(new TableWrapData(TableWrapData.FILL_GRAB));
		label = toolkit.createLabel(form.getBody(),
				"This text goes into column 2 and consumes only one cell",
				SWT.WRAP);
		label.setLayoutData(new TableWrapData(TableWrapData.FILL_GRAB));
		label = toolkit.createLabel(form.getBody(),
				"This text goes into column 3 and consumes only one cell too",
				SWT.WRAP);
		label.setLayoutData(new TableWrapData(TableWrapData.FILL_GRAB));
	}

	@Override
	public void setFocus() {
	}
}
