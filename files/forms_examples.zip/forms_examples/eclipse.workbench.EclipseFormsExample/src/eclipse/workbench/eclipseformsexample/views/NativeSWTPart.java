package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class NativeSWTPart extends ViewPart {

	public NativeSWTPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());
		ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("Native SWT components with Eclipse Forms");
		toolkit.decorateFormHeading(form.getForm());
		
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		form.getBody().setLayout(layout);		
		
		Label label = new Label(form.getBody(), SWT.NULL);
		label.setText("Text field label : ");
		Text text = new Text(form.getBody(), SWT.BORDER);
		text.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		Button button = new Button(form.getBody(), SWT.CHECK);
		button.setText("A SWT natif checkbox component in a form");
		GridData gd = new GridData();
		gd.horizontalSpan = 2;
		button.setLayoutData(gd);
	}

	@Override
	public void setFocus() {
	}
}
