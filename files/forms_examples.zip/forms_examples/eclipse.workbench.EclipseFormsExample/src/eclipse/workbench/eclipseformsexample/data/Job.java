package eclipse.workbench.eclipseformsexample.data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class Job {
	
	private List<TreePerson> myTreePerson;

	private String job;

	public Job(String pMetier) {
		this.job = pMetier;
		myTreePerson = new ArrayList<TreePerson>();
	}

	public void addTreePerson(TreePerson pTreePerson) {
		myTreePerson.add(pTreePerson);
		pTreePerson.setParent(this);
	}

	public String getJob() {
		return job;
	}

	public List<TreePerson> getTreePersons() {
		return myTreePerson;
	}
	
	public String toString() {
		return job;
	}

	public boolean isTreePersonEmpty() {
		return myTreePerson.isEmpty();
	}
}
