package eclipse.workbench.eclipseformsexample.views;

import java.util.ArrayList;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.forms.DetailsPart;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.MasterDetailsBlock;
import org.eclipse.ui.forms.SectionPart;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.Section;

import eclipse.workbench.eclipseformsexample.Activator;
import eclipse.workbench.eclipseformsexample.data.TablePerson;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 * 
 * Original idea from http://www.eclipse.org/articles/Article-Forms/article.html
 */
public class MyMasterDetailsBlock extends MasterDetailsBlock {

	private TableViewer viewer;
	
	@Override
	protected void createMasterPart(final IManagedForm managedForm, Composite parent) {
		FormToolkit toolkit = managedForm.getToolkit();
		Section section = toolkit.createSection(parent, Section.DESCRIPTION | Section.TITLE_BAR);
		section.setText("Persons");
		section.setDescription("The list contains objects from the model whose details are editable on the right");
		section.marginWidth = 10;
		section.marginHeight = 5;
		
		Composite client = toolkit.createComposite(section, SWT.WRAP);
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		layout.marginWidth = 2;
		layout.marginHeight = 2;
		client.setLayout(layout);
		Table t = toolkit.createTable(client, SWT.FULL_SELECTION);
		GridData gd = new GridData(GridData.FILL_BOTH);
		gd.heightHint = 20;
		gd.widthHint = 100;
		t.setLayoutData(gd);
		toolkit.paintBordersFor(client);
		gd = new GridData(GridData.VERTICAL_ALIGN_BEGINNING);
		section.setClient(client);

		final SectionPart spart = new SectionPart(section);
		System.out.println(spart);
		managedForm.addPart(spart);
		
		viewer = new TableViewer(t);
		viewer.addSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				managedForm.fireSelectionChanged(spart, event.getSelection());
			}
		});
		viewer.setContentProvider(new MyStructuredContentProvider());
		viewer.setLabelProvider(new MyTableLabelProvider());
			    
		
		ArrayList<TablePerson> myPersonList = new ArrayList<TablePerson>();
		myPersonList.add(new TablePerson("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new TablePerson("Motte","John", "Football", 15, false));
		myPersonList.add(new TablePerson("Pratdut","B�atrice", "Basketball", 25, true));
		myPersonList.add(new TablePerson("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new TablePerson("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new TablePerson("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new TablePerson("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new TablePerson("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new TablePerson("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new TablePerson("Rioux","Ren�", "Rugby", 61, false));
		myPersonList.add(new TablePerson("Dupont","Sandrine", "Roller", 22, false));
		myPersonList.add(new TablePerson("Motte","John", "Football", 15, false));
		myPersonList.add(new TablePerson("Pratdut","B�atrice", "Basketball", 25, true));
		myPersonList.add(new TablePerson("Giphone","Harry", "Rugby", 35, false));
		myPersonList.add(new TablePerson("Garphine","Mohamed", "Football", 50, false));
		myPersonList.add(new TablePerson("Sume","Bruce", "Football", 31, false));
		myPersonList.add(new TablePerson("Chedantrou","Damien", "Football", 36, false));
		myPersonList.add(new TablePerson("Factions","Pauline", "Basketball", 15, false));
		myPersonList.add(new TablePerson("Pouillou","Laurent", "Rugby", 26, false));
		myPersonList.add(new TablePerson("Rioux","Ren�", "Rugby", 61, false));
		
		viewer.setInput(myPersonList);

		new TableColumn(t, SWT.CENTER).setText("Nom");   
		new TableColumn(t, SWT.CENTER).setText("Pr�nom");
		new TableColumn(t, SWT.CENTER).setText("Sport");
		new TableColumn(t, SWT.CENTER).setText("Age");
		new TableColumn(t, SWT.CENTER).setText("V�g�tarien");
		
	    for (int i = 0, n = t.getColumnCount(); i < n; i++) {
	        t.getColumn(i).setWidth(100);
	      }	    
	    
	    t.setHeaderVisible(true);
	    t.setLinesVisible(true);
	    	    
	    viewer.refresh();
	}

	@Override
	protected void createToolBarActions(IManagedForm managedForm) {
		final ScrolledForm form = managedForm.getForm();
		Action haction = new Action("hor", Action.AS_RADIO_BUTTON) {
			public void run() {
				sashForm.setOrientation(SWT.HORIZONTAL);
				form.reflow(true);
			}
		};
		haction.setChecked(true);
		haction.setToolTipText("Horizontal Orientation");
		haction.setImageDescriptor(Activator.getDefault().getImageRegistry().getDescriptor(Activator.IMG_HORIZONTAL));
		Action vaction = new Action("ver", Action.AS_RADIO_BUTTON) {
			public void run() {
				sashForm.setOrientation(SWT.VERTICAL);
				form.reflow(true);
			}
		};
		vaction.setChecked(false);
		vaction.setToolTipText("Vertical Orientation");
		vaction.setImageDescriptor(Activator.getDefault().getImageRegistry().getDescriptor(Activator.IMG_VERTICAL));
		form.getToolBarManager().add(haction);
		form.getToolBarManager().add(vaction);
	}

	@Override
	protected void registerPages(DetailsPart detailsPart) {
		detailsPart.registerPage(TablePerson.class, new MyDetailsPage(viewer));		
	}

	static class MyStructuredContentProvider implements IStructuredContentProvider {
		@SuppressWarnings("unchecked")
		public Object[] getElements(Object inputElement) {
			ArrayList<TablePerson> localInputElement = (ArrayList<TablePerson>)inputElement;				
			return localInputElement.toArray();
		}
		
		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput,
				Object newInput) {
		}	
	}
	
	static class MyTableLabelProvider implements ITableLabelProvider {
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		public String getColumnText(Object element, int columnIndex) {
			TablePerson currentPerson = (TablePerson)element;
			switch(columnIndex) {
			case 0 : return currentPerson.getName();
			case 1 : return currentPerson.getFirstName();
			case 2 : return currentPerson.getSportName();
			case 3 : return Integer.toString(currentPerson.getOld());
			case 4 : return Boolean.toString(currentPerson.isVegetarian());
			default : return "";
			}
		}

		public void addListener(ILabelProviderListener listener) {
		}

		public void dispose() {
		}

		public boolean isLabelProperty(Object element, String property) {
			return false;
		}

		public void removeListener(ILabelProviderListener listener) {
		}
	}
}
