package eclipse.workbench.eclipseformsexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.ScrolledPageBook;
import org.eclipse.ui.forms.widgets.TableWrapData;
import org.eclipse.ui.forms.widgets.TableWrapLayout;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : July 2010
 */
public class PageBookPart extends ViewPart {

	public PageBookPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		FormToolkit toolkit = new FormToolkit(parent.getDisplay());

		final ScrolledForm form = toolkit.createScrolledForm(parent);
		form.setText("PageBook Composite Example");
		toolkit.decorateFormHeading(form.getForm());

		TableWrapLayout layout = new TableWrapLayout();
		layout.numColumns = 2;
		layout.topMargin = 0;
		form.getBody().setLayout(layout);
		
		final ScrolledPageBook pageBook = toolkit.createPageBook(form.getBody(), SWT.BORDER);
		
		Composite page1 = pageBook.createPage("page 1");
		page1.setLayout(new GridLayout());
		Composite sectionClient1 = toolkit.createComposite(page1);
		sectionClient1.setLayout(new GridLayout());
		toolkit.createButton(sectionClient1, "Radio 1", SWT.RADIO);
		toolkit.createButton(sectionClient1, "Radio 2", SWT.RADIO);
		GridData layoutData = new GridData(GridData.FILL_BOTH);
		sectionClient1.setLayoutData(layoutData);

		final Composite page2 = pageBook.createPage("page 2");
		page2.setLayout(new GridLayout());
		Composite sectionClient2 = toolkit.createComposite(page2);
		sectionClient2.setLayout(new GridLayout());
		toolkit.createButton(sectionClient2, "Radio 1", SWT.CHECK);
		toolkit.createButton(sectionClient2, "Radio 2", SWT.CHECK);
		layoutData = new GridData(GridData.FILL_BOTH);
		sectionClient2.setLayoutData(layoutData);

		TableWrapData td = new TableWrapData(TableWrapData.FILL_GRAB);
		td.heightHint = 80;
		td.colspan = 2;
		pageBook.setLayoutData(td);
		
		pageBook.showPage("page 1");

		final Button createButton = toolkit.createButton(form.getBody(), "Show Page 1", SWT.FLAT);
		createButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				pageBook.showPage("page 1");
			}			
		});
		final Button createButton2 = toolkit.createButton(form.getBody(), "Show Page 2", SWT.FLAT);
		createButton2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				pageBook.showPage("page 2");
			}			
		});
	}

	@Override
	public void setFocus() {
	}
}
