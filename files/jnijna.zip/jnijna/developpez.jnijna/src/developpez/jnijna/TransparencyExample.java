package developpez.jnijna;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
public class TransparencyExample {
	
	private static final boolean isJNIImplementation = true;
	
	private final byte opacity = (byte)200;
	
	public TransparencyExample() {
		final Display display = new Display();
		final Shell myShell = new Shell(display, SWT.SHELL_TRIM | SWT.ON_TOP);
		myShell.setText("Transparency Example");
		myShell.setLayout(new FillLayout(SWT.VERTICAL));
		
		final Button myButton = new Button(myShell,SWT.NONE);
		myButton.setText("Go To The Transparency Dream");

		final Composite myComposite = new Composite(myShell, 0x80000);
		Color colorDarkBlue = Display.getDefault().getSystemColor(SWT.COLOR_DARK_BLUE);
		myComposite.setBackground(colorDarkBlue);
			
		myShell.setSize(400, 200);
		myShell.setLocation(0, 0);
		myShell.open();
			
		createTransparency(myShell.handle, colorDarkBlue.handle, opacity);
		
		while(!myShell.isDisposed()) {
		if (!display.readAndDispatch())
		display.sleep();
		}
		display.dispose();		
	}	
	
	public static void main(String[] argv) {
		new TransparencyExample();
	}
	
	private void createTransparency(int hWindow, int hColor, byte opacity) {
		if (isJNIImplementation) {
			int flags = JNIUser32.GetWindowLong(hWindow, JNIUser32.GWL_EXSTYLE);
	        flags |= JNIUser32.WS_EX_LAYERED;		        
	        JNIUser32.SetWindowLong(hWindow, JNIUser32.GWL_EXSTYLE, flags);        
	        JNIUser32.SetLayeredWindowAttributes(hWindow, hColor, opacity, JNIUser32.LWA_COLORKEY | JNIUser32.LWA_ALPHA);			
		} else {
			JNAUser32 lib = JNAUser32.INSTANCE;

	        int flags = lib.GetWindowLong(hWindow, JNAUser32.GWL_EXSTYLE);
	        flags |= JNAUser32.WS_EX_LAYERED;		        
	        lib.SetWindowLong(hWindow, JNAUser32.GWL_EXSTYLE, flags);        
	        lib.SetLayeredWindowAttributes(hWindow, hColor, opacity, JNAUser32.LWA_COLORKEY | JNAUser32.LWA_ALPHA);		
		}
	}
}
