package developpez.jnijna;

public final class JNIUser32 {
	
	static {
		System.loadLibrary("transparency");
	}
	
	public static final int LWA_COLORKEY = 1;

	public static final int LWA_ALPHA = 2;

	public static final int WS_EX_LAYERED = 0x80000;
	
	public static final int GWL_EXSTYLE = -20;
	
	public static final native int GetWindowLong(int hWnd, int nIndex);

	public static final native int SetWindowLong(int hWnd, int nIndex,
			int dwNewLong);

	public static final native boolean SetLayeredWindowAttributes(int hwnd,
			int crKey, byte bAlpha, int dwFlags);
}
