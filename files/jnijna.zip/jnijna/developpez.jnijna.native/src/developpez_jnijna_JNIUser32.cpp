#define WINVER 0x0500
#include <jni.h> 
#include <stdio.h>
#include <windows.h> 
#include "developpez_jnijna_JNIUser32.h"

JNIEXPORT jint JNICALL Java_developpez_jnijna_JNIUser32_GetWindowLong
  (JNIEnv *env, jclass theClass, jint windowHandle, jint nIndex) {
	jint rc = 0;
	rc = (jint)GetWindowLongA((HWND)windowHandle, nIndex);
	return rc;
}

JNIEXPORT jint JNICALL Java_developpez_jnijna_JNIUser32_SetWindowLong
  (JNIEnv *env, jclass theClass, jint windowHandle, jint nIndex, jint dwNewLong) {
	jint rc = 0;
	rc = (jint)SetWindowLongA((HWND)windowHandle, nIndex, dwNewLong);
	return rc;
}

JNIEXPORT jboolean JNICALL Java_developpez_jnijna_JNIUser32_SetLayeredWindowAttributes
  (JNIEnv *env, jclass theClass, jint windowHandle, jint hColor, jbyte alpha, jint flags) {
 	SetLayeredWindowAttributes((HWND)windowHandle,hColor,alpha,flags);
	return( 0 );
}
