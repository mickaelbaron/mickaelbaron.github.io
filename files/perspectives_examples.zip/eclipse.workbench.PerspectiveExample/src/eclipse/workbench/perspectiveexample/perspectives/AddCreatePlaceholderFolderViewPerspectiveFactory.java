package eclipse.workbench.perspectiveexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.IPlaceholderFolderLayout;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class AddCreatePlaceholderFolderViewPerspectiveFactory implements
		IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorArea = layout.getEditorArea();

		IPlaceholderFolderLayout createPlaceholderFolder = layout
				.createPlaceholderFolder("bottomFolder", IPageLayout.BOTTOM,
						0.45f, editorArea);
		createPlaceholderFolder.addPlaceholder(IPageLayout.ID_BOOKMARKS);
		createPlaceholderFolder.addPlaceholder(IPageLayout.ID_TASK_LIST);
		createPlaceholderFolder.addPlaceholder(IPageLayout.ID_RES_NAV);
	}

}
