package eclipse.workbench.perspectiveexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class AddViewPerspectiveFactory implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorAreaId = layout.getEditorArea();

		layout.addView(IPageLayout.ID_BOOKMARKS, IPageLayout.LEFT, 0.25f,
				editorAreaId);
		layout.addView(IPageLayout.ID_TASK_LIST, IPageLayout.BOTTOM, 0.15f,
				editorAreaId);
		layout.addView(IPageLayout.ID_RES_NAV, IPageLayout.BOTTOM, 0.45f,
				IPageLayout.ID_TASK_LIST);
	}
}
