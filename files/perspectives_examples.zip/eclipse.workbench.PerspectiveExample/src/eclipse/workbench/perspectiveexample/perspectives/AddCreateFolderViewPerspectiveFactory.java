package eclipse.workbench.perspectiveexample.perspectives;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class AddCreateFolderViewPerspectiveFactory implements
		IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorArea = layout.getEditorArea();
		
		IFolderLayout createFolder = layout.createFolder("bottomFolder",
				IPageLayout.BOTTOM, 0.45f, editorArea);
		createFolder.addView(IPageLayout.ID_BOOKMARKS);
		createFolder.addView(IPageLayout.ID_TASK_LIST);
		createFolder.addView(IPageLayout.ID_RES_NAV);
	}

}
