package eclipse.workbench.perspectiveexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class AddFastViewPerspectiveFactory implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorAreaId = layout.getEditorArea();

		layout.addView(IPageLayout.ID_RES_NAV, IPageLayout.BOTTOM, 0.45f,
				editorAreaId);

		layout.addFastView(IPageLayout.ID_BOOKMARKS, 0.50f);
		layout.addFastView(IPageLayout.ID_TASK_LIST, 0.50f);
	}
}
