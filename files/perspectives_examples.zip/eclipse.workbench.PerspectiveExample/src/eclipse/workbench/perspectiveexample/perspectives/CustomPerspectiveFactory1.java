package eclipse.workbench.perspectiveexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.console.IConsoleConstants;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class CustomPerspectiveFactory1 implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorAreaId = layout.getEditorArea();

		layout.addView(IPageLayout.ID_BOOKMARKS, IPageLayout.LEFT, 0.25f,
				editorAreaId);

		layout.addActionSet("org.eclipse.team.ui.actionSet");

		layout.addNewWizardShortcut("org.eclipse.ui.wizards.new.file");

		layout.addPerspectiveShortcut("org.eclipse.ui.resourcePerspective");

		layout.addShowViewShortcut(IConsoleConstants.ID_CONSOLE_VIEW);
	}
}
