package eclipse.workbench.perspectiveexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IPerspectiveRegistry;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class PerspectiveRegistryViewPart extends ViewPart {

	public PerspectiveRegistryViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		GridLayout myGRidLayout = new GridLayout(3, false);
		parent.setLayout(myGRidLayout);

		Button searchPerspective = new Button(parent, SWT.FLAT);
		searchPerspective.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IPerspectiveRegistry perspectiveRegistry = PlatformUI
						.getWorkbench().getPerspectiveRegistry();
				IPerspectiveDescriptor findPerspectiveWithId = perspectiveRegistry
						.findPerspectiveWithId("eclipse.workbench.PerspectiveExample.AddFastViewPerspective");
				if (findPerspectiveWithId != null) {
					System.out.println(findPerspectiveWithId.getId());
					System.out.println(findPerspectiveWithId.getLabel());
					System.out.println(findPerspectiveWithId.getDescription());
				}
			}
		});
		searchPerspective.setText("Find : AddFastViewPerspective");

		Button deletePerspective = new Button(parent, SWT.FLAT);
		deletePerspective.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IPerspectiveRegistry perspectiveRegistry = PlatformUI
						.getWorkbench().getPerspectiveRegistry();
				// Need to create an user perpsective called CustomPerspective
				// along the runtime of the application.
				IPerspectiveDescriptor findPerspectiveWithId = perspectiveRegistry
						.findPerspectiveWithId("CustomPerspective");
				if (findPerspectiveWithId != null) {
					perspectiveRegistry
							.deletePerspective(findPerspectiveWithId);
					System.out
							.println("Perspective \"CustomPerspective\" deleted.");
				}
			}
		});
		deletePerspective.setText("Delete : CustomPerspective");

		Button listsPerspective = new Button(parent, SWT.FLAT);
		listsPerspective.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IPerspectiveRegistry perspectiveRegistry = PlatformUI
						.getWorkbench().getPerspectiveRegistry();
				IPerspectiveDescriptor[] perspectives = perspectiveRegistry
						.getPerspectives();
				for (IPerspectiveDescriptor perspectiveDescriptor : perspectives) {
					System.out.println(perspectiveDescriptor.getId());
				}
			}
		});
		listsPerspective.setText("Lists all Perspectives");
	}

	@Override
	public void setFocus() {
	}
}
