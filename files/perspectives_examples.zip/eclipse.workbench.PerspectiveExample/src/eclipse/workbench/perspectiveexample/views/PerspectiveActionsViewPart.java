package eclipse.workbench.perspectiveexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class PerspectiveActionsViewPart extends ViewPart {

	public PerspectiveActionsViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(2, true));

		Button resetButton = new Button(parent, SWT.PUSH);
		resetButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				try {
					IHandlerService hs = (IHandlerService) PlatformUI
							.getWorkbench().getService(IHandlerService.class);
					hs.executeCommand(
							"org.eclipse.ui.window.resetPerspective",
							null);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		resetButton.setText("Reset Perspective");
	}

	@Override
	public void setFocus() {
	}
}
