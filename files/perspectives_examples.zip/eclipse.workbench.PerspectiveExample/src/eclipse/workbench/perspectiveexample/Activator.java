package eclipse.workbench.perspectiveexample;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IPerspectiveListener4;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2009
 */
public class Activator extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "eclipse.workbench.PerspectiveExample";

	// The shared instance
	private static Activator plugin;
	
	/**
	 * The constructor
	 */
	public Activator() {
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		
		IWorkbenchWindow activeWorkbenchWindow = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
		activeWorkbenchWindow.addPerspectiveListener(new IPerspectiveListener4() {

			public void perspectiveActivated(IWorkbenchPage page,
					IPerspectiveDescriptor perspective) {
				// TODO Auto-generated method stub				
				System.out.println("Activated " + perspective.getId());
			}

			public void perspectiveChanged(IWorkbenchPage page,
					IPerspectiveDescriptor perspective, String changeId) {
				// TODO Auto-generated method stub				
				System.out.println("Changed " + perspective.getId() + " " + changeId);
			}

			public void perspectivePreDeactivate(IWorkbenchPage page,
					IPerspectiveDescriptor perspective) {
				// TODO Auto-generated method stub
				System.out.println("PreDeactivate " + perspective.getId());
				
			}

			public void perspectiveClosed(IWorkbenchPage page,
					IPerspectiveDescriptor perspective) {
				// TODO Auto-generated method stub
				System.out.println("Closed " + perspective.getId());
			}

			public void perspectiveDeactivated(IWorkbenchPage page,
					IPerspectiveDescriptor perspective) {
				// TODO Auto-generated method stub
				System.out.println("Deactivated " + perspective.getId());
			}

			public void perspectiveOpened(IWorkbenchPage page,
					IPerspectiveDescriptor perspective) {
				// TODO Auto-generated method stub
				System.out.println("Opened " + perspective.getId());
			}

			public void perspectiveSavedAs(IWorkbenchPage page,
					IPerspectiveDescriptor oldPerspective,
					IPerspectiveDescriptor newPerspective) {
				// TODO Auto-generated method stub
				System.out.println("SaveAs " + oldPerspective.getId() + " " + newPerspective.getId());
			}

			public void perspectiveChanged(IWorkbenchPage page,
					IPerspectiveDescriptor perspective,
					IWorkbenchPartReference partRef, String changeId) {
				// TODO Auto-generated method stub
				System.out.println("Changed " + perspective.getId() + " " + partRef.getId() + " " + changeId);
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given
	 * plug-in relative path
	 *
	 * @param path the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}
}
