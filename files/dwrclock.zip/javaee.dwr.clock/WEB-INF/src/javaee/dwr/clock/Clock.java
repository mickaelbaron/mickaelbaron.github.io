package javaee.dwr.clock;

import java.util.Collection;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.directwebremoting.proxy.dwr.Util;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : december 2007
 */
public class Clock implements Runnable {

	private transient boolean active = false;

	private WebContext wctx = null;

	private static final Log log = LogFactory.getLog(Clock.class);

	public Clock() {
		wctx = WebContextFactory.get();
	}
		
	public synchronized void toggleClock() {
		active = !active;
		if (active) {
			new Thread(this).start();
		}
	}

	@SuppressWarnings("unchecked")
	public void run() {
		String currentPage = wctx.getCurrentPage();
		active = true;
		try {
			log.info("CLOCK: Thread de l'horloge d�marr�");
			while (active) {
				Collection sessions = wctx.getScriptSessionsByPage(currentPage);
				Util utilAll = new Util(sessions);
				utilAll.setValue("clockDisplay", new Date().toString());
				Thread.sleep(1000);
			}
			Collection sessions = wctx.getScriptSessionsByPage(currentPage);
			Util pages = new Util(sessions);
			pages.setValue("clockDisplay", "Termin�");

			log.debug("CLOCK: Thread de l'horloge arr�t�");
		} catch (InterruptedException ex) {
			log.warn("Interrupted", ex);
		}
	}
}
