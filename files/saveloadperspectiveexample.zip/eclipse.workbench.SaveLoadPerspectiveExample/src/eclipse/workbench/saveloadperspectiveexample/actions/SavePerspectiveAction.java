package eclipse.workbench.saveloadperspectiveexample.actions;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.XMLMemento;
import org.eclipse.ui.internal.Perspective;
import org.eclipse.ui.internal.WorkbenchPage;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2008
 */
public class SavePerspectiveAction implements IWorkbenchWindowActionDelegate {

	private static final String PERSPECTIVE = "perspective";

	public void init(IWorkbenchWindow window) {
	}

	public void selectionChanged(IAction action, ISelection selection) {
	}

	public void dispose() {
	}
	
	public void run(IAction action) {
		IWorkbenchWindow activeWorkbenchWindow = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow();
		if (activeWorkbenchWindow == null) {
			return;
		}

		IWorkbenchPage activePage = activeWorkbenchWindow.getActivePage();
		if (activePage == null) {
			return;
		}

		WorkbenchPage activeInternalPage = (WorkbenchPage) activePage;
		if (activeInternalPage == null) {
			return;
		}

		Perspective activeInternalPerspective = activeInternalPage
				.getActivePerspective();
		if (activeInternalPerspective == null) {
			return;
		}
		
		XMLMemento memento = XMLMemento.createWriteRoot(PERSPECTIVE);
		Writer writer = new StringWriter();
		activeInternalPerspective.saveState(memento);
		try {
			memento.save(writer);
			System.out.println(writer);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
