package eclipse.workbench.saveloadperspectiveexample.actions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;

import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.WorkbenchException;
import org.eclipse.ui.XMLMemento;
import org.eclipse.ui.internal.registry.PerspectiveDescriptor;
import org.eclipse.ui.internal.registry.PerspectiveRegistry;
import org.eclipse.ui.preferences.ScopedPreferenceStore;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2008
 */
public class LoadPerspectiveAction implements IWorkbenchWindowActionDelegate {

	private IWorkbenchWindow window;

	private IPreferenceStore preferenceStore;

	private static final String PERSP = "_persp"; 
	
	public LoadPerspectiveAction() {
	}

	public void selectionChanged(IAction action, ISelection selection) {
	}

	public void dispose() {
	}

	public void init(IWorkbenchWindow window) {
		this.window = window;
	}
	
	/**
	 * Retrieve from fileName file the XML perspective description. 
	 * 
	 * @param fileName file name of the XML perspective description
	 * @return a string containing the XML perspective description
	 */
	private String extractPerspectiveDescriptionFromFile(String fileName) {
		BufferedReader in = null;
		StringBuffer xmlString = new StringBuffer();

		InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream(fileName);
		in = new BufferedReader(new InputStreamReader(resourceAsStream));

		if (in == null) {
			return null;
		}

		char[] buf = new char[1024];
		int numRead = 0;

		try {
			while ((numRead = in.read(buf)) != -1) {
				xmlString.append(buf, 0, numRead);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return xmlString.toString();
	}
	
	public void run(IAction action) {
		String xmlString = this.extractPerspectiveDescriptionFromFile("perspectivePerso.xml");		
		Reader reader = null;

		if (xmlString != null && xmlString.length() != 0) {
			reader = new StringReader(xmlString.toString());
		} else {
			return;
		}

		// Transform String definition into XMLMemento
		XMLMemento memento = null;
		try {
			memento = XMLMemento.createReadRoot(reader);
		} catch (WorkbenchException e) {
			e.printStackTrace();
			return;
		}
		
		// Create an empty perspective descriptor.
		PerspectiveDescriptor newPersp = new PerspectiveDescriptor(null, null,
				null);
		// From a perspective descriptor, restore the state of the perspective.
		newPersp.restoreState(memento);

		// Retrieve the perspective registry. 
		// Don't care about this warning, we need to use this internal API ... 
		PerspectiveRegistry perspectiveRegistry = (PerspectiveRegistry) PlatformUI
				.getWorkbench().getPerspectiveRegistry();

		String id = newPersp.getId();

		// Find if there is a perspective with the same ID into the perspective registry. 
		IPerspectiveDescriptor oldPersp = perspectiveRegistry
				.findPerspectiveWithId(id);

		if (oldPersp != null) {
			System.out
					.println("Remove old perspective in order to replace it.");
			// Remove the existing perspective.
			perspectiveRegistry.deletePerspective(oldPersp);
		}

		// Retrieve the preference store of the workbench.
		IPreferenceStore workbenchStore = getWorkbenchPreferenceStore();
		
		// Store the new perspective description.
		workbenchStore.putValue(newPersp.getLabel() + PERSP, xmlString
				.toString());
		// Store the custom name of the new perspective.
		workbenchStore.putValue("perspectives", newPersp.getLabel());

		// Set perspective of the active page.
		PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
			.setPerspective(newPersp);
		
		// Reset perspective in order to take into account the new perspective.
		PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.resetPerspective();
	}

	private IPreferenceStore getWorkbenchPreferenceStore() {
		if (this.preferenceStore == null) {
			this.preferenceStore = new ScopedPreferenceStore(
					new InstanceScope(), "org.eclipse.ui.workbench");
		}
		return this.preferenceStore;
	}
}