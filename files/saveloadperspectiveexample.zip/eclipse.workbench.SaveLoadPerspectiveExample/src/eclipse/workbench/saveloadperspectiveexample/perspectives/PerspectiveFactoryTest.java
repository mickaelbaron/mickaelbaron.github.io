package eclipse.workbench.saveloadperspectiveexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2008
 */
public class PerspectiveFactoryTest implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		layout.addStandaloneView(IPageLayout.ID_RES_NAV, true,
				IPageLayout.LEFT, 0.50f, layout.getEditorArea());
	}
}
