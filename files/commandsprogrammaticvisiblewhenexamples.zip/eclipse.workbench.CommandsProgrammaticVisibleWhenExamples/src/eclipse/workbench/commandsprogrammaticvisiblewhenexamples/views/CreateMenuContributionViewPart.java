package eclipse.workbench.commandsprogrammaticvisiblewhenexamples.views;

import java.util.Set;

import org.eclipse.core.expressions.EvaluationResult;
import org.eclipse.core.expressions.Expression;
import org.eclipse.core.expressions.IEvaluationContext;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.WorkbenchWindow;
import org.eclipse.ui.internal.menus.WorkbenchMenuService;
import org.eclipse.ui.internal.services.EvaluationReference;
import org.eclipse.ui.menus.AbstractContributionFactory;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;
import org.eclipse.ui.menus.IContributionRoot;
import org.eclipse.ui.menus.IMenuService;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.ui.services.IEvaluationService;
import org.eclipse.ui.services.IServiceLocator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : November 2009
 */
@SuppressWarnings("restriction")
public class CreateMenuContributionViewPart extends ViewPart {

	private boolean isVisible = true;
	
	private CommandContributionItem item;
	
	private Expression currentExpression;
	
	public CreateMenuContributionViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(2, true));
		GridData myData = new GridData(GridData.FILL_BOTH);
		myData.horizontalSpan = 2;
		
		final Button myButton = new Button(parent, SWT.NONE);
		myButton.setText("Create");
		myButton.setLayoutData(myData);
		
		myButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IMenuService service = (IMenuService) PlatformUI.getWorkbench().getService(IMenuService.class);
				AbstractContributionFactory ref = new AbstractContributionFactory("menu:org.eclipse.ui.main.menu", null) {
					
					@Override
					public void createContributionItems(IServiceLocator serviceLocator, IContributionRoot additions) {
						CommandContributionItemParameter commandParameter = new CommandContributionItemParameter(
								serviceLocator, 
								"contributionitem",
								"eclipse.workbench.commandsprogrammaticvisiblewhenexamples.helloworldcommandid",
								CommandContributionItem.STYLE_PUSH);						
						currentExpression = new Expression() {
							@Override
							public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
								if (isVisible) {
									return EvaluationResult.TRUE;
								} else {
									return EvaluationResult.FALSE;
								}
								
							}							
						};
						item = new CommandContributionItem(commandParameter);						
						additions.addContributionItem(item, currentExpression);
					}
				};
				service.addContributionFactory(ref);				
				myButton.setEnabled(false);
			}			
		});

		myData = new GridData(GridData.FILL_BOTH);

		Button hideMenuContribution = new Button(parent, SWT.NONE);
		hideMenuContribution.setText("Hide");
		hideMenuContribution.setLayoutData(myData);
		hideMenuContribution.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				isVisible = false;
				
				updateExpression();
			}
		});
		
		Button showMenuContribution = new Button(parent, SWT.NONE);
		showMenuContribution.setText("Show");
		showMenuContribution.setLayoutData(myData);
		showMenuContribution.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				isVisible = true;
							
				updateExpression();	
			}
		});
		
	}

	@Override
	public void setFocus() {
	}

	@SuppressWarnings({ "unchecked" })
	private void updateExpression() {
		WorkbenchWindow current = (WorkbenchWindow)PlatformUI.getWorkbench().getActiveWorkbenchWindow();
		final Set<EvaluationReference> menuRestrictions = current.getMenuRestrictions();
	
		if (menuRestrictions == null) { return; }
		
		IEvaluationService es = (IEvaluationService)PlatformUI.getWorkbench().getService(IEvaluationService.class);
		IEvaluationContext currentState = es.getCurrentState();
		
		EvaluationReference[] refs = (EvaluationReference[]) menuRestrictions.toArray(new EvaluationReference[menuRestrictions.size()]);
		boolean changeDetected = false;
		for (EvaluationReference evalRef : refs) {
			final Expression expression = evalRef.getExpression();					
			if (expression == currentExpression) {
				evalRef.setPostingChanges(true);
				boolean os = evalRef.evaluate(currentState);
				evalRef.clearResult();
				boolean ns = evalRef.evaluate(currentState);

				if (os != ns) {
					changeDetected = true;
					evalRef.getListener().propertyChange(
							new PropertyChangeEvent(evalRef, evalRef
									.getProperty(), valueOf(os), valueOf(ns)));
				}		
			}
		}	
		
		if (changeDetected) {
			IMenuService ms = (IMenuService) PlatformUI.getWorkbench().getService(IMenuService.class);
			if (ms instanceof WorkbenchMenuService) {
				((WorkbenchMenuService) ms).updateManagers();
			}
		}
	}
	
	private Boolean valueOf(boolean result) {
		return result ? Boolean.TRUE : Boolean.FALSE;
	}
}
