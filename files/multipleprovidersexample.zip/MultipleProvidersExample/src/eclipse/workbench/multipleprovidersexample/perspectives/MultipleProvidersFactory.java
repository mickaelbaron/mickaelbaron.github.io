package eclipse.workbench.multipleprovidersexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : May 2009
 */
public class MultipleProvidersFactory implements IPerspectiveFactory {

	@Override
	public void createInitialLayout(IPageLayout layout) {
		layout.setEditorAreaVisible(false);
		String editorArea = layout.getEditorArea();
		
		layout.addView("eclipse.workbench.MultipleProvidersExample.views.multipleprovidersid",
				IPageLayout.LEFT, 0.45f, editorArea);
		layout.addView("eclipse.workbench.MultipleProvidersExample.views.selectionlistenerid",
				IPageLayout.RIGHT, 0.45f, editorArea);
	}

}
