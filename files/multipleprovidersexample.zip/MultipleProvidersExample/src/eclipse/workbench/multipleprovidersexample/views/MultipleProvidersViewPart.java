package eclipse.workbench.multipleprovidersexample.views;

import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : May 2009
 */
public class MultipleProvidersViewPart extends ViewPart {

	private TableViewer viewer1;

	private TableViewer viewer2;
	
	class ViewContentProvider implements IStructuredContentProvider {
		public void inputChanged(Viewer v, Object oldInput, Object newInput) {
		}

		public void dispose() {
		}

		public Object[] getElements(Object parent) {
			return new String[] { "One", "Two", "Three" };
		}
	}

	class ViewLabelProvider extends LabelProvider implements
			ITableLabelProvider {
		public String getColumnText(Object obj, int index) {
			return getText(obj);
		}

		public Image getColumnImage(Object obj, int index) {
			return getImage(obj);
		}

		public Image getImage(Object obj) {
			return PlatformUI.getWorkbench().getSharedImages().getImage(
					ISharedImages.IMG_OBJ_ELEMENT);
		}
	}

	class NameSorter extends ViewerSorter {
	}
	
	public MultipleProvidersViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		viewer1 = new TableViewer(parent, SWT.MULTI | SWT.H_SCROLL
				| SWT.V_SCROLL | SWT.BORDER);
		viewer1.setContentProvider(new ViewContentProvider());
		viewer1.setLabelProvider(new ViewLabelProvider());
		viewer1.setInput(getViewSite());

		
		viewer2 = new TableViewer(parent, SWT.MULTI | SWT.H_SCROLL
				| SWT.V_SCROLL | SWT.BORDER);
		viewer2.setContentProvider(new ViewContentProvider());
		viewer2.setLabelProvider(new ViewLabelProvider());
		viewer2.setInput(getViewSite());		
		
		final SelectionProviderIntermediate selectionProviderIntermediate = new SelectionProviderIntermediate();
		this.getSite().setSelectionProvider(selectionProviderIntermediate);

		viewer1.addSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				selectionProviderIntermediate.setSelectionProviderDelegate(viewer1);
			}
		});
		viewer1.addPostSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				selectionProviderIntermediate.setSelectionProviderDelegate(viewer1);
			}			
		});
		
		viewer2.addSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				selectionProviderIntermediate.setSelectionProviderDelegate(viewer2);
			}			
		});
		
		viewer2.addPostSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				selectionProviderIntermediate.setSelectionProviderDelegate(viewer2);
			}			
		});
		
	}

	@Override
	public void setFocus() {
	}
}
