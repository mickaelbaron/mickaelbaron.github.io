package eclipse.workbench.builderexample;

import java.util.Map;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class CustomIncrementalProjectBuilder extends IncrementalProjectBuilder {

	@SuppressWarnings("unchecked")
	@Override
	protected IProject[] build(int kind, Map args, IProgressMonitor monitor)
			throws CoreException {
		if (kind == IncrementalProjectBuilder.FULL_BUILD) {
			fullBuild(monitor);
		} else {
			IResourceDelta delta = getDelta(getProject());
			if (delta == null) {
				fullBuild(monitor);
			} else {
				incrementalBuild(delta, monitor);
			}
		}
		return null;
	}

	protected void fullBuild(final IProgressMonitor monitor)
			throws CoreException {
		try {
			final IFolder folder = this.getProject().getFolder("My Bin");
			if (!folder.exists()) {
				folder.create(true, true, null);
			}
			
			getProject().accept(new MyBuildVisitor());
		} catch (CoreException e) {
		}
	}

	protected void incrementalBuild(IResourceDelta delta,
			IProgressMonitor monitor) throws CoreException {
		// the visitor does the work.
		delta.accept(new MyBuildDeltaVisitor());
	}

	class MyBuildVisitor implements IResourceVisitor {
		public boolean visit(IResource res) {

			System.out.println("Full " + res.getName());
			return true;
		}
	}
	

	class MyBuildDeltaVisitor implements IResourceDeltaVisitor {
		public boolean visit(IResourceDelta res) {
			
			System.out.println("Incremental " + res.getKind() + " " + res.getResource().getName());
			return true;
		}
	}
	
	@Override
	protected void clean(IProgressMonitor monitor) throws CoreException {
		final IFolder folder = this.getProject().getFolder("My Bin");
		if (folder.exists()) {
			folder.delete(true, null);
		}
	}
}
