package eclipse.workbench.builderexample;

import java.io.ByteArrayInputStream;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class BuilderViewPart extends ViewPart {

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout());
		
		Button createTasks = new Button(parent, SWT.FLAT);
		createTasks.setText("Associate Builder ...");
		createTasks.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				
				final IProject projectBuilder = root.getProject("Project Builder");

				try {
					if (!projectBuilder.exists()) {
						projectBuilder.create(null);	
						projectBuilder.open(null);
					}
					
					final IFile file = projectBuilder.getFile("file 1");
					if (!file.exists()) {
						file.create(new ByteArrayInputStream("HelloWorld\n This is text for Builder examples".getBytes()), IResource.NONE, null);
					}
							
					final String BUILDER_ID = "eclipse.workbench.BuilderExample.samplebuilderid";
					IProjectDescription desc = projectBuilder.getDescription();
					ICommand[] commands = desc.getBuildSpec();
				
					// Add builder to project
					ICommand command = desc.newCommand();
					command.setBuilderName(BUILDER_ID);
					ICommand[] newCommands = new ICommand[commands.length + 1];

					// Add it before other builders.
					System.arraycopy(commands, 0, newCommands, 1, commands.length);
					newCommands[0] = command;
					desc.setBuildSpec(newCommands);
					projectBuilder.setDescription(desc, null);					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}			
		});
	}

	@Override
	public void setFocus() {
	}
}
