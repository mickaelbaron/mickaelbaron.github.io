package eclipse.workbench.editorexample.editors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IPartListener2;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.EditorPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class LifeCycleEditor extends EditorPart {

	private boolean dirty;

	public LifeCycleEditor() {
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
	}

	@Override
	public void doSaveAs() {
	}

	@Override
	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		this.setSite(site);
		this.setInput(input);
	}

	@Override
	public boolean isDirty() {
		return dirty;
	}

	@Override
	public boolean isSaveAsAllowed() {
		return true;
	}

	@Override
	public void createPartControl(Composite parent) {
		dirty = false;

		IWorkbenchPage activePage = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getActivePage();
		activePage.addPartListener(new IPartListener2() {

			@Override
			public void partActivated(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partActivated()");
				}
			}

			@Override
			public void partBroughtToTop(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partBroughtToTop()");
				}
			}

			@Override
			public void partClosed(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partClosed()");
				}
			}

			@Override
			public void partDeactivated(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partDeactivated()");
				}
			}

			@Override
			public void partHidden(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partHidden()");
				}
			}

			@Override
			public void partInputChanged(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partInputChanged()");
				}
			}

			@Override
			public void partOpened(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partOpened()");
				}
			}

			@Override
			public void partVisible(IWorkbenchPartReference partRef) {
				IWorkbenchPart part = partRef.getPart(false);
				if (LifeCycleEditor.this == part) {
					System.out.println(".partVisible()");
				}
			}
		});
	}

	@Override
	public void setFocus() {
	}
}
