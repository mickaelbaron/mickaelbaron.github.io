package eclipse.workbench.editorexample.editors;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.FileEditorInput;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class OpenExternalEditorCommandHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		try {
			IWorkspace ws = ResourcesPlugin.getWorkspace();
			IProject project = ws.getRoot().getProject("SimpleEditor");

			if (!project.exists())
				project.create(null);

			if (!project.isOpen())
				project.open(null);

			final IWorkbenchWindow activeWorkbenchWindow = PlatformUI
					.getWorkbench().getActiveWorkbenchWindow();
			final Shell shell = activeWorkbenchWindow.getShell();

			String name = new FileDialog(shell, SWT.OPEN).open();
			if (name == null)
				return null;

			IPath location = new Path(name);
			IFile file = project.getFile(location.lastSegment());
			file.createLink(location, IResource.NONE, null);
			IWorkbenchPage page = activeWorkbenchWindow.getActivePage();
			if (page != null) {
				IEditorDescriptor desc = PlatformUI.getWorkbench()
						.getEditorRegistry().getDefaultEditor(file.getName());
				page.openEditor(new FileEditorInput(file), desc.getId());

			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
}
