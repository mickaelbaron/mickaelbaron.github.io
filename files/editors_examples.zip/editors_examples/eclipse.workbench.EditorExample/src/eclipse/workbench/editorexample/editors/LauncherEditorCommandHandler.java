package eclipse.workbench.editorexample.editors;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorRegistry;
import org.eclipse.ui.PlatformUI;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class LauncherEditorCommandHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final IEditorRegistry editorRegistry = PlatformUI.getWorkbench()
				.getEditorRegistry();
		IEditorDescriptor defaultEditor = editorRegistry
				.getDefaultEditor("*.html");
		if (defaultEditor != null) {
			System.out.println(defaultEditor.getLabel());
		}

		editorRegistry
				.setDefaultEditor("*.html",
						"eclipse.workbench.EditorExample.SimpleExternalEditorWithLauncherId");

		defaultEditor = editorRegistry.getDefaultEditor("*.html");
		if (defaultEditor != null) {
			System.out.println(defaultEditor.getLabel());
		}

		return null;
	}
}
