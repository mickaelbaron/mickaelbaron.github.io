package eclipse.workbench.editorexample.editors;

import java.net.URI;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class OpenExternalEditorWithEFSCommandHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final IWorkbenchWindow activeWorkbenchWindow = PlatformUI
				.getWorkbench().getActiveWorkbenchWindow();
		final Shell shell = activeWorkbenchWindow.getShell();

		String name = new FileDialog(shell, SWT.OPEN).open();
		if (name == null)
			return null;
		name = name.replace('\\', '/');
		IFileStore fileStore = EFS.getLocalFileSystem().getStore(
				URI.create(name));
		if (!fileStore.fetchInfo().isDirectory()
				&& fileStore.fetchInfo().exists()) {
			IWorkbenchPage page = activeWorkbenchWindow.getActivePage();
			try {
				IDE.openEditorOnFileStore(page, fileStore);
			} catch (PartInitException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
