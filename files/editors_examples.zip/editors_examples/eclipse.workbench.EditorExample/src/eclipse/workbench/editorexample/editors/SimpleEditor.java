package eclipse.workbench.editorexample.editors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import eclipse.workbench.editorexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class SimpleEditor extends EditorPart {

	public int count;
	
	public SimpleEditor() {
	}

	@Override
	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		setSite(site);
		setInput(input);
		
		count = Activator.getDefault().incrCount();
	}
	
	@Override
	public boolean isDirty() {
		return true;
	}

	@Override
	public boolean isSaveAsAllowed() {
		System.out.println("SimpleEditor.isSaveAsAllowed()");
		return false;
	}

	@Override
	public boolean isSaveOnCloseNeeded() {
		System.out.println("SimpleEditor.isSaveOnCloseNeeded()");
		return true;
	}
	
	@Override
	public void createPartControl(Composite parent) {
		Label myLabel = new Label(parent, SWT.NONE);
		myLabel.setText("Simple View");						
	}

	@Override
	public void setFocus() {
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
		System.out.println("SimpleEditor.doSave()");
	}


	@Override
	public void doSaveAs() {
		System.out.println("SimpleEditor.doSaveAs()");
	}
	
	@Override
	public void dispose() {
		System.out.println("fin");
	}
}
