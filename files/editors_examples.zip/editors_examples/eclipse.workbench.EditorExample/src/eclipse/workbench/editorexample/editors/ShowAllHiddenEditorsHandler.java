package eclipse.workbench.editorexample.editors;

import java.util.List;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.WorkbenchPage;

import eclipse.workbench.editorexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
@SuppressWarnings("restriction")
public class ShowAllHiddenEditorsHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

		WorkbenchPage activeWorkbencPage = (WorkbenchPage)activePage;
		
		final List<IEditorReference> hiddenEditors = Activator.getDefault().getHiddenEditors();
		hiddenEditors.clear();
		activeWorkbencPage.resetHiddenEditors();		
		return null;
	}
}
