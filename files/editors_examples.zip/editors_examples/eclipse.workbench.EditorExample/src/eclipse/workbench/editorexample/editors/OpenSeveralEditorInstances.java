package eclipse.workbench.editorexample.editors;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.ISelectionService;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.FileEditorInput;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class OpenSeveralEditorInstances extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final IWorkbenchPage activePage = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getActivePage();

		ISelectionService selService = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getSelectionService();
		final ISelection selection = selService.getSelection();
		if (selection instanceof TreeSelection) {
			TreeSelection currentFile = (TreeSelection) selection;
			final IFile firstElement = (IFile) currentFile.getFirstElement();
			IEditorDescriptor desc = PlatformUI.getWorkbench()
					.getEditorRegistry().getDefaultEditor(
							firstElement.getName());
			try {
				activePage.openEditor(new FileEditorInput(firstElement), desc
						.getId(), true, IWorkbenchPage.MATCH_NONE);
			} catch (PartInitException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

}
