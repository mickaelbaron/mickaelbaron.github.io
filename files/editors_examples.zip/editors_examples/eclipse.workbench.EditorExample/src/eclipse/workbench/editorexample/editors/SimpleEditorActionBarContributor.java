package eclipse.workbench.editorexample.editors;

import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;
import org.eclipse.ui.part.EditorActionBarContributor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class SimpleEditorActionBarContributor extends
		EditorActionBarContributor {

	@Override
	public void contributeToMenu(IMenuManager menuManager) {
		CommandContributionItemParameter commandParameter = new CommandContributionItemParameter(
				PlatformUI.getWorkbench(), "contributionitem",
				"eclipse.workbench.editorexample.SimpleCommandId",
				CommandContributionItem.STYLE_PUSH);
		IContributionItem ref = new CommandContributionItem(commandParameter);

		IMenuManager menu = new MenuManager("Simple Editor");
		menuManager
				.prependToGroup(IWorkbenchActionConstants.MB_ADDITIONS, menu);
		menu.add(ref);
	}

	public SimpleEditorActionBarContributor() {
	}

	@Override
	public void contributeToToolBar(IToolBarManager toolBarManager) {
		CommandContributionItemParameter commandParameter = new CommandContributionItemParameter(
				PlatformUI.getWorkbench(), "contributionitem",
				"eclipse.workbench.editorexample.SimpleCommandId",
				CommandContributionItem.STYLE_PUSH);
		IContributionItem ref = new CommandContributionItem(commandParameter);
		toolBarManager.add(ref);
	}

	@Override
	public void setActiveEditor(IEditorPart targetEditor) {
	}
}
