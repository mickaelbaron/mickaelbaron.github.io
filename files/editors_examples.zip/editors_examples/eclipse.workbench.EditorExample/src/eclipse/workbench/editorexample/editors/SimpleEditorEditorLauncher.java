package eclipse.workbench.editorexample.editors;

import org.eclipse.core.runtime.IPath;
import org.eclipse.swt.program.Program;
import org.eclipse.ui.IEditorLauncher;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class SimpleEditorEditorLauncher implements IEditorLauncher {

	@Override
	public void open(IPath file) {
		final Program findProgram = Program.findProgram("txt");
		boolean result = findProgram.execute(file.toFile().getAbsolutePath());
		
		System.out.println("External Editor has been launched ? : " + result);
	}
}
