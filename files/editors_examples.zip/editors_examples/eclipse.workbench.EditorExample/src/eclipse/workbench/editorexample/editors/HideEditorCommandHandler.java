package eclipse.workbench.editorexample.editors;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.PlatformUI;

import eclipse.workbench.editorexample.Activator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class HideEditorCommandHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final IWorkbenchPage activePage = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getActivePage();

		final IWorkbenchPartReference reference = activePage
				.getReference(activePage.getActiveEditor());
		if (reference instanceof IEditorReference) {
			activePage.hideEditor((IEditorReference) reference);
			Activator.getDefault().getHiddenEditors().add(
					(IEditorReference) reference);
		}

		return null;
	}
}
