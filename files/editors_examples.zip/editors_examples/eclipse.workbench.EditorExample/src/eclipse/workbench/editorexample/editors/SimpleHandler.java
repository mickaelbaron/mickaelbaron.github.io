package eclipse.workbench.editorexample.editors;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorRegistry;
import org.eclipse.ui.PlatformUI;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class SimpleHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final IEditorRegistry editorRegistry = PlatformUI.getWorkbench().getEditorRegistry();
		
		final IEditorDescriptor[] editors = editorRegistry.getEditors("*.html");
		for (IEditorDescriptor iEditorDescriptor : editors) {
			System.out.println(iEditorDescriptor.getLabel());
		}
		return null;				
	}
}
