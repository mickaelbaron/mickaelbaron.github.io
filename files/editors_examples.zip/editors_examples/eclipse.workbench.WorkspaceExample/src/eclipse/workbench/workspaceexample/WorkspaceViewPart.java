package eclipse.workbench.workspaceexample;

import java.io.ByteArrayInputStream;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Platform;
import org.eclipse.osgi.service.datalocation.Location;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class WorkspaceViewPart extends ViewPart {

	public WorkspaceViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout());
		
		Button location = new Button(parent, SWT.FLAT);
		location.setText("Workspace location ...");
		location.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Location instanceLoc = Platform.getInstanceLocation();
				
				System.out.println(instanceLoc.getURL().toString());		
			}
		});
		
		Button getProjects = new Button(parent, SWT.FLAT);
		getProjects.setText("Projects from the current Workspace ...");
		getProjects.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {				
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				final IProject[] projects = root.getProjects();
				for (IProject iProject : projects) {
					System.out.println(iProject.getName());
				}
			}
		});
		
		Button createProject = new Button(parent, SWT.FLAT);
		createProject.setText("Create new Project ...");
		createProject.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {				
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				final IProject project4 = root.getProject("Project 4");
				
				try {
					project4.create(null);
					project4.open(null);
					
					final IProjectDescription description = project4.getDescription();
					description.setComment("This is a simple project");
					final IProject project1 = root.getProject("Project 1");

					final IProject project2 = root.getProject("Project 2");
					
					IProject[] tabProjects = {project1, project2};
					
					description.setReferencedProjects(tabProjects);
					
					project4.setDescription(description, null);
				} catch (CoreException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		Button createFolder = new Button(parent, SWT.FLAT);
		createFolder.setText("Create new Folder and File ...");
		createFolder.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {				
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				final IProject project4 = root.getProject("Project 4");
				
				try {
					final IFolder folderA = project4.getFolder("Folder A");
					folderA.create(true, true, null);

					IFile fileA = project4.getFile("File A.txt");
					fileA.create(new ByteArrayInputStream("HelloWorld from File A".getBytes()), true, null);
					
					IFile fileB = folderA.getFile("File B.txt");
					fileB.create(new ByteArrayInputStream("HelloWorld from File B".getBytes()), true, null);
					
					System.out.println(fileA.getFullPath());
					
				} catch (CoreException e1) {
					e1.printStackTrace();
				}
			}
		});
		
	}

	@Override
	public void setFocus() {
	}
}
