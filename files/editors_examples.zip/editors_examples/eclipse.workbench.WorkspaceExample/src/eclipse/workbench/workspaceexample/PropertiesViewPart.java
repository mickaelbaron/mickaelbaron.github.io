package eclipse.workbench.workspaceexample;

import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PropertiesViewPart extends ViewPart {

	private final String projectName = "Project 5";
	
	public PropertiesViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout());
		
		Button saveSessionPropertiesButton = new Button(parent, SWT.FLAT);
		saveSessionPropertiesButton.setText("Save Session Properties ...");
		saveSessionPropertiesButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				
				final IProject project5 = root.getProject(projectName);

				try {
					if (!project5.exists()) {
						project5.create(null);	
						project5.open(null);
					}
					project5.setSessionProperty(new QualifiedName("session_test", "en"), "test");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		
		Button loadSessionPropertiesButton = new Button(parent, SWT.FLAT);
		loadSessionPropertiesButton.setText("Load Session Properties ...");
		loadSessionPropertiesButton.addSelectionListener(new SelectionAdapter() {
			@SuppressWarnings("unchecked")
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				final IProject project5 = root.getProject(projectName);

				try {
					final Map sessionProperties = project5.getSessionProperties();
					System.out.println(sessionProperties.get(new QualifiedName("session_test", "en")));
				} catch (CoreException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		Button savePersistentPropertiesButton = new Button(parent, SWT.FLAT);
		savePersistentPropertiesButton.setText("Save Persistence Properties ...");
		savePersistentPropertiesButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				final IProject project5 = root.getProject(projectName);

				try {
					if (!project5.exists()) {
						project5.create(null);						
					}
							
					project5.setPersistentProperty(new QualifiedName("persistent_test", "en"), "test");
				} catch (CoreException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		Button loadPersistentPropertiesButton = new Button(parent, SWT.FLAT);
		loadPersistentPropertiesButton.setText("Load Persistence Properties ...");
		loadPersistentPropertiesButton.addSelectionListener(new SelectionAdapter() {
			@SuppressWarnings("unchecked")
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				final IProject project5 = root.getProject(projectName);

				try {
					final Map persistentProperties = project5.getPersistentProperties();
					System.out.println(persistentProperties.get(new QualifiedName("persistent_test", "en")));
				} catch (CoreException e1) {
					e1.printStackTrace();
				}
			}
		});
	}

	@Override
	public void setFocus() {
	}
}
