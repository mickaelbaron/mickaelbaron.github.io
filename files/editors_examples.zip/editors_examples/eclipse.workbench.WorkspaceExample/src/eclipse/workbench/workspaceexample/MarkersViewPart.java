package eclipse.workbench.workspaceexample;

import java.io.ByteArrayInputStream;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class MarkersViewPart extends ViewPart {

	private final String projectName = "Project Markers";
	
	public MarkersViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout());
		
		Button createTasks = new Button(parent, SWT.FLAT);
		createTasks.setText("Create Tasks ...");
		createTasks.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				
				final IProject projectMarkers = root.getProject(projectName);

				try {
					if (!projectMarkers.exists()) {
						projectMarkers.create(null);	
						projectMarkers.open(null);
					}
					
					final IFile file = projectMarkers.getFile("file");
					if (!file.exists()) {
						file.create(new ByteArrayInputStream("HelloWorld\n This is a text for Marker examples".getBytes()), IResource.NONE, null);
					}
					
					IMarker createTaskMarker = file.createMarker(IMarker.TASK);
					createTaskMarker.setAttribute(IMarker.MESSAGE, "Sample Task message");
					createTaskMarker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
					createTaskMarker.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_LOW);
					createTaskMarker.setAttribute(IMarker.USER_EDITABLE, false);					
					createTaskMarker.setAttribute(IMarker.LINE_NUMBER, 2);
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		
		Button createProblems = new Button(parent, SWT.FLAT);
		createProblems.setText("Create Problems ...");
		createProblems.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				
				final IProject projectTask = root.getProject(projectName);

				try {
					if (!projectTask.exists()) {
						projectTask.create(null);	
						projectTask.open(null);
					}
					
					final IFile file = projectTask.getFile("file");
					if (!file.exists()) {
						file.create(new ByteArrayInputStream("HelloWorld\n This is text for Marker examples".getBytes()), IResource.NONE, null);
					}
					
					IMarker createErrorProblemMarker = file.createMarker(IMarker.PROBLEM);
					createErrorProblemMarker.setAttribute(IMarker.MESSAGE, "Sample Error Problem message");
					createErrorProblemMarker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
					createErrorProblemMarker.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_LOW);
					createErrorProblemMarker.setAttribute(IMarker.LINE_NUMBER, 2);

					IMarker createWarningProblemMarker = file.createMarker(IMarker.PROBLEM);
					createWarningProblemMarker.setAttribute(IMarker.MESSAGE, "Sample Warning Problem message");
					createWarningProblemMarker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_WARNING);
					createWarningProblemMarker.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_HIGH);
					createWarningProblemMarker.setAttribute(IMarker.LINE_NUMBER, 2);					
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		
		Button createBookmarks = new Button(parent, SWT.FLAT);
		createBookmarks.setText("Create Bookmarks ...");
		createBookmarks.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				
				final IProject projectTask = root.getProject(projectName);

				try {
					if (!projectTask.exists()) {
						projectTask.create(null);	
						projectTask.open(null);
					}
					
					final IFile file = projectTask.getFile("file");
					if (!file.exists()) {
						file.create(new ByteArrayInputStream("HelloWorld\n This is text for Marker examples".getBytes()), IResource.NONE, null);
					}
					
					IMarker createErrorProblemMarker = file.createMarker(IMarker.BOOKMARK);
					createErrorProblemMarker.setAttribute(IMarker.MESSAGE, "Sample Bookmark message");
					createErrorProblemMarker.setAttribute(IMarker.LINE_NUMBER, 2);
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});		
	}

	@Override
	public void setFocus() {
	}
}
