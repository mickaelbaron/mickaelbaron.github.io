package eclipse.workbench.passmemeditor;

import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemEditorPart extends AbstractDecoratedTextEditor {
	public PassMemEditorPart() {
		super();
		
		this.setSourceViewerConfiguration(
				new PassMemSourceViewerConfiguration(getSharedColors(), getPreferenceStore()));		
	}
}
