package eclipse.workbench.passmemeditor;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.ITokenScanner;
import org.eclipse.jface.text.rules.IWordDetector;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WordRule;
import org.eclipse.jface.text.source.ISharedTextColors;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.ui.editors.text.TextSourceViewerConfiguration;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemSourceViewerConfiguration extends
		TextSourceViewerConfiguration {

	private ISharedTextColors refSharedTextColors;

	private static final class WordDetector implements IWordDetector {
		public boolean isWordPart(char c) {
			return Character.isLetter(c);
		}

		public boolean isWordStart(char c) {
			return c == '@';
		}
	}

	public PassMemSourceViewerConfiguration(
			ISharedTextColors pSharedTextColors,
			IPreferenceStore preferenceStore) {
		super(preferenceStore);
		this.refSharedTextColors = pSharedTextColors;
	}

	@Override
	public String getConfiguredDocumentPartitioning(ISourceViewer sourceViewer) {
		return PassDocumentProvider.PASS_PARTITIONING;
	}

	@Override
	public String[] getConfiguredContentTypes(ISourceViewer sourceViewer) {
		return new String[] { 
			PassDocumentProvider.PASS_CODE,
			PassDocumentProvider.PASS_COMMENT };
	}

	@Override
	public IPresentationReconciler getPresentationReconciler(
			ISourceViewer sourceViewer) {
		PresentationReconciler reconciler = new PresentationReconciler();
		reconciler
				.setDocumentPartitioning(getConfiguredDocumentPartitioning(sourceViewer));

		// Partition for other.
		DefaultDamagerRepairer defaultDamagerRepairer = new DefaultDamagerRepairer(
				getDefaultRuleBasedScanner());

		reconciler.setDamager(defaultDamagerRepairer,
				PassDocumentProvider.PASS_CODE);
		reconciler.setRepairer(defaultDamagerRepairer,
				PassDocumentProvider.PASS_CODE);

		// Partition for Comment.
		DefaultDamagerRepairer commentDamagerRepairer = new DefaultDamagerRepairer(
				getCommentRuleBasedScanner());

		reconciler.setDamager(commentDamagerRepairer,
				PassDocumentProvider.PASS_COMMENT);
		reconciler.setRepairer(commentDamagerRepairer,
				PassDocumentProvider.PASS_COMMENT);

		return reconciler;
	}

	private ITokenScanner getCommentRuleBasedScanner() {
		Token tokenComment2 = new Token(new TextAttribute(refSharedTextColors
				.getColor(new RGB(140, 140, 140)), refSharedTextColors
				.getColor(new RGB(200, 200, 200)), SWT.ITALIC));

		RuleBasedScanner commentScanner = new RuleBasedScanner();
		commentScanner.setDefaultReturnToken(tokenComment2);

		return commentScanner;
	}

	private ITokenScanner getDefaultRuleBasedScanner() {
		Token tokenDefault = new Token(new TextAttribute(refSharedTextColors
				.getColor(new RGB(0, 0, 255)), null, SWT.ITALIC | SWT.BOLD));
		Token keywordToken = new Token(new TextAttribute(refSharedTextColors
				.getColor(new RGB(0, 0, 0)), null, SWT.BOLD));

		RuleBasedScanner passMemScanner = new RuleBasedScanner();

		// Keywords.
		String[] keywords = { "@entry", "@login", "@password", "@url", "@note",
				"@creationDate", "@expirationDate" };
		WordRule keywordRule = new WordRule(new WordDetector(), tokenDefault);

		for (String current : keywords) {
			keywordRule.addWord(current, keywordToken);
		}

		IRule[] rules = { keywordRule };
		passMemScanner.setRules(rules);

		return passMemScanner;
	}
}
