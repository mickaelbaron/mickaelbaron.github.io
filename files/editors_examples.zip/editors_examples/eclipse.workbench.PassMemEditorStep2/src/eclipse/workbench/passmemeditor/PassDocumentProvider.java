package eclipse.workbench.passmemeditor;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentExtension3;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.EndOfLineRule;
import org.eclipse.jface.text.rules.FastPartitioner;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.MultiLineRule;
import org.eclipse.jface.text.rules.RuleBasedPartitionScanner;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.ui.editors.text.FileDocumentProvider;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassDocumentProvider extends FileDocumentProvider {

	public static final String PASS_PARTITIONING = "eclipse.workbench.passmemeditor.passpartitioning";
	
	public static final String PASS_CODE = IDocument.DEFAULT_CONTENT_TYPE;
	
	public static final String PASS_COMMENT= "PASS_COMMENT";
	
	private static final String[] CONTENT_TYPES= {
		PASS_CODE,
		PASS_COMMENT
	};
	
	@Override
	protected void setupDocument(Object element, IDocument document) {		
		if (document instanceof IDocumentExtension3) {
			IDocumentExtension3 ext = (IDocumentExtension3)document;
			
			IDocumentPartitioner partitioner = createPassPartitioner();
			ext.setDocumentPartitioner(PASS_PARTITIONING, partitioner);
			partitioner.connect(document);
		}
	}	
	
	private IDocumentPartitioner createPassPartitioner() {
		EndOfLineRule commentRule1 = new EndOfLineRule("//", new Token(PASS_COMMENT),'c');
		MultiLineRule commentRule2 = new MultiLineRule("/*", "*/", new Token(PASS_COMMENT), (char)0, true);

		IPredicateRule[] rules= { commentRule1, commentRule2 };

		RuleBasedPartitionScanner scanner = new RuleBasedPartitionScanner();
		scanner.setPredicateRules(rules);
		
		return new FastPartitioner(scanner, CONTENT_TYPES);
	}
}
