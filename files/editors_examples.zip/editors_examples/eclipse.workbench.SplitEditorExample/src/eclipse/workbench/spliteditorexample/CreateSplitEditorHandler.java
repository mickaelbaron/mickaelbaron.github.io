
package eclipse.workbench.spliteditorexample;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.EditorSashContainer;
import org.eclipse.ui.internal.EditorStack;
import org.eclipse.ui.internal.ILayoutContainer;
import org.eclipse.ui.internal.LayoutPart;
import org.eclipse.ui.internal.PartPane;
import org.eclipse.ui.internal.PartSashContainer;
import org.eclipse.ui.internal.PartSite;
import org.eclipse.ui.internal.PartStack;
import org.eclipse.ui.internal.WorkbenchPage;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
@SuppressWarnings("restriction")
public class CreateSplitEditorHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		IWorkbenchPage workbenchPage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		IWorkbenchPart part = workbenchPage.getActivePart();
		
		PartPane partPane = ((PartSite) part.getSite()).getPane();
		LayoutPart layoutPart = partPane.getPart();

		IEditorReference[] editorReferences = workbenchPage.getEditorReferences();
		// Do it only if we have more that one editor
		if (editorReferences.length > 1) {
			// Get PartPane that correspond to the active editor
			PartPane currentEditorPartPane = ((PartSite) workbenchPage.getActiveEditor().getSite()).getPane();
			EditorSashContainer editorSashContainer = null;
			ILayoutContainer rootLayoutContainer = layoutPart.getContainer();
			if (rootLayoutContainer instanceof LayoutPart) {
				ILayoutContainer editorSashLayoutContainer = ((LayoutPart) rootLayoutContainer).getContainer();
				if (editorSashLayoutContainer instanceof EditorSashContainer) {
					editorSashContainer = ((EditorSashContainer) editorSashLayoutContainer);
				}
			}
			/*
			 * Create a new part stack (i.e. a workbook) to home the currentEditorPartPane
			 * which hold the active editor
			 * */
			PartStack newPart = createStack(editorSashContainer);
			editorSashContainer.stack(currentEditorPartPane, newPart);
			if (rootLayoutContainer instanceof LayoutPart) {
				ILayoutContainer cont = ((LayoutPart) rootLayoutContainer).getContainer();

				if (cont instanceof PartSashContainer) {
					// "Split" the editor area by adding the new part
					((PartSashContainer) cont).add(newPart);
				}
			}
		}
		
		// TODO Auto-generated method stub
		return null;
	}

	private PartStack createStack(EditorSashContainer editorSashContainer) {
		WorkbenchPage workbenchPage = (WorkbenchPage) PlatformUI.getWorkbench().getActiveWorkbenchWindow()
				.getActivePage();
		EditorStack newWorkbook = EditorStack.newEditorWorkbook(editorSashContainer, workbenchPage);
		return newWorkbook;
	}
}
