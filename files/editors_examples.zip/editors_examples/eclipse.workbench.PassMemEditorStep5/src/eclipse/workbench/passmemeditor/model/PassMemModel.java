package eclipse.workbench.passmemeditor.model;

import java.util.ArrayList;
import java.util.List;

public class PassMemModel {
	
	private List<KeywordPosition> keywordPositions; 
	
	public PassMemModel() {
		keywordPositions = new ArrayList<KeywordPosition>();
	}
	
	public void addKeywordPosition(KeywordPosition current) {
		this.keywordPositions.add(current);
	}
	
	public List<KeywordPosition> getKeywordPositions() {
		return this.keywordPositions;
	}
}
