package eclipse.workbench.passmemeditor.model;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;

import eclipse.workbench.passmemeditor.PassMemSourceViewerConfiguration;

public final class PassMemParser {
	
	private IDocument fDocument;

	private int fLine;
	
	private int fLineCount;

	/**
	 * Parses a recipe in the passed document and returns it.
	 * 
	 * @param document
	 * @return the parsed recipe, <code>null</code> if there is no well-formed recipe
	 */
	public PassMemModel parse(IDocument document) {
		try {
			fDocument= document;
			fLine= 0;
			fLineCount= fDocument.getNumberOfLines();
			return parsePassMem();
		} catch (BadLocationException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private PassMemModel parsePassMem() throws BadLocationException {
		PassMemModel refModel = new PassMemModel();
		
		while (fLine < fLineCount) {
			IRegion region= fDocument.getLineInformation(fLine);
			String text= fDocument.get(region.getOffset(), region.getLength());
			
			for (int i = 0 ; i < PassMemSourceViewerConfiguration.KEYWORDS.length ; i++) {
				if (text.startsWith(PassMemSourceViewerConfiguration.KEYWORDS[i])) {
					refModel.addKeywordPosition(buildKeywordPosition(text, PassMemSourceViewerConfiguration.KEYWORDS[i], region.getOffset(), refModel));
				}	
			}
			fLine++;
		}
		return refModel;
	}
	
	private KeywordPosition buildKeywordPosition(String text, String keyword, int offset, PassMemModel pModel) {
		KeywordPosition refKeywordPosition = new KeywordPosition(keyword, offset, text.length());
		return refKeywordPosition;	
	}
}
