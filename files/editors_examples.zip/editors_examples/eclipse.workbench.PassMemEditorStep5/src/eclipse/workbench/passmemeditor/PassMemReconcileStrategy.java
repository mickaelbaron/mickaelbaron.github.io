package eclipse.workbench.passmemeditor;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.reconciler.DirtyRegion;
import org.eclipse.jface.text.reconciler.IReconcilingStrategy;
import org.eclipse.jface.text.reconciler.IReconcilingStrategyExtension;
import org.eclipse.jface.text.source.ISourceViewer;

import eclipse.workbench.passmemeditor.model.PassMemModel;
import eclipse.workbench.passmemeditor.model.PassMemParser;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemReconcileStrategy implements IReconcilingStrategy, IReconcilingStrategyExtension {

	private IDocument fDocument;
	
	private final PassMemEditorPart fEditor;
	
	public PassMemReconcileStrategy(ISourceViewer pSourceViewer, PassMemEditorPart refEditorPart) {
		fEditor = refEditorPart;
	}
	
	@Override
	public void reconcile(IRegion partition) {
		PassMemModel value = new PassMemParser().parse(fDocument);
		this.fEditor.setPassMemModel(value);
	}

	@Override
	public void reconcile(DirtyRegion dirtyRegion, IRegion subRegion) {
	}

	@Override
	public void setDocument(IDocument document) {
		fDocument = document;		
	}

	@Override
	public void initialReconcile() {
		reconcile(new Region(0, fDocument.getLength()));
		
	}

	@Override
	public void setProgressMonitor(IProgressMonitor monitor) {
	}
}
