package eclipse.workbench.passmemeditor.model;

public class KeywordPosition {

	private String key;
	
	private int offset;
	
	private int length;
	
	public KeywordPosition(String key, int offset, int length) {
		this.key = key;
		this.offset = offset;
		this.length = length;
	}
	
	public String getKey() {
		return key;
	}

	public int getOffSetPosition() {
		return offset;
	}

	public int getLength() {
		return length;
	}
}
