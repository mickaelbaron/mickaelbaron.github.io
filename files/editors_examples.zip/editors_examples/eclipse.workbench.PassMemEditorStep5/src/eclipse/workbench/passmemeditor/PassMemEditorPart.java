package eclipse.workbench.passmemeditor;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;
import org.eclipse.ui.texteditor.ContentAssistAction;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;

import eclipse.workbench.passmemeditor.model.KeywordPosition;
import eclipse.workbench.passmemeditor.model.PassMemModel;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemEditorPart extends AbstractDecoratedTextEditor {
	
	private PassMemOutlinePage fOutlinePage;
	
	private PassMemModel fPassMemModel;

	public PassMemEditorPart() {
		super();
		
		this.setSourceViewerConfiguration(
				new PassMemSourceViewerConfiguration(getSharedColors(), getPreferenceStore(), this));		
		this.setDocumentProvider(new PassDocumentProvider());
	}
		
	protected void createActions() {
		super.createActions();
		
		ContentAssistAction action= new ContentAssistAction(PassMemEditorMessages.getBundle(), "contentAssist.", this);
		action.setActionDefinitionId(ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
		setAction("ContentAssist", action);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Object getAdapter(Class required) {
		if (IContentOutlinePage.class.equals(required)) {
			if (fOutlinePage == null) {
				createOutlinePage();
			}

			return fOutlinePage;
		}

		return super.getAdapter(required);
	}
	
	private void createOutlinePage() {
		fOutlinePage = new PassMemOutlinePage(this);
		fOutlinePage.addSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				ISelection selection= event.getSelection();
				if (selection instanceof IStructuredSelection) {
					IStructuredSelection ss= (IStructuredSelection) selection;
					Object element= ss.getFirstElement();
					if (element instanceof KeywordPosition) {
						KeywordPosition re= (KeywordPosition) element;
						selectAndReveal(re.getOffSetPosition(), re.getLength());
					}
				}
			}
		});
	}
	
	public void setPassMemModel(PassMemModel passMemModel) {
		fPassMemModel = passMemModel;
		if (fOutlinePage != null)
			fOutlinePage.updatePassMemModel(passMemModel);
	}

	public PassMemModel getPassMemModel() {
		return fPassMemModel;
	}
}
