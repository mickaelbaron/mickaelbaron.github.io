package eclipse.workbench.passmemeditor;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;

import eclipse.workbench.passmemeditor.model.KeywordPosition;
import eclipse.workbench.passmemeditor.model.PassMemModel;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
final class PassMemOutlinePage extends ContentOutlinePage {
	private final PassMemEditorPart fEditor;

	private final class RecipeOutlineContentProvider implements
			ITreeContentProvider {
		@Override
		public void inputChanged(Viewer v, Object oldInput, Object newInput) {
		}
		
		@Override
		public void dispose() {
		}

		@Override
		public Object[] getElements(Object inputElement) {
			return getChildren(inputElement);
		}

		@Override
		public boolean hasChildren(Object element) {
			if (element instanceof PassMemModel) {
				return true;
			} else {
				return false;
			}
		}

		@Override
		public Object getParent(Object element) {
			return null;
		}

		@Override
		public Object[] getChildren(Object parentElement) {
			return ((PassMemModel)parentElement).getKeywordPositions().toArray();
		}
	}

	public PassMemOutlinePage(PassMemEditorPart editor) {
		fEditor = editor;
	}

	public void createControl(Composite parent) {
		super.createControl(parent);
		TreeViewer viewer = getTreeViewer();

		ITreeContentProvider contentProvider = new RecipeOutlineContentProvider();
		viewer.setContentProvider(contentProvider);
		viewer.setLabelProvider(new LabelProvider() {

			@Override
			public String getText(Object element) {
				if (element instanceof KeywordPosition) {
					final KeywordPosition currentKeywordPosition = (KeywordPosition)element;
					return currentKeywordPosition.getKey();
				} else {
					return super.getText(element);
				}
			}
		});
		viewer.setInput(fEditor.getPassMemModel());
	}

	public void updatePassMemModel(final PassMemModel recipe) {
		final TreeViewer viewer = getTreeViewer();
		if (viewer == null)
			return;

		runInSWTThread(viewer, new Runnable() {
			public void run() {
				viewer.setInput(recipe);
			}
		});
	}

	private void runInSWTThread(final TreeViewer viewer, Runnable runnable) {
		Display display = viewer.getControl().getDisplay();
		if (display.getThread() == Thread.currentThread())
			runnable.run();
		else
			display.asyncExec(runnable);
	}
}