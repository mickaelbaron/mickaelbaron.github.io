package eclipse.workbench.natureexample;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class CustomProjectNature implements IProjectNature {

	private IProject current;
	
	@Override
	public void configure() throws CoreException {
		final String BUILDER_ID = "eclipse.workbench.BuilderExample.samplebuilderid";
		IProjectDescription desc = current.getDescription();
		ICommand[] commands = desc.getBuildSpec();
	
		// Add builder to project
		ICommand command = desc.newCommand();
		command.setBuilderName(BUILDER_ID);
		ICommand[] newCommands = new ICommand[commands.length + 1];

		// Add it before other builders.
		System.arraycopy(commands, 0, newCommands, 1, commands.length);
		newCommands[0] = command;
		desc.setBuildSpec(newCommands);
		current.setDescription(desc, null);	
	}

	@Override
	public void deconfigure() throws CoreException {
	}

	@Override
	public IProject getProject() {
		return current;
	}

	@Override
	public void setProject(IProject project) {
		this.current = project;
	}
}
