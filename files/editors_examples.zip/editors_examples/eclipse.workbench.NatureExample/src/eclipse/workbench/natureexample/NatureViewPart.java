package eclipse.workbench.natureexample;

import java.io.ByteArrayInputStream;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class NatureViewPart extends ViewPart {

	public NatureViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout());
		
		Button createNature = new Button(parent, SWT.FLAT);
		createNature.setText("Associate Nature (add Builder by code ...");
		createNature.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				
				final IProject projectNature = root.getProject("Project Nature");

				try {
					if (!projectNature.exists()) {
						projectNature.create(null);	
						projectNature.open(null);
					}
					
					final IFile file = projectNature.getFile("file 1");
					if (!file.exists()) {
						file.create(new ByteArrayInputStream("HelloWorld\n This is text for Nature examples".getBytes()), IResource.NONE, null);
					}
						
					IProjectDescription description = projectNature.getDescription();
					String[] natures = description.getNatureIds();
					String[] newNatures = new String[natures.length + 1];
					System.arraycopy(natures, 0, newNatures, 0, natures.length);
					newNatures[natures.length] = "eclipse.workbench.NatureExample.samplenatureid";
					description.setNatureIds(newNatures);
					projectNature.setDescription(description, null);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
			
		Button createRequiresNature = new Button(parent, SWT.FLAT);
		createRequiresNature.setText("Associate Nature (add requires-nature constraint ...");
		createRequiresNature.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
				
				final IProject projectNature = root.getProject("Project Requires Nature");

				try {
					if (!projectNature.exists()) {
						projectNature.create(null);	
						projectNature.open(null);
					}
					
					final IFile file = projectNature.getFile("file 1");
					if (!file.exists()) {
						file.create(new ByteArrayInputStream("HelloWorld\n This is text for Nature examples".getBytes()), IResource.NONE, null);
					}
						
					IProjectDescription description = projectNature.getDescription();
					String[] natures = description.getNatureIds();
					String[] newNatures = new String[natures.length + 1];
					System.arraycopy(natures, 0, newNatures, 0, natures.length);
					newNatures[natures.length] = "eclipse.workbench.NatureExample.samplerequiresnaturesid";
					IStatus status = ResourcesPlugin.getWorkspace().validateNatureSet(newNatures);

					if (status.getCode() == IStatus.OK) {
						description.setNatureIds(newNatures);
						projectNature.setDescription(description, null);
					} else {
						System.out.println("Cannot enable this nature, nature is required.");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}
		});		
	}

	@Override
	public void setFocus() {
	}
}
