package eclipse.workbench.editoractionbarcontributorexample.editor;

import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.menus.CommandContributionItem;
import org.eclipse.ui.menus.CommandContributionItemParameter;
import org.eclipse.ui.part.EditorActionBarContributor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class EditorWithCommandActionBarContributor extends
		EditorActionBarContributor {

	@Override
	public void contributeToMenu(IMenuManager menuManager) {
		super.contributeToMenu(menuManager);
		
		CommandContributionItemParameter commandParameter = new CommandContributionItemParameter(
				PlatformUI.getWorkbench(), "contributionitem",
				"eclipse.workbench.editorexample.SimpleCommandId",
				CommandContributionItem.STYLE_PUSH);
		IContributionItem ref = new CommandContributionItem(commandParameter);
		
		IMenuManager menu = new MenuManager("Simple Editor");
		menuManager.prependToGroup(IWorkbenchActionConstants.MB_ADDITIONS, menu);
		menuManager.findMenuUsingPath("File").add(ref);

	}

	@Override
	public void contributeToStatusLine(IStatusLineManager statusLineManager) {
		CommandContributionItemParameter commandParameter = new CommandContributionItemParameter(
				PlatformUI.getWorkbench(), "contributionitem",
				"eclipse.workbench.editoractionbarcontributorexample.samplecommandid",
				CommandContributionItem.STYLE_PUSH);
		IContributionItem ref = new CommandContributionItem(commandParameter);

		statusLineManager.add(ref);
	}

	@Override
	public void contributeToToolBar(IToolBarManager toolBarManager) {
		CommandContributionItemParameter commandParameter = new CommandContributionItemParameter(
				PlatformUI.getWorkbench(), "contributionitem",
				"eclipse.workbench.editoractionbarcontributorexample.samplecommandid",
				CommandContributionItem.STYLE_PUSH);
		IContributionItem ref = new CommandContributionItem(commandParameter);

		toolBarManager.add(ref);
	}

	public EditorWithCommandActionBarContributor() {
	}
}
