package eclipse.workbench.passmemeditor;

import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;
import org.eclipse.ui.texteditor.ContentAssistAction;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemEditorPart extends AbstractDecoratedTextEditor {
	public PassMemEditorPart() {
		super();
		
		this.setSourceViewerConfiguration(
				new PassMemSourceViewerConfiguration(getSharedColors(), getPreferenceStore()));		
		this.setDocumentProvider(new PassDocumentProvider());
		
	}
	
	protected void createActions() {
		super.createActions();
		
		ContentAssistAction action= new ContentAssistAction(PassMemEditorMessages.getBundle(), "contentAssist.", this);
		action.setActionDefinitionId(ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
		setAction("ContentAssist", action);
	}
}
