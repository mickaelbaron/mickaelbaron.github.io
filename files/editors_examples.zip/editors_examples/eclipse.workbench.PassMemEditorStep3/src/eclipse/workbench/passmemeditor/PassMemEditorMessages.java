package eclipse.workbench.passmemeditor;

import java.util.ResourceBundle;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemEditorMessages {
	public static ResourceBundle getBundle() {
		return ResourceBundle.getBundle(PassMemEditorMessages.class.getName());
	}
}
