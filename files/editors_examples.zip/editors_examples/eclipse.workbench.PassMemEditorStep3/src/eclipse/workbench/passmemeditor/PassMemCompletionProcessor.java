package eclipse.workbench.passmemeditor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.CompletionProposal;
import org.eclipse.jface.text.contentassist.ContextInformation;
import org.eclipse.jface.text.contentassist.ContextInformationValidator;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemCompletionProcessor implements IContentAssistProcessor {
	
	@Override
	public char[] getCompletionProposalAutoActivationCharacters() {
		return new char[] {'@'};
	}

	@Override
	public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer, int offset) {
		IDocument document = viewer.getDocument();
		int currOffset = offset - 1;
		
		String currWord = "";
		try {
			char currChar;
			while (currOffset > 0 && !Character.isWhitespace(currChar = document.getChar(currOffset))) {
				currWord = currChar + currWord;
				currOffset--;
			}

			List<String> currentSuggests = buildSuggests(currWord);
			ICompletionProposal[] proposals = null;
			if (currentSuggests.size() > 0) {
				proposals = buildProposals(currentSuggests, currWord, offset - currWord.length());
			}
			return proposals;
		} catch (BadLocationException e) {
			e.printStackTrace();
			return null;
		}
	}

	private List<String> buildSuggests(String word) {
		List<String> current = new ArrayList<String>();
		
		for (int i = 0 ; i < PassMemSourceViewerConfiguration.KEYWORDS.length ; i++) {
			if (PassMemSourceViewerConfiguration.KEYWORDS[i].startsWith(word)) {
				current.add(PassMemSourceViewerConfiguration.KEYWORDS[i]);
			}
		}		
		return current;
	}
	
	private ICompletionProposal[] buildProposals(List<String> suggestions, String replacedWord, int offset) {
		ICompletionProposal[] proposals = new ICompletionProposal[suggestions.size()];
		int index = 0;
		for (Iterator<String> i = suggestions.iterator(); i.hasNext();) {
			String currSuggestion = (String) i.next();
			IContextInformation contextInfo = new ContextInformation(null, currSuggestion);			
			proposals[index] = new CompletionProposal(currSuggestion, offset,
					replacedWord.length(), currSuggestion.length(), null, currSuggestion, contextInfo,currSuggestion);
			index++;
		}
		return proposals;
	}
	

	@Override
	public char[] getContextInformationAutoActivationCharacters() {
		return new char[] {'-'};
	}

	@Override
	public IContextInformation[] computeContextInformation(ITextViewer viewer, int offset) {
		ContextInformation[] contextInfos = new ContextInformation[PassMemSourceViewerConfiguration.KEYWORDS.length];

		for (int i = 0; i < contextInfos.length; i++) {
			contextInfos[i] = new ContextInformation(null, PassMemSourceViewerConfiguration.KEYWORDS[i]);
		}

		return contextInfos;
	}

	@Override
	public String getErrorMessage() {
		return null;
	}

	@Override
	public IContextInformationValidator getContextInformationValidator() {
		return new ContextInformationValidator(this);
	}
}
