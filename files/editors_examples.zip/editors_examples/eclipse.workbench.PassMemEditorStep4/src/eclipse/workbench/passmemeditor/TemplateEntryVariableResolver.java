package eclipse.workbench.passmemeditor;

import org.eclipse.jface.text.templates.TemplateContext;
import org.eclipse.jface.text.templates.TemplateVariableResolver;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class TemplateEntryVariableResolver extends TemplateVariableResolver {

	@Override
	protected String[] resolveAll(TemplateContext context) {
		return new String[] {"twitter", "gmail"};
	}
}
