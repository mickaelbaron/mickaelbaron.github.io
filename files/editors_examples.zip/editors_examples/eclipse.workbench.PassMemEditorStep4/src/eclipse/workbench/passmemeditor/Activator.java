package eclipse.workbench.passmemeditor;

import java.io.IOException;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.editors.text.templates.ContributionContextTypeRegistry;
import org.eclipse.ui.editors.text.templates.ContributionTemplateStore;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class Activator extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "eclipse.workbench.passmemeditorstep4";

	private ContributionTemplateStore fTemplateStore;
	
	private ContributionContextTypeRegistry fRegistry;
	
	public static final String PASS_MEM_TEMPLATE_CONTEXT= "eclipse.workbench.passmemeditorstep4.templatecontextid";
	
	private static final String TEMPLATES_PREFERENCE_KEY= "templates"; //$NON-NLS-1$
	
	// The shared instance
	private static Activator plugin;
	
	/**
	 * The constructor
	 */
	public Activator() {
	}

	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}
	
	public ContributionTemplateStore getTemplateStore() {
		if (fTemplateStore == null) { 
			fTemplateStore= new ContributionTemplateStore(getContextTypeRegistry(), getPreferenceStore(), TEMPLATES_PREFERENCE_KEY);
			try {
				fTemplateStore.load();
			} catch (IOException x) {
				x.printStackTrace();
			}
		}
		return fTemplateStore;
	}
	
	public ContributionContextTypeRegistry getContextTypeRegistry() {
		if (fRegistry == null) {
			fRegistry= new ContributionContextTypeRegistry();
			fRegistry.addContextType(PASS_MEM_TEMPLATE_CONTEXT);
		}	
		return fRegistry;
	}
	
	public static Image getImage(String id) {
		ImageRegistry imageRegistry= getDefault().getImageRegistry();
		Image image= imageRegistry.get(id);
		if (image == null) {
			imageRegistry.put(id, ImageDescriptor.createFromURL(Activator.getDefault().getBundle().getEntry("/icons/" + id + ".gif"))); //$NON-NLS-1$ //$NON-NLS-2$
			image= imageRegistry.get(id);
		}
		return image;
	}
}
