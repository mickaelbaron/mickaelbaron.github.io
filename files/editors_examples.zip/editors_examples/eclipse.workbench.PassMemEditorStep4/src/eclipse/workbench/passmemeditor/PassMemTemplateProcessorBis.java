package eclipse.workbench.passmemeditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.CompletionProposal;
import org.eclipse.jface.text.contentassist.ContextInformation;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.templates.Template;
import org.eclipse.jface.text.templates.TemplateCompletionProcessor;
import org.eclipse.jface.text.templates.TemplateContextType;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.editors.text.templates.ContributionTemplateStore;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemTemplateProcessorBis extends TemplateCompletionProcessor {

	@Override
	protected TemplateContextType getContextType(ITextViewer viewer,
			IRegion region) {
		return Activator.getDefault().getContextTypeRegistry().getContextType(Activator.PASS_MEM_TEMPLATE_CONTEXT);
	}

	@Override
	protected Image getImage(Template template) {
		return Activator.getImage("template");
	}

	@Override
	protected Template[] getTemplates(String contextTypeId) {
		ContributionTemplateStore templateStore= Activator.getDefault().getTemplateStore();
		return templateStore.getTemplates(contextTypeId);
	}
	
	@Override
	public char[] getCompletionProposalAutoActivationCharacters() {
		return new char[] {'@'};
	}

	@Override
	public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer, int offset) {
		final ICompletionProposal[] computeCompletionProposals = super.computeCompletionProposals(viewer, offset);
		
		IDocument document = viewer.getDocument();
		int currOffset = offset - 1;
		
		String currWord = "";
		try {
			char currChar;
			while (currOffset > 0 && !Character.isWhitespace(currChar = document.getChar(currOffset))) {
				currWord = currChar + currWord;
				currOffset--;
			}

			List<String> currentSuggests = buildSuggests(currWord);
			ICompletionProposal[] proposals = null;
			if (currentSuggests.size() > 0) {
				proposals = buildProposals(currentSuggests, currWord, offset - currWord.length());
			}
			
			final ICompletionProposal[] copyOf = Arrays.copyOf(computeCompletionProposals, computeCompletionProposals.length + proposals.length);
			
			for (int i = 0 ; i < proposals.length ; i++) {
				copyOf[i+computeCompletionProposals.length] = proposals[i];
			}
			
			return copyOf;
		} catch (BadLocationException e) {
			e.printStackTrace();
			return null;
		}
	}

	private List<String> buildSuggests(String word) {
		List<String> current = new ArrayList<String>();
		
		for (int i = 0 ; i < PassMemSourceViewerConfiguration.KEYWORDS.length ; i++) {
			if (PassMemSourceViewerConfiguration.KEYWORDS[i].startsWith(word)) {
				current.add(PassMemSourceViewerConfiguration.KEYWORDS[i]);
			}
		}		
		return current;
	}
	
	private ICompletionProposal[] buildProposals(List<String> suggestions, String replacedWord, int offset) {
		ICompletionProposal[] proposals = new ICompletionProposal[suggestions.size()];
		int index = 0;
		for (Iterator<String> i = suggestions.iterator(); i.hasNext();) {
			String currSuggestion = (String) i.next();
			IContextInformation contextInfo = new ContextInformation(null, currSuggestion);			
			proposals[index] = new CompletionProposal(currSuggestion, offset,
					replacedWord.length(), currSuggestion.length(), null, currSuggestion, contextInfo,currSuggestion);
			index++;
		}
		return proposals;
	}
}
