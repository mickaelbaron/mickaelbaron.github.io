package eclipse.workbench.passmemeditor;

import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.templates.Template;
import org.eclipse.jface.text.templates.TemplateCompletionProcessor;
import org.eclipse.jface.text.templates.TemplateContextType;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.editors.text.templates.ContributionTemplateStore;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
public class PassMemTemplateProcessor extends TemplateCompletionProcessor {

	@Override
	protected TemplateContextType getContextType(ITextViewer viewer,
			IRegion region) {
		return Activator.getDefault().getContextTypeRegistry().getContextType(Activator.PASS_MEM_TEMPLATE_CONTEXT);
	}

	@Override
	protected Image getImage(Template template) {
		return Activator.getImage("template");
	}

	@Override
	protected Template[] getTemplates(String contextTypeId) {
		ContributionTemplateStore templateStore= Activator.getDefault().getTemplateStore();
		return templateStore.getTemplates(contextTypeId);
	}
}
