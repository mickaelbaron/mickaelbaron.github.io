package eclipse.swt.SWTTipOfTheDay.model;

/**
 * A tip.
 * 
 * Based on SwingX project (http://swinglabs.org/) 
 * Original author Frederic Lavigne (fred@L2FProd.com)
 */
public interface Tip {

	String getTipName();

	Object getTip();
}
