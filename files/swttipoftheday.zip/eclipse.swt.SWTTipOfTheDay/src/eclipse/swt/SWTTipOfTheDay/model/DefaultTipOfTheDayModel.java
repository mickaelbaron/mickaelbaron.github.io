package eclipse.swt.SWTTipOfTheDay.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * Default TipOfTheDayModel implementation.
 * 
 * Based on SwingX project (http://swinglabs.org/) 
 * Original author Frederic Lavigne (fred@L2FProd.com)
 */
public class DefaultTipOfTheDayModel implements TipOfTheDayModel {

	private List<Tip> tips = new ArrayList<Tip>();

	public DefaultTipOfTheDayModel() {
	}

	public DefaultTipOfTheDayModel(Tip[] tips) {
		this(Arrays.asList(tips));
	}

	public DefaultTipOfTheDayModel(Collection<Tip> tips) {
		this.tips.addAll(tips);
	}

	public Tip getTipAt(int index) {
		return tips.get(index);
	}

	public int getTipCount() {
		return tips.size();
	}

	public void add(Tip tip) {
		tips.add(tip);
	}

	public void remove(Tip tip) {
		tips.remove(tip);
	}

	public Tip[] getTips() {
		return tips.toArray(new Tip[tips.size()]);
	}

	public void setTips(Tip[] tips) {
		this.tips.clear();
		this.tips.addAll(Arrays.asList(tips));
	}

}
