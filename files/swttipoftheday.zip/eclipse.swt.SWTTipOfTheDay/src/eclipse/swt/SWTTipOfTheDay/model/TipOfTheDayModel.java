package eclipse.swt.SWTTipOfTheDay.model;

/**
 * A model for SWTTipOfTheDay.
 * 
 * Based on SwingX project (http://swinglabs.org/) 
 * Original author Frederic Lavigne (fred@L2FProd.com)
 */
public interface TipOfTheDayModel {

	int getTipCount();

	Tip getTipAt(int index);
}
