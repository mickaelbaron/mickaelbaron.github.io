package eclipse.swt.SWTTipOfTheDay.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Loads tips from Properties.
 * 
 * Based on SwingX project (http://swinglabs.org/) 
 * Original author Frederic Lavigne (fred@L2FProd.com)
 */
public class TipLoader {

	private TipLoader() {
	}

	public static TipOfTheDayModel load(Properties props) {
		List<Tip> tips = new ArrayList<Tip>();

		int count = 1;
		while (true) {
			String nameKey = "tip." + count + ".name";
			String nameValue = props.getProperty(nameKey);

			String descriptionKey = "tip." + count + ".description";
			String descriptionValue = props.getProperty(descriptionKey);

			if (nameValue != null && descriptionValue == null) {
				throw new IllegalArgumentException("No description for name "
						+ nameValue);
			}

			if (descriptionValue == null) {
				break;
			}

			DefaultTip tip = new DefaultTip(nameValue, descriptionValue);
			tips.add(tip);

			count++;
		}

		return new DefaultTipOfTheDayModel(tips);
	}
}
