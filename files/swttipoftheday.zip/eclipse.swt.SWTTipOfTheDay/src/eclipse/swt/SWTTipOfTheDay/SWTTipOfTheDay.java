package eclipse.swt.SWTTipOfTheDay;

import java.awt.HeadlessException;
import java.util.Observable;
import java.util.prefs.Preferences;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Shell;

import eclipse.swt.SWTTipOfTheDay.model.DefaultTipOfTheDayModel;
import eclipse.swt.SWTTipOfTheDay.model.Tip;
import eclipse.swt.SWTTipOfTheDay.model.TipOfTheDayModel;
import eclipse.swt.SWTTipOfTheDay.ui.SWTTipOfTheDayUI;

/**
 * Dialog controller of the SWTTipOfTheDay component.   
 * 
 * Based on SwingX project (http://swinglabs.org/) 
 * Original author Frederic Lavigne (fred@L2FProd.com)
 * 
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : January 2008
 */
public class SWTTipOfTheDay extends Observable {

	private static final long serialVersionUID = -8976156934177938171L;

	public static final String PREFERENCE_KEY = "ShowTipOnStartup";

	public static final String CURRENT_TIP_CHANGED_KEY = "currentTip";

	private TipOfTheDayModel model;

	private int currentTip = 0;

	private SWTTipOfTheDayUI tipOfTheDayUI;

	public SWTTipOfTheDay() {
		this(new DefaultTipOfTheDayModel(new Tip[0]));
	}

	public SWTTipOfTheDay(TipOfTheDayModel model) {
		this.model = model;
		tipOfTheDayUI = new SWTTipOfTheDayUI(this);
		this.addObserver(tipOfTheDayUI);
	}

	public TipOfTheDayModel getModel() {
		return model;
	}

	public void setModel(TipOfTheDayModel model) {
		if (model == null) {
			throw new IllegalArgumentException("model can not be null");
		}
		this.model = model;
	}

	public int getCurrentTip() {
		return currentTip;
	}

	public void setCurrentTip(int currentTip) {
		if (currentTip < 0 || currentTip >= getModel().getTipCount()) {
			throw new IllegalArgumentException(
					"Current tip must be within the bounds [0, "
							+ getModel().getTipCount() + "[");
		}

		this.currentTip = currentTip;
		this.setChanged();
		this.notifyObservers();
	}

	public void nextTip() {
		int count = getModel().getTipCount();
		if (count == 0) {
			return;
		}

		int nextTip = currentTip + 1;
		if (nextTip >= count) {
			nextTip = 0;
		}
		setCurrentTip(nextTip);
	}

	public void previousTip() {
		int count = getModel().getTipCount();
		if (count == 0) {
			return;
		}

		int previousTip = currentTip - 1;
		if (previousTip < 0) {
			previousTip = count - 1;
		}
		setCurrentTip(previousTip);
	}

	public void showDialog(Shell parentShell) throws HeadlessException {
		showDialog(parentShell, (ShowOnStartupChoice) null);
	}

	public boolean showDialog(Shell parentShell, Preferences showOnStartupPref)
			throws HeadlessException {
		return showDialog(parentShell, showOnStartupPref, false);
	}

	public boolean showDialog(Shell parentShell,
			final Preferences showOnStartupPref, boolean force)
			throws HeadlessException {
		if (showOnStartupPref == null) {
			throw new IllegalArgumentException("Preferences can not be null");
		}

		ShowOnStartupChoice store = new ShowOnStartupChoice() {
			public boolean isShowingOnStartup() {
				return showOnStartupPref.getBoolean(PREFERENCE_KEY, true);
			}

			public void setShowingOnStartup(boolean showOnStartup) {
				if (showOnStartup
						&& !showOnStartupPref.getBoolean(PREFERENCE_KEY, true)) {
					showOnStartupPref.remove(PREFERENCE_KEY);
				} else if (!showOnStartup) {
					showOnStartupPref.putBoolean(PREFERENCE_KEY, showOnStartup);
				}
			}
		};
		return showDialog(parentShell, store, force);
	}

	public boolean showDialog(Shell parentShell, ShowOnStartupChoice choice) {
		return showDialog(parentShell, choice, false);
	}

	public boolean showDialog(Shell parentShell, ShowOnStartupChoice choice,
			boolean force) {
		if (choice == null) {
			createDialog(parentShell, choice);
			return true;
		} else if (force || choice.isShowingOnStartup()) {
			createDialog(parentShell, choice);
			return choice.isShowingOnStartup();
		} else {
			return false;
		}
	}

	public static boolean isShowingOnStartup(Preferences showOnStartupPref) {
		return showOnStartupPref.getBoolean(PREFERENCE_KEY, true);
	}

	public static void forceShowOnStartup(Preferences showOnStartupPref) {
		showOnStartupPref.remove(PREFERENCE_KEY);
	}

	protected Dialog createDialog(Shell parentComponent,
			ShowOnStartupChoice choice) {
		return this.tipOfTheDayUI.createDialog(parentComponent, choice);
	}

	public static interface ShowOnStartupChoice {

		void setShowingOnStartup(boolean showOnStartup);

		boolean isShowingOnStartup();
	}
}
