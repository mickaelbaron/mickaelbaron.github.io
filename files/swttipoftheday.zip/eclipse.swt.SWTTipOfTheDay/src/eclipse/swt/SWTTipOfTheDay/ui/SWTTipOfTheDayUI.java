package eclipse.swt.SWTTipOfTheDay.ui;

import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import eclipse.swt.SWTTipOfTheDay.SWTTipOfTheDay;
import eclipse.swt.SWTTipOfTheDay.SWTTipOfTheDay.ShowOnStartupChoice;
import eclipse.swt.SWTTipOfTheDay.model.Tip;

/**
 * SWT implementation of the SWTTipOfTheDay UI.   
 * 
 * Based on SwingX project (http://swinglabs.org/) 
 * Original author Frederic Lavigne (fred@L2FProd.com)
 * 
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : January 2008
 */
public class SWTTipOfTheDayUI extends TipOfTheDayUI implements Observer {

	private static final String TIP_IMAGE = "/eclipse/swt/SWTTipOfTheDay/resources/tipoftheday48.png";

	public static final String RESOURCES_PATH = "eclipse/swt/SWTTipOfTheDay/resources/SWTTipOfTheDay";

	protected SWTTipOfTheDay tipPane;

	protected Composite tipArea;

	protected Control currentTipComponent;
	
	public SWTTipOfTheDayUI(SWTTipOfTheDay tipPane) {
		this.tipPane = tipPane;
	}

	public Dialog createDialog(Shell parentShell, ShowOnStartupChoice choice) {
		return createDialog(parentShell, choice, true);
	}

	protected Dialog createDialog(Shell parentShell,
			final ShowOnStartupChoice choice, boolean showPreviousButton) {
		ResourceBundle messages = ResourceBundle.getBundle(RESOURCES_PATH);
			
		String title = messages.getString("SWTTipOfTheDay.dialogTitle");

		final Button showOnStartupBox;

		final SWTTipOfTheDayDialog myDialog = new SWTTipOfTheDayDialog(
				parentShell, 0);
		Shell shellDialog = myDialog.getShellDialog();
		shellDialog.setText(title);
		shellDialog.setLayout(new GridLayout(1, false));

		// Content
		Composite content = new Composite(shellDialog, SWT.BORDER);
		GridLayout gridLayout = new GridLayout(2, false);
		gridLayout.marginLeft = 0;
		gridLayout.marginTop = 0;
		gridLayout.marginBottom = 0;
		gridLayout.marginRight = 0;
		gridLayout.horizontalSpacing = -5;
		content.setLayout(gridLayout);
		GridData gridData = new GridData(GridData.FILL_BOTH);
		content.setLayoutData(gridData);

		Composite tipIconComposite = new Composite(content, SWT.NONE);
		tipIconComposite.setLayout(new GridLayout(1, true));
		tipIconComposite.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_DARK_GRAY));
		gridData = new GridData(GridData.FILL_VERTICAL);
		tipIconComposite.setLayoutData(gridData);
		
		Label tipIcon = new Label(tipIconComposite, SWT.NONE);
		tipIcon.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_DARK_GRAY));
		tipIcon.setImage(new Image(Display.getCurrent(), SWTTipOfTheDayUI.class.getResourceAsStream(TIP_IMAGE)));

		gridData = new GridData(GridData.FILL_VERTICAL);
		gridData.horizontalAlignment = SWT.LEFT;
		gridData.verticalAlignment = SWT.TOP;
		gridData.heightHint = 32;
		gridData.widthHint = 60;
		gridData.verticalIndent = 50;
		gridData.horizontalIndent = 36;
		tipIcon.setLayoutData(gridData);

		Composite rightPane = new Composite(content, SWT.NONE);
		gridLayout = new GridLayout(1, true);
		gridLayout.marginLeft = 0;
		gridLayout.marginTop = -5;
		gridLayout.marginBottom = -5;
		gridLayout.marginRight = -5;
		gridLayout.verticalSpacing = 10;
		rightPane.setLayout(gridLayout);
		gridData = new GridData(GridData.FILL_BOTH);
		rightPane.setLayoutData(gridData);
		
		Composite didYouKnowComposite = new Composite(rightPane, SWT.NONE);
		gridLayout = new GridLayout(1, true);
		gridLayout.marginTop = -5;
		gridLayout.marginBottom = -5;
		didYouKnowComposite.setLayout(gridLayout);
		gridData = new GridData(GridData.FILL_HORIZONTAL);
		didYouKnowComposite.setLayoutData(gridData);
		
		Label didYouKnow = new Label(didYouKnowComposite, SWT.NONE);
		didYouKnow.setText(messages.getString("SWTTipOfTheDay.didYouKnowText"));
		Font font = new Font(shellDialog.getDisplay(), "Helvetica", 15, SWT.BOLD);
		didYouKnow.setFont(font);

		Composite hRule = new Composite(rightPane, SWT.NONE);
		hRule
				.setBackground(Display.getCurrent().getSystemColor(
						SWT.COLOR_DARK_GRAY));
		gridData = new GridData(GridData.FILL_HORIZONTAL);
		gridData.heightHint = 5;
		hRule.setLayoutData(gridData);

		tipArea = new Composite(rightPane, SWT.NONE);
		gridLayout = new GridLayout(1, true);
		gridLayout.marginTop = -5;
		gridLayout.marginBottom = -5;
		gridLayout.marginRight = -5;
		tipArea.setLayout(gridLayout);
		gridData = new GridData(GridData.FILL_BOTH);
		gridData.minimumWidth = 400;
		gridData.minimumHeight = 200;
		tipArea.setLayoutData(gridData);

		// Tip controls
		Composite controls = new Composite(shellDialog, SWT.NONE);
		gridLayout = new GridLayout(2, false);
		controls.setLayout(gridLayout);
		gridData = new GridData();
		gridData.horizontalSpan = 2;
		gridData.horizontalAlignment = SWT.FILL;
		controls.setLayoutData(gridData);

		if (choice != null) {
			showOnStartupBox = new Button(controls, SWT.CHECK);
			gridData = new GridData();
			gridData.horizontalAlignment = SWT.LEFT;
			gridData.horizontalSpan = 1;
			showOnStartupBox.setLayoutData(gridData);
			showOnStartupBox.setText(messages.getString("SWTTipOfTheDay.showOnStartupText"));
			showOnStartupBox.setSelection(choice.isShowingOnStartup());
		} else {
			showOnStartupBox = null;
		}

		Composite buttons = new Composite(controls, SWT.NONE);
		buttons.setLayout(new GridLayout(showPreviousButton ? 3 : 2, true));
		gridData = new GridData();
		gridData.grabExcessHorizontalSpace = true;
		gridData.horizontalAlignment = SWT.END;
		buttons.setLayoutData(gridData);

		if (showPreviousButton) {
			Button previousTipButton = new Button(buttons, SWT.FLAT);
			previousTipButton.setText(messages.getString("SWTTipOfTheDay.previousTipText"));
			previousTipButton.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
					tipPane.previousTip();
				}
			});
		}

		Button nextTipButton = new Button(buttons, SWT.FLAT);
		nextTipButton.setText(messages.getString("SWTTipOfTheDay.nextTipText"));
		nextTipButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				tipPane.nextTip();
			}
		});

		Button closeButton = new Button(buttons, SWT.FLAT);
		closeButton.setText(messages.getString("SWTTipOfTheDay.closeText"));

		final SelectionListener saveChoice = new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				if (choice != null) {
					choice.setShowingOnStartup(showOnStartupBox.getSelection());
				}
				myDialog.close();
			}
		};

		closeButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				saveChoice.widgetSelected(null);
			}
		});
		shellDialog.setDefaultButton(closeButton);

		shellDialog.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				saveChoice.widgetSelected(null);
			}
		});
		
		shellDialog.pack();
		this.showCurrentTip();
		myDialog.open();
		return myDialog;
	}

	protected void showCurrentTip() {
		if (currentTipComponent != null) {
			currentTipComponent.dispose();
		}

		int currentTip = tipPane.getCurrentTip();
		if (currentTip == -1) {
			Label label = new Label(tipArea, SWT.NONE);
			currentTipComponent = label;
			return;
		}

		if (tipPane.getModel() == null
				|| tipPane.getModel().getTipCount() == 0
				|| (currentTip < 0 && currentTip >= tipPane.getModel()
						.getTipCount())) {
			currentTipComponent = new Label(tipArea, SWT.NONE);
			GridData gridData = new GridData(GridData.FILL_BOTH);
			currentTipComponent.setLayoutData(gridData);
		} else {
			Tip tip = tipPane.getModel().getTipAt(currentTip);

			Object tipObject = tip.getTip();
			if (tipObject instanceof Control) {
				currentTipComponent = (Control) tipObject;
			} else {
				Text tipText = new Text(tipArea, SWT.WRAP | SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
				GridData gridData = new GridData(GridData.FILL_BOTH);
				tipText.setLayoutData(gridData);
				
				String text = tipObject == null ? "" : tipObject.toString();

				tipText.setText(text);
				currentTipComponent = tipText;
			}
			// TODO : HTML renderer via SWT Browser.
		}
		tipArea.layout(true);
	}

	private static class SWTTipOfTheDayDialog extends Dialog {

		private Shell shellDialog;

		public SWTTipOfTheDayDialog(Shell parentShell, int style) {
			super(parentShell, style);
			Shell parent = getParent();
			shellDialog = new Shell(parent, SWT.SHELL_TRIM
					| SWT.APPLICATION_MODAL);
		}

		public void open() {
			Shell parent = getParent();
			Display display = parent.getDisplay();
			
			if (display != null && shellDialog != null) {
				Rectangle clientAreaRectangle = display.getClientArea();
				
				if (clientAreaRectangle != null && clientAreaRectangle.width > 0 && clientAreaRectangle.height > 0) {
					shellDialog.setLocation((int)((clientAreaRectangle.width - shellDialog.getSize().x) / 2), (int)((clientAreaRectangle.height - shellDialog.getSize().y) / 2));
				}
			}
			
			shellDialog.open();
			while (!shellDialog.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		}
	
		public Shell getShellDialog() {
			return shellDialog;
		}

		public void close() {
			shellDialog.dispose();
		}
	}

	public void update(Observable o, Object arg) {
		this.showCurrentTip();
	}
}
