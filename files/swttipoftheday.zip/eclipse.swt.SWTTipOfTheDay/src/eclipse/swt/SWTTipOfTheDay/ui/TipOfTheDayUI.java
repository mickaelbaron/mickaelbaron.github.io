package eclipse.swt.SWTTipOfTheDay.ui;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Shell;

import eclipse.swt.SWTTipOfTheDay.SWTTipOfTheDay;

/**
 * Description of the SWTTipOfTheDay UI.   
 * 
 * Based on SwingX project (http://swinglabs.org/) 
 * Original author Frederic Lavigne (fred@L2FProd.com)
 * 
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : January 2008
 */
public abstract class TipOfTheDayUI {

	public abstract Dialog createDialog(Shell parentComposite,
			SWTTipOfTheDay.ShowOnStartupChoice choice);
}