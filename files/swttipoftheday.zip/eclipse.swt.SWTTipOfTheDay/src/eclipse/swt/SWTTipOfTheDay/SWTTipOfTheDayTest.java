package eclipse.swt.SWTTipOfTheDay;

import java.util.prefs.Preferences;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import eclipse.swt.SWTTipOfTheDay.model.DefaultTip;
import eclipse.swt.SWTTipOfTheDay.model.DefaultTipOfTheDayModel;

/**
 * Test class of the SWTTipOfTheDay component.
 * 
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : January 2008
 */
public class SWTTipOfTheDayTest {

	public SWTTipOfTheDayTest() {
		DefaultTipOfTheDayModel tips = new DefaultTipOfTheDayModel();

		tips.add(new DefaultTip("tip1", "This is the first tip "
				+ "This is the first tip " + "This is the first tip "
				+ "This is the first tip " + "This is the first tip "
				+ "This is the first tip\n" + "This is the first tip "
				+ "This is the first tip"));

		tips.add(new DefaultTip("tip2", "This is the second tip "
				+ "This is the second tip " + "This is the second tip \n"
				+ "This is the second tip " + "This is the second tip "
				+ "This is the second tip \n" + "This is the second tip "
				+ "This is the second tip"));

		final SWTTipOfTheDay current = new SWTTipOfTheDay(tips);

		final Preferences myPref = Preferences.systemNodeForPackage(current
				.getClass());
		Preferences.systemRoot();

		Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, true));
		shell.setText("Test class of the SWTTipOfTheDay Component");
		shell.setSize(200, 200);

		shell.setLayout(new GridLayout());
		Button myButton = new Button(shell, SWT.FLAT);
		myButton.setText("Open the SWTTipOfTheDay dialog");
		GridData myGridData = new GridData(GridData.FILL_BOTH);
		myButton.setLayoutData(myGridData);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				current.showDialog(shell, myPref, true); 
					// True = to force the opening of the SWTTipOfTheDay dialog
			}
		});

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] args) {
		new SWTTipOfTheDayTest();
	}
}
