package eclipse.workbench.commandsperspectiveexample;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2009
 */
public class CommandsViewSamplePart extends ViewPart {

	public CommandsViewSamplePart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1,true));
		Label myLabel = new Label(parent, SWT.NONE);
		myLabel.setText("Simple Text");
	}

	@Override
	public void setFocus() {
	}
}
