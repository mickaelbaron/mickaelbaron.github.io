package org.keulkeul;

import java.io.File;
import java.util.Hashtable;

import javax.swing.JLabel;

import quicktime.QTException;
import quicktime.app.view.MoviePlayer;
import quicktime.app.view.QTFactory;
import quicktime.app.view.QTJComponent;
import quicktime.io.OpenMovieFile;
import quicktime.io.QTFile;
import quicktime.std.StdQTConstants;
import quicktime.std.StdQTException;
import quicktime.std.clocks.ExtremesCallBack;
import quicktime.std.movies.Movie;
import quicktime.std.movies.TimeInfo;
import quicktime.util.QTUtils;

/**
 * Copyright (C) 2006  Mickaël BARON
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * @author Mickaël BARON (baron.mickael@gmail.com)
 **/
public class QuickTimePlayerControl {
	
    private Movie currentMovie;
    
	private boolean isPlayingWithMark = false;
	
	private boolean isPlaying = false;
	
	private boolean isFinished = false;
    
	private int duration = 0;
	
	private int startMark = - 1;
	
	private int finishMark = - 1;	
	   
	private boolean mousePressed = false;

	private boolean keyPressed = false;
	
	private String mediaFileName = ""; 
	
	private String mediaFilePath = "";
	
	private QuickTimePlayerUI refUI;
		
	public QuickTimePlayerControl() {
		refUI = new QuickTimePlayerUI(this);
        this.processInitPlayer();
		refUI.setVisible(true);
	}
	
    public void openMovie(QTFile qtf) {
    	try {
	        mediaFileName = qtf.getName();
	        mediaFilePath = qtf.getParent();
	        if (mediaFilePath == null) {
	        	mediaFilePath = "";
	        }
	        OpenMovieFile openqtfile = OpenMovieFile.asRead(qtf);
	        currentMovie = Movie.fromFile(openqtfile);
	        MoviePlayer mp = new MoviePlayer(currentMovie);
	        QTJComponent qc = QTFactory.makeQTJComponent(mp);
	        duration = currentMovie.getDuration();
	        new MyQTCallback(currentMovie);
	        refUI.openNewMovie(qc, duration , getTimeWithFormat(duration / currentMovie.getTimeScale()), mediaFilePath + File.separator + mediaFileName,qtf.length() / 1024);
	        if (startMark != -1) {
	        	this.startMarkMovie();
	        }
	        
	        if (finishMark != -1) {
	        	this.finishMarkMovie();
	        }
	        
	    } catch (QTException e) {
	        refUI.hideMoviePanel();
	    } catch (Exception e) {
	    	refUI.hideMoviePanel();
	    } finally {            
	        QTUtils.reclaimMemory(); 
	    }        	
    }
    
    public void openFromBrowse () {
        try {
        	this.stopMovie();
            QTFile qtf = QTFile.standardGetFilePreview(QTFile.kStandardQTFileTypes);
            this.openMovie(qtf);
        } catch (QTException e) {
            refUI.hideMoviePanel();
        } finally {            
            QTUtils.reclaimMemory(); 
        }
    }
    
    public void closeMediaEditor() {
        stopMovie();
        refUI.stopTimer();
        refUI.setVisible(false);
        System.exit(0);
    } 
    
    public void stopMovie() {
    	if (currentMovie != null) {
    		try {
    			currentMovie.stop();    		
    		} catch (StdQTException exe) {
    			exe.printStackTrace();
    		}
    	}
    }
    
	public void removeCurrentMovie() {
		if (currentMovie == null) {
			return;
		}
		try {
			currentMovie.stop();
		} catch (QTException qte) {
			qte.printStackTrace();
		}
		refUI.stopTimer();
		this.processInitPlayer();
	}
    
    private void startMarkMovie() {
		Hashtable<Integer,JLabel> labelTable = new Hashtable<Integer,JLabel>();
		labelTable.put(startMark, QuickTimePlayerUI.getStartMarkSlider());
    	
		if (finishMark != -1) {
			if (startMark >= finishMark) {
				finishMark = -1;	
				refUI.setFinishMarkTextField("");
				refUI.setDisableFinishMarkInit();
			} else {
				labelTable.put(finishMark, QuickTimePlayerUI.getFinishMarkSlider());				
			}
    	}
    	
		refUI.setEnableStartMarkInit();
		refUI.setEnablePlayMarkButton(labelTable);
		refUI.setStartMarkTextField(getTimeWithFormat((getRealCurrentTime(startMark))));   	
    }
    
    public void startMarkMovieAction() {
		startMark = this.getCurrentTime();
		this.startMarkMovie();
    }
    
    private void finishMarkMovie() {
    	Hashtable<Integer,JLabel> labelTable = new Hashtable<Integer,JLabel>();
		labelTable.put(finishMark, QuickTimePlayerUI.getFinishMarkSlider());
		
		if (startMark != -1) {
			if (startMark >= finishMark) {
				startMark = -1;
				refUI.setStartMarkTextField("");
				refUI.setDisableStartMarkInit();
			} else {
				labelTable.put(startMark, QuickTimePlayerUI.getStartMarkSlider());
			}
		}
		
		refUI.setEnableFinishMarkInit();
		refUI.setEnablePlayMarkButton(labelTable);
		refUI.setFinishMarkTextField(getTimeWithFormat((getRealCurrentTime(finishMark))));
    }
    
    public void playMovieAction() {
		try {
			currentMovie.setActiveSegment(new TimeInfo(0,duration));
			if (isPlayingWithMark) {
				isPlayingWithMark = false;
				refUI.setPlayMarkButtonImage();
			} 
			if (isPlaying) {
				currentMovie.stop();
				refUI.setPlayButtonImage();
				isPlaying = false;
			} else {
				if (isFinished) {
					currentMovie.goToBeginning();
					isFinished = false;
				}
				currentMovie.start();
				refUI.setPauseButtonImage();
				isPlaying = true;
			}
		} catch (StdQTException exe) {
			exe.printStackTrace();					
		}
    }  

    public void playMarkMovieAction() {
    	try {
    		int start = 0;
			int finish = duration;
			
			if (startMark != -1) {
				start = startMark;
			}
			
			if (finishMark != -1) {
				finish = finishMark;
			}
			
			currentMovie.setActiveSegment(new TimeInfo(start,finish - start));

			if (isPlaying) {
				isPlaying = false;
				refUI.setPlayButtonImage();
			}
			if (isPlayingWithMark) {
				currentMovie.stop();
				refUI.setPlayMarkButtonImage();
				isPlayingWithMark = false;
			} else {
				if (isFinished) {
					currentMovie.goToBeginning();
					isFinished = false;
				}
				currentMovie.start();
				refUI.setPauseMarkButtonImage();
				isPlayingWithMark = true;
			}
		} catch (StdQTException exe) {
			exe.printStackTrace();
		}    	
    } 
    
    public void finishMarkMovieAction() {
		finishMark = this.getCurrentTime();
		this.finishMarkMovie();
    }
    
    public void initStartMarkMovieAction() {
		startMark = -1;
		Hashtable<Integer,JLabel> labelTable = new Hashtable<Integer,JLabel>();
		if (finishMark != -1) {
			labelTable.put(finishMark, QuickTimePlayerUI.getFinishMarkSlider());
		}
		if (labelTable.size() == 0) {
			refUI.setDisablePlayMarkButton();
		}
		else {
			refUI.setEnablePlayMarkButton(labelTable);			
		}
		refUI.setStartMarkTextField("");
		refUI.setDisableStartMarkInit();
    }
    
    public void initFinishMarkMovieAction() {
		finishMark = -1;
		Hashtable<Integer,JLabel> labelTable = new Hashtable<Integer,JLabel>();
		if (startMark != -1) {
			labelTable.put(startMark, QuickTimePlayerUI.getStartMarkSlider());
		}
		
		if (isPlayingWithMark) {
			try {
				currentMovie.setActiveSegment(new TimeInfo(0,duration));
				refUI.setPlayMarkButtonImage();
				isPlayingWithMark = false;
			} catch (StdQTException exe) {
				exe.printStackTrace();
			}
		}
		
		if (labelTable.size() == 0) {
			refUI.setDisablePlayMarkButton();
		}
		else { 
			refUI.setEnablePlayMarkButton(labelTable);
		}
		refUI.setFinishMarkTextField("");
		refUI.setDisableFinishMarkInit();
    }
    
    public void enableMousePressedAction() {
    	if (currentMovie == null) {
    		return;
    	}
    	this.mousePressed = true;
  	
		try {
			currentMovie.setActiveSegment(new TimeInfo(0,duration));
			if (isPlayingWithMark) {
				isPlaying = true;
				refUI.setPlayMarkButtonImage();
				refUI.setPauseButtonImage();
				isPlayingWithMark = false;
			}
		} catch (StdQTException exe) {
			exe.printStackTrace();
		}
    }
    
    public void disableMousePressedAction() {
    	this.mousePressed = false;
    }
    
    public void disableKeyPressedAction() {
    	this.keyPressed = false;
    }
    
    public void enableKeyPressedAction() {
    	if (currentMovie == null) {
    		return;
    	}
    	
    	this.keyPressed = true;
    	try {
			currentMovie.setActiveSegment(new TimeInfo(0,duration));
			if (isPlayingWithMark) {
				isPlaying = true;
				refUI.setPlayMarkButtonImage();
				refUI.setPauseButtonImage();
				isPlayingWithMark = false;
			}
		} catch (StdQTException exe) {
			exe.printStackTrace();
		}
    }
    
    public void timeProgress(int slider) {
    	if (mousePressed || keyPressed) {					
			try {
				currentMovie.setTimeValue(slider);						
			} catch (StdQTException exe) {
				exe.printStackTrace();
			}
		}		
    }
    
    public void timerProgess() {
    	if (currentMovie == null) {
			return;
		}
		try {
			int totalSeconds = currentMovie.getTime() / currentMovie.getTimeScale();
			refUI.setTimeLabelContent(getTimeWithFormat(totalSeconds));
			if (!(mousePressed && keyPressed)) {
				refUI.setTimeSliderContent(currentMovie.getTime());
			}			
		} catch (QTException qte) {
			qte.printStackTrace();
		}
    }
    
    private class MyQTCallback extends ExtremesCallBack {
        public MyQTCallback (Movie m) throws QTException {
            super (m.getTimeBase(), StdQTConstants.triggerAtStop);
            callMeWhen();
        }

        public void execute() {        	
            if (rateWhenCalled == 0.0) {
            
            } else if (rateWhenCalled == 1.0) {  
            	refUI.setPlayButtonImage();
            	refUI.setPlayMarkButtonImage();
            	isPlaying = false;
            	isPlayingWithMark = false;
            	try {
            		currentMovie.stop();
            		isFinished = true;
				} catch (StdQTException exe) {
					exe.printStackTrace();					
				}
            }
            try {
                callMeWhen();
            } catch (QTException qte) {
                qte.printStackTrace();
            }
        }
    }
    
    private String getTimeWithFormat(int totalSeconds) {
		int seconds = totalSeconds % 60;
		int minutes = totalSeconds / 60;
		String secString = (seconds > 9) ? Integer.toString(seconds) : ("0" + Integer.toString(seconds));
		String minString = Integer.toString(minutes);
		return (minString + ":" + secString);
    }
    
	private int getCurrentTime() {
		if (currentMovie != null) {
			try {
				int totalSeconds = currentMovie.getTime();
				return totalSeconds;
			} catch (QTException qte) {
				qte.printStackTrace();
			}		
		}
		return -1;
	}
    
	private int getRealCurrentTime(int current) {
		try {
			return current / currentMovie.getTimeScale();
		} catch(QTException qte) {
			qte.printStackTrace();
		}
		return -1;
	}
    
	private void processInitPlayer() {
		refUI.initPlayerController();
		refUI.hideMoviePanel();
		refUI.hideMovieInformationPanel();
		isPlayingWithMark = false;
		isPlaying = false;
		isFinished = false;
		duration = 0;
		startMark = -1;
		finishMark = -1;
		mousePressed = false;
		keyPressed = false;		
	}
	
	public static void main(String[] argv) {
		try {
			QTSessionCheck.check();
			new QuickTimePlayerControl();
		} catch (QTException qte) {
			qte.printStackTrace();
		}
	}
}
