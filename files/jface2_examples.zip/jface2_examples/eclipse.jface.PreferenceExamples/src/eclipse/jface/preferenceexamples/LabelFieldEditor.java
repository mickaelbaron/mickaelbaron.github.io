package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.FieldEditor;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Based on www.eclipse.org/articles/Article-Field-Editors/field_editors.html FieldEditor.
 * 
 * Date : March 2008
 */
public class LabelFieldEditor extends FieldEditor {

	private Label label;

	private int vGap;

	public LabelFieldEditor(String value, Composite parent, int pVGap) {
		init("label", value);
		this.vGap = pVGap;

		if (vGap < 0) {
			this.vGap = 0;
		}

		createControl(parent);
	}

	protected void adjustForNumColumns(int numColumns) {
		((GridData) label.getLayoutData()).horizontalSpan = numColumns;
	}

	protected void doFillIntoGrid(Composite parent, int numColumns) {
		label = getLabelControl(parent);

		GridData gridData = new GridData();
		gridData.horizontalSpan = numColumns;
		gridData.horizontalAlignment = GridData.FILL;
		gridData.grabExcessHorizontalSpace = false;
		gridData.verticalAlignment = GridData.CENTER;
		gridData.grabExcessVerticalSpace = false;
		gridData.heightHint = vGap;

		label.setLayoutData(gridData);
	}

	public int getNumberOfControls() {
		return 1;
	}

	protected void doLoad() {
	}

	protected void doLoadDefault() {
	}

	protected void doStore() {
	}
}
