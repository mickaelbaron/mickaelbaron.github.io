package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.FieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class MinMaxFieldEditor extends FieldEditor {

	private static final String MIN_MAX_PREDICAT_ERROR_MESSAGE = "Valeur min doit être strictement inférieure à la valeur max";

	private static final String MIN_MAX_ERROR_MESSAGE = "Valeurs 'min' et 'max' non correctes";

	private static final String MAX_ERROR_MESSAGE = "Valeur 'max' non correcte";

	private static final String MIN_ERROR_MESSAGE = "Valeur 'min' non correcte";

	private static final String MAX = "Max";

	private static final String MIN = "Min";

	private static final String MIN_NAME = "MIN";

	private static final String MAX_NAME = "MAX";

	public static int UNLIMITED = -1;

	private int widthInChars = UNLIMITED;

	private Text minField;

	private Text maxField;

	private Composite top;

	private boolean isMinValid;

	private boolean isMaxValid;

	private String oldMinValue;

	private String oldMaxValue;

	public MinMaxFieldEditor(String properties, String labelText,
			Composite parent) {
		this(properties, labelText, UNLIMITED, parent);
	}

	public MinMaxFieldEditor(String properties, String labelText, int limit,
			Composite parent) {
		init(properties, labelText);
		widthInChars = limit;
		createControl(parent);
	}

	protected void adjustForNumColumns(int numColumns) {
		GridData layoutData = (GridData) top.getLayoutData();
		layoutData.horizontalSpan = numColumns;
	}

	public int getNumberOfControls() {
		return 2;
	}

	protected void doFillIntoGrid(Composite parent, int numColumns) {
		top = parent;

		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		gd.horizontalSpan = numColumns;
		parent.setLayoutData(gd);

		Label label = this.getLabelControl(parent);
		GridData labelData = new GridData();
		labelData.horizontalSpan = numColumns;
		label.setLayoutData(labelData);

		Composite minComposite = new Composite(parent, SWT.BORDER);
		minComposite.setLayout(new GridLayout(2, false));
		Label minLabel = new Label(minComposite, SWT.NONE);
		minLabel.setText(MIN);

		minField = new Text(minComposite, SWT.BORDER);
		minField.setLayoutData(prepareLayout(minField));
		minField.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				clearErrorMessage();
			}
		});
		minField.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				refreshValidState();
			}

			public void focusLost(FocusEvent e) {
				valueChanged();
				clearErrorMessage();
			}
		});

		Composite maxComposite = new Composite(parent, SWT.BORDER);
		maxComposite.setLayout(new GridLayout(2, false));
		Label maxLabel = new Label(maxComposite, SWT.NONE);
		maxLabel.setText(MAX);

		maxField = new Text(maxComposite, SWT.BORDER);
		maxField.setLayoutData(prepareLayout(maxField));
		maxField.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				clearErrorMessage();
			}
		});
		maxField.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				refreshValidState();
			}

			public void focusLost(FocusEvent e) {
				valueChanged();
				clearErrorMessage();
			}
		});
	}

	private GridData prepareLayout(Text tf) {
		GridData gd = new GridData();
		if (widthInChars != UNLIMITED) {
			tf.setTextLimit(widthInChars);
			GC gc = new GC(minField);
			try {
				Point extent = gc.textExtent("X");
				gd.widthHint = widthInChars * extent.x;
			} finally {
				gc.dispose();
			}
		} else {
			gd.horizontalAlignment = GridData.FILL;
			gd.grabExcessHorizontalSpace = true;
		}
		return gd;
	}

	private String getMinStringValue() {
		if (minField != null) {
			return minField.getText();
		}

		return getPreferenceStore().getString(getPreferenceName() + MIN_NAME);
	}

	private String getMaxStringValue() {
		if (maxField != null) {
			return maxField.getText();
		}

		return getPreferenceStore().getString(getPreferenceName() + MAX_NAME);
	}

	protected void valueChanged() {
		setPresentsDefaultValue(false);

		boolean oldMinState = isMinValid;
		boolean oldMaxState = isMaxValid;

		refreshValidState();

		if (isMinValid != oldMinState) {
			fireStateChanged(IS_VALID, oldMinState, isMinValid);
		}

		if (isMaxValid != oldMaxState) {
			fireStateChanged(IS_VALID, oldMaxState, isMaxValid);
		}

		String newMinValue = minField.getText();
		String newMaxValue = maxField.getText();
		if (!newMinValue.equals(oldMinValue)) {
			fireValueChanged(VALUE, oldMinValue, newMinValue);
			oldMinValue = newMinValue;
		}

		if (!newMaxValue.equals(oldMaxValue)) {
			fireValueChanged(VALUE, oldMaxValue, newMaxValue);
			oldMaxValue = newMaxValue;
		}
	}

	protected void refreshValidState() {
		if (minField == null || maxField == null) {
			isMinValid = false;
			isMaxValid = false;
			return;
		}

		String minText = this.minField.getText();
		String maxText = this.maxField.getText();
		String message = "";
		int minValue = 0;
		int maxValue = 0;

		try {
			minValue = Integer.valueOf(minText).intValue();
			isMinValid = true;
		} catch (NumberFormatException e1) {
			message = MIN_ERROR_MESSAGE;
			isMinValid = false;
		}

		try {
			maxValue = Integer.valueOf(maxText).intValue();
			isMaxValid = true;
		} catch (NumberFormatException e1) {
			isMaxValid = false;
			if (isMinValid) {
				message = MAX_ERROR_MESSAGE;
			} else {
				message = MIN_MAX_ERROR_MESSAGE;
			}
		}

		if (isMinValid && isMaxValid) {
			if (minValue > maxValue) {
				isMinValid = false;
				isMaxValid = false;
				showErrorMessage(MIN_MAX_PREDICAT_ERROR_MESSAGE);
				return;
			}
		} else {
			showErrorMessage(message);
			return;
		}
		clearErrorMessage();
	}

	public int getMinValue() throws NumberFormatException {
		return new Integer(getMinStringValue()).intValue();
	}

	public int getMaxValue() throws NumberFormatException {
		return new Integer(getMaxStringValue()).intValue();
	}

	protected void doLoad() {
		if (minField != null && maxField != null) {
			int minValue = getPreferenceStore().getInt(
					getPreferenceName() + MIN_NAME);
			int maxValue = getPreferenceStore().getInt(
					getPreferenceName() + MAX_NAME);
			minField.setText("" + minValue);
			maxField.setText("" + maxValue);
		}
	}

	protected void doLoadDefault() {
		if (minField != null && maxField != null) {
			int minValue = getPreferenceStore().getDefaultInt(
					getPreferenceName() + MIN_NAME);
			int maxValue = getPreferenceStore().getDefaultInt(
					getPreferenceName() + MAX_NAME);
			minField.setText("" + minValue);
			maxField.setText("" + maxValue);
		}
		valueChanged();
	}

	protected void doStore() {
		if (minField != null && maxField != null) {
			Integer i = new Integer(minField.getText());
			Integer j = new Integer(maxField.getText());
			getPreferenceStore().setValue(getPreferenceName() + MIN_NAME,
					i.intValue());
			getPreferenceStore().setValue(getPreferenceName() + MAX_NAME,
					j.intValue());
		}
	}
}
