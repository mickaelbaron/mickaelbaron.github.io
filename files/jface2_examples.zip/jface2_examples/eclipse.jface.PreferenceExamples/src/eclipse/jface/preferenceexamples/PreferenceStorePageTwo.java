package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceStorePageTwo extends PreferencePage {
	private Button buttonOne;

	private Button buttonTwo;

	private static final String BUTTON1_PROPERTIES = "pageTwo.check1";

	private static final String BUTTON2_PROPERTIES = "pageTwo.check2";

	public PreferenceStorePageTwo() {
		super("Page Deux");
		setDescription("Préférence des options 'Page Deux'");
	}

	protected Control createContents(Composite comp) {
		IPreferenceStore currentPreferenceStore = getPreferenceStore();

		Composite myComposite = new Composite(comp, SWT.NONE);
		myComposite.setLayout(new GridLayout(2, true));

		Composite myGroupControl = new Composite(myComposite, SWT.NONE);
		myGroupControl.setLayout(new GridLayout(2, false));
		Label label = new Label(myGroupControl, SWT.LEFT);
		label.setText("Champs 1:");
		buttonOne = new Button(myGroupControl, SWT.CHECK);
		buttonOne.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		buttonOne.setSelection(currentPreferenceStore
				.getBoolean(BUTTON1_PROPERTIES));

		myGroupControl = new Composite(myComposite, SWT.NONE);
		myGroupControl.setLayout(new GridLayout(2, false));
		label = new Label(myGroupControl, SWT.LEFT);
		label.setText("Champs 2:");
		buttonTwo = new Button(myGroupControl, SWT.CHECK);
		buttonTwo.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		buttonTwo.setSelection(currentPreferenceStore
				.getBoolean(BUTTON2_PROPERTIES));

		return myComposite;
	}

	public boolean performOk() {
		IPreferenceStore currentPreferenceStore = getPreferenceStore();

		// Modification du contenu de la sauvegarde à partir des champs de texte
		if (this.buttonOne != null) {
			currentPreferenceStore.setValue(BUTTON1_PROPERTIES, buttonOne
					.getSelection());
		}
		if (this.buttonTwo != null) {
			currentPreferenceStore.setValue(BUTTON2_PROPERTIES, buttonTwo
					.getSelection());
		}

		return true;
	}
}
