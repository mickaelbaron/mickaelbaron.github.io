package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceStorePageOne extends PreferencePage {

	private Text textFieldOne;

	private Text textFieldTwo;

	private static final String FIELD1_PROPERTIES = "pageOne.field1";

	private static final String FIELD2_PROPERTIES = "pageOne.field2";

	public PreferenceStorePageOne() {
		super("Page Une");
		setDescription("Préférence des options 'Page Une'");
	}

	protected Control createContents(Composite comp) {
		IPreferenceStore currentPreferenceStore = getPreferenceStore();

		Composite myComposite = new Composite(comp, SWT.NONE);
		myComposite.setLayout(new GridLayout(2, false));

		Label label = new Label(myComposite, SWT.LEFT);
		label.setText("Champs 1:");
		textFieldOne = new Text(myComposite, SWT.BORDER);
		textFieldOne.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		textFieldOne.setText(currentPreferenceStore
				.getString(FIELD1_PROPERTIES));

		label = new Label(myComposite, SWT.LEFT);
		label.setText("Champs 2:");
		textFieldTwo = new Text(myComposite, SWT.BORDER);
		textFieldTwo.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		textFieldTwo.setText(currentPreferenceStore
				.getString(FIELD2_PROPERTIES));

		return myComposite;
	}

	protected void performApply() {
		this.performOk();
	}

	public boolean performOk() {
		IPreferenceStore currentPreferenceStore = getPreferenceStore();

		// Modification du contenu de la sauvegarde à partir des champs de texte
		if (this.textFieldOne != null) {
			currentPreferenceStore.setValue(FIELD1_PROPERTIES, textFieldOne
					.getText());
		}
		if (this.textFieldTwo != null) {
			currentPreferenceStore.setValue(FIELD2_PROPERTIES, textFieldTwo
					.getText());
		}

		return true;
	}
}
