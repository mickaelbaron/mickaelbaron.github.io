package eclipse.jface.preferenceexamples;

import org.eclipse.swt.widgets.Composite;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Based on www.eclipse.org/articles/Article-Field-Editors/field_editors.html FieldEditor.
 * 
 * Date : March 2008
 */
public class SpacerFieldEditor extends LabelFieldEditor {
	public SpacerFieldEditor(Composite parent, int pVGap) {
		super("", parent, pVGap);
	}
}
