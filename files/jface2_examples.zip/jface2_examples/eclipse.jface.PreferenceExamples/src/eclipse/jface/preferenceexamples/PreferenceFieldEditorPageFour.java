package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.FieldEditorPreferencePage;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceFieldEditorPageFour extends FieldEditorPreferencePage {

	public PreferenceFieldEditorPageFour() {
		super("Page Quatre", GRID);
	}

	protected void createFieldEditors() {
		MinMaxFieldEditor bfe = new MinMaxFieldEditor("tolerance", "Tolérence",
				3, getFieldEditorParent());
		addField(bfe);
	}
}
