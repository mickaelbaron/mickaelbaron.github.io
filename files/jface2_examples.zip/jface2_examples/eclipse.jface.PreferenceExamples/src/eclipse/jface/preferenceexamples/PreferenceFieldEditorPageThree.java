package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.FontFieldEditor;
import org.eclipse.jface.preference.PathEditor;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.jface.preference.ScaleFieldEditor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceFieldEditorPageThree extends FieldEditorPreferencePage {

	private static final String FONT_PROPERTIES = "pageThree.font";

	private static final String RADIO_PROPERTIES = "pageThree.radio";

	private static final String PATH_PROPERTIES = "pageThree.path";

	private static final String SCALE_PROPERTIES = "pageThree.scale";

	public PreferenceFieldEditorPageThree() {
		super("Page Trois", GRID);
	}

	protected void createFieldEditors() {
		FontFieldEditor ffe = new FontFieldEditor(FONT_PROPERTIES, "Police",
				getFieldEditorParent());
		addField(ffe);

		final int V_GAP = 20;
		SpacerFieldEditor spacer = new SpacerFieldEditor(
				getFieldEditorParent(), V_GAP);
		addField(spacer);

		final String[][] strings = new String[][] {
				{ "Première Valeur", "tag1" }, { "Deuxième Valeur", "tag2" },
				{ "Troisième Valeur", "tag3" }, { "Quatrième Valeur", "tag4" } };
		RadioGroupFieldEditor rfe = new RadioGroupFieldEditor(RADIO_PROPERTIES,
				"Radio Group", 2, strings, getFieldEditorParent(), true);
		addField(rfe);

		spacer = new SpacerFieldEditor(getFieldEditorParent(), V_GAP);
		addField(spacer);

		PathEditor pe = new PathEditor(PATH_PROPERTIES, "Path:",
				"Choisir des chemins", getFieldEditorParent());
		addField(pe);

		spacer = new SpacerFieldEditor(getFieldEditorParent(), V_GAP);
		addField(spacer);

		ScaleFieldEditor sfe = new ScaleFieldEditor(SCALE_PROPERTIES,
				"Echelle", getFieldEditorParent(), 0, 100, 1, 10);
		addField(sfe);
	}
}
