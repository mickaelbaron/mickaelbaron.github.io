package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.ColorFieldEditor;
import org.eclipse.jface.preference.DirectoryFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.FileFieldEditor;
import org.eclipse.jface.preference.IntegerFieldEditor;
import org.eclipse.jface.preference.StringFieldEditor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceFieldEditorPageOne extends FieldEditorPreferencePage {

	private static final String CHECK_PROPERTIES = "pageOne.check";

	private static final String STRING_PROPERTIES = "pageOne.string";

	private static final String INTEGER_PROPERTIES = "pageOne.integer";

	private static final String COLOR_PROPERTIES = "pageOne.color";

	private static final String DIRECTORY_PROPERTIES = "pageOne.directory";

	private static final String FILE_PROPERTIES = "pageOne.file";

	public PreferenceFieldEditorPageOne() {
		super("Page Une", GRID);
	}

	protected void createFieldEditors() {
		BooleanFieldEditor bfe = new BooleanFieldEditor(CHECK_PROPERTIES,
				"Booléen", getFieldEditorParent());
		addField(bfe);

		StringFieldEditor sfe = new StringFieldEditor(STRING_PROPERTIES,
				"Chaîne de caractères", getFieldEditorParent());
		addField(sfe);

		IntegerFieldEditor ife = new IntegerFieldEditor(INTEGER_PROPERTIES,
				"Entier", getFieldEditorParent());
		addField(ife);

		ColorFieldEditor cfe = new ColorFieldEditor(COLOR_PROPERTIES,
				"Couleur", getFieldEditorParent());
		addField(cfe);

		DirectoryFieldEditor dfe = new DirectoryFieldEditor(
				DIRECTORY_PROPERTIES, "Répertoire", getFieldEditorParent());
		addField(dfe);

		FileFieldEditor ffe = new FileFieldEditor(FILE_PROPERTIES, "Fichier",
				getFieldEditorParent());
		addField(ffe);
	}
}
