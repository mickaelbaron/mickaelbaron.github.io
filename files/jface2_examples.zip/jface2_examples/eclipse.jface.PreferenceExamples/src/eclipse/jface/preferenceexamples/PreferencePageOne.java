package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferencePageOne extends PreferencePage {
	private Text textFieldOne;

	private Text textFieldTwo;

	public PreferencePageOne() {
		super("Page Une");
		setDescription("Préférence des options 'Page Une'");
	}

	private void validFieldOneValue() {
		String value = textFieldOne.getText();
		if (value == null || value.equals("")) {
			PreferencePageOne.this.setValid(false);
		}

		if (this.isValid()) {
			this.setMessage(null);
		} else {
			this.setMessage("Champs 1 : ne peut être vide", ERROR);
		}
	}

	protected Control createContents(Composite comp) {
		Composite myComposite = new Composite(comp, SWT.NONE);
		myComposite.setLayout(new GridLayout(2, false));

		Label label = new Label(myComposite, SWT.LEFT);
		label.setText("Champs 1:");
		textFieldOne = new Text(myComposite, SWT.BORDER);
		textFieldOne.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				validFieldOneValue();
			}
		});
		textFieldOne.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		label = new Label(myComposite, SWT.LEFT);
		label.setText("Champs 2:");
		textFieldTwo = new Text(myComposite, SWT.BORDER);
		textFieldTwo.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		return myComposite;
	}
}
