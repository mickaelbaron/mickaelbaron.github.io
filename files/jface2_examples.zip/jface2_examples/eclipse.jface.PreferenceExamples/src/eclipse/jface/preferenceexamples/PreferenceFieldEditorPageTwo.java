package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.FontFieldEditor;
import org.eclipse.jface.preference.PathEditor;
import org.eclipse.jface.preference.RadioGroupFieldEditor;
import org.eclipse.jface.preference.ScaleFieldEditor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceFieldEditorPageTwo extends FieldEditorPreferencePage {

	private static final String FONT_PROPERTIES = "pageTwo.font";

	private static final String RADIO_PROPERTIES = "pageTwo.radio";

	private static final String PATH_PROPERTIES = "pageTwo.path";

	private static final String SCALE_PROPERTIES = "pageTwo.scale";

	public PreferenceFieldEditorPageTwo() {
		super("Page Deux", GRID);
	}

	protected void createFieldEditors() {
		FontFieldEditor ffe = new FontFieldEditor(FONT_PROPERTIES, "Police",
				getFieldEditorParent());
		addField(ffe);

		final String[][] strings = new String[][] {
				{ "Première Valeur", "tag1" }, { "Deuxième Valeur", "tag2" },
				{ "Troisième Valeur", "tag3" }, { "Quatrième Valeur", "tag4" } };
		RadioGroupFieldEditor rfe = new RadioGroupFieldEditor(RADIO_PROPERTIES,
				"RadioGroup", 2, strings, getFieldEditorParent(), true);
		addField(rfe);

		PathEditor pe = new PathEditor(PATH_PROPERTIES, "Path:",
				"Choisir des chemins", getFieldEditorParent());
		addField(pe);

		ScaleFieldEditor sfe = new ScaleFieldEditor(SCALE_PROPERTIES,
				"Echelle", getFieldEditorParent(), 0, 100, 1, 10);
		addField(sfe);
	}
}
