package eclipse.jface.preferenceexamples;

import java.io.IOException;

import org.eclipse.jface.preference.PreferenceDialog;
import org.eclipse.jface.preference.PreferenceManager;
import org.eclipse.jface.preference.PreferenceNode;
import org.eclipse.jface.preference.PreferenceStore;
import org.eclipse.swt.widgets.Display;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceStoreExample {
	public PreferenceStoreExample() {
		Display myDisplay = new Display();

		PreferenceNode one = new PreferenceNode("one",
				new PreferenceStorePageOne());
		PreferenceNode two = new PreferenceNode("two",
				new PreferenceStorePageTwo());

		PreferenceManager mgr = new PreferenceManager();
		mgr.addToRoot(one);
		mgr.addTo("one", two);

		PreferenceDialog myPreferenceDialog = new PreferenceDialog(null, mgr);

		PreferenceStore ps = new PreferenceStore("prefs.properties");
		try {
			ps.load();
		} catch (IOException e) {
			e.printStackTrace();
		}

		myPreferenceDialog.setPreferenceStore(ps);
		myPreferenceDialog.open();

		try {
			ps.save();
		} catch (IOException e) {
			e.printStackTrace();
		}

		myDisplay.dispose();
	}

	public static void main(String[] args) {
		new PreferenceStoreExample();
	}
}