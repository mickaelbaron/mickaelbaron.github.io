package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferencePageTwo extends PreferencePage {
	private Button buttonOne;

	private Button buttonTwo;

	public PreferencePageTwo() {
		super("Page Deux");
		setDescription("Préférence des options 'Page Deux'");
	}

	protected Control createContents(Composite comp) {
		Composite myComposite = new Composite(comp, SWT.NONE);
		myComposite.setLayout(new GridLayout(2, true));

		Composite myGroupControl = new Composite(myComposite, SWT.NONE);
		myGroupControl.setLayout(new GridLayout(2, false));
		Label label = new Label(myGroupControl, SWT.LEFT);
		label.setText("Champs 1:");
		buttonOne = new Button(myGroupControl, SWT.CHECK);
		buttonOne.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		myGroupControl = new Composite(myComposite, SWT.NONE);
		myGroupControl.setLayout(new GridLayout(2, false));
		label = new Label(myGroupControl, SWT.LEFT);
		label.setText("Champs 2:");
		buttonTwo = new Button(myGroupControl, SWT.CHECK);
		buttonTwo.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		return myComposite;
	}
}
