package eclipse.jface.preferenceexamples;

import org.eclipse.jface.preference.PreferenceDialog;
import org.eclipse.jface.preference.PreferenceManager;
import org.eclipse.jface.preference.PreferenceNode;
import org.eclipse.swt.widgets.Display;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class PreferenceExample {
	public PreferenceExample() {
		Display myDisplay = new Display();

		PreferenceNode one = new PreferenceNode("one", new PreferencePageOne());
		PreferenceNode two = new PreferenceNode("two", new PreferencePageTwo());
		PreferenceNode three = new PreferenceNode("three", "Page Three", null,
				PreferencePageTwo.class.getName());

		one.add(two);
		one.add(three);

		System.out.println(one.getSubNodes().length); // Doit retourner 2 ...

		PreferenceManager mgr = new PreferenceManager();
		mgr.addToRoot(one);

		// Autre écriture pour ajouter two et three à one
		// mgr.addTo("one", two);
		// mgr.addTo("one", three);

		PreferenceDialog myPreferenceDialog = new PreferenceDialog(null, mgr);
		myPreferenceDialog.open();

		myDisplay.dispose();
	}

	public static void main(String[] args) {
		new PreferenceExample();
	}
}