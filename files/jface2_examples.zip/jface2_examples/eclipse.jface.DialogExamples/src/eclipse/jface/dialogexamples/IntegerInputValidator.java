package eclipse.jface.dialogexamples;

import org.eclipse.jface.dialogs.IInputValidator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class IntegerInputValidator implements IInputValidator {
	public String isValid(String newText) {
		try {
			int value = new Integer(newText).intValue();

			if (value < 0)
				return "Doit être positif";
			if (value > 1000)
				return "Ne doit pas être supérieur à 1000";
		} catch (NumberFormatException e) {
			return "Ne correspond pas à un entier";
		}
		return null;
	}
}
