package eclipse.jface.dialogexamples;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * ErrorDialog : based on IconAndMessageDialog class.
 * 
 * Date : March 2008
 */
public class ErrorDialogExample {
	public static void errorDialog(Shell pShell, int severity) {
		String statusMessage = "[Placer ici le status de l'erreur]\n\n";

		switch (severity) {
		case IStatus.ERROR:
			statusMessage += "Status Error Message";
			break;
		case IStatus.INFO:
			statusMessage += "Status Info Message";
			break;
		case IStatus.WARNING:
			statusMessage += "Status Warning Message";
			break;
		default:
			statusMessage += "Status Error Message";
			break;
		}

		IStatus errorStatus = new Status(severity, "My Plug-In ID", 0,
				statusMessage, null);
		ErrorDialog
				.openError(
						pShell,
						"JFace Error Dialog",
						"[Placer ici le message d'erreur] \n\nUn problème est survenu au niveau ...",
						errorStatus);
	}
}
