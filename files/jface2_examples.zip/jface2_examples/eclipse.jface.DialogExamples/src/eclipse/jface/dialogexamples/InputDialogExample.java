package eclipse.jface.dialogexamples;

import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * InputDialog : based on Dialog
 * 
 * Date : March 2008
 */
public class InputDialogExample {

	public static void stringInputDialog(Shell pShell) {
		InputDialog myInputDialog = new InputDialog(pShell,
				"JFace Input Dialog",
				"[Placer Message pour la saisie] Saisir votre texte",
				"Ma Valeur", null);

		if (myInputDialog.open() == Window.OK) {
			System.out
					.println("Vous avez sélectionné la validation en saisissant : "
							+ myInputDialog.getValue());
		} else {
			System.out.println("Vous avez sélectionné l'annulation.");
		}
	}

	public static void validationIntegerInputDialog(Shell pShell) {
		InputDialog myInputDialog = new InputDialog(pShell,
				"JFace Input Dialog",
				"[Placer Message pour la saisie] Saisir votre texte",
				"Ma Valeur", new IntegerInputValidator());

		if (myInputDialog.open() == Window.OK) {
			System.out
					.println("Vous avez sélectionné la validation en saisissant : "
							+ myInputDialog.getValue());
		} else {
			System.out.println("Vous avez sélectionné l'annulation.");
		}
	}

	public static void validationStringInputDialog(Shell pShell) {
		InputDialog myInputDialog = new InputDialog(pShell,
				"JFace Input Dialog",
				"[Placer Message pour la saisie] Saisir votre texte",
				"Ma Valeur", new StringInputValidator());

		if (myInputDialog.open() == Window.OK) {
			System.out
					.println("Vous avez sélectionné la validation en saisissant : "
							+ myInputDialog.getValue());
		} else {
			System.out.println("Vous avez sélectionné l'annulation.");
		}
	}
}
