package eclipse.jface.dialogexamples;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class DialogLibraryExample {
	public DialogLibraryExample() {
		Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("Bibliothèque de boîtes de dialogue JFace");
		shell.setLayout(new GridLayout(1, false));

		Label messageLabel = new Label(shell, SWT.NONE);
		messageLabel.setText("ErrorDialog");

		Composite groupComposite = new Composite(shell, SWT.NONE);
		groupComposite.setLayout(new GridLayout(3, false));
		Button myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				ErrorDialogExample.errorDialog(shell, IStatus.ERROR);
			}
		});
		myButton.setText("Error Dialog : ERROR");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				ErrorDialogExample.errorDialog(shell, IStatus.INFO);
			}
		});
		myButton.setText("Error Dialog : INFO");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				ErrorDialogExample.errorDialog(shell, IStatus.WARNING);
			}
		});
		myButton.setText("Error Dialog : WARNING");

		messageLabel = new Label(shell, SWT.NONE);
		messageLabel.setText("InputDialog");

		groupComposite = new Composite(shell, SWT.NONE);
		groupComposite.setLayout(new GridLayout(3, false));
		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				InputDialogExample.stringInputDialog(shell);
			}
		});
		myButton.setText("Input Dialog : String");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				InputDialogExample.validationStringInputDialog(shell);
			}
		});
		myButton.setText("Input Dialog : Validation String");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				InputDialogExample.validationIntegerInputDialog(shell);
			}
		});
		myButton.setText("Input Dialog : Validation Integer");

		messageLabel = new Label(shell, SWT.NONE);
		messageLabel.setText("MessageDialog");

		groupComposite = new Composite(shell, SWT.NONE);
		groupComposite.setLayout(new GridLayout(5, false));
		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				MessageDialogExample.confirmDialog(shell);
			}
		});
		myButton.setText("Message Dialog : Confirmation");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				MessageDialogExample.errorDialog(shell);
			}
		});
		myButton.setText("Message Dialog : Error");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				MessageDialogExample.informationDialog(shell);
			}
		});
		myButton.setText("Message Dialog : Information");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				MessageDialogExample.questionDialog(shell);
			}
		});
		myButton.setText("Message Dialog : Question");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				MessageDialogExample.warningDialog(shell);
			}
		});
		myButton.setText("Message Dialog : Warning");

		messageLabel = new Label(shell, SWT.NONE);
		messageLabel.setText("ProgressMonitorDialog");

		groupComposite = new Composite(shell, SWT.NONE);
		groupComposite.setLayout(new GridLayout(5, false));
		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				ProgressMonitorDialogExample
						.progressMonitorDialog(shell, false);
			}
		});
		myButton.setText("ProgressMonitor Dialog : Not Indeterminate");

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				ProgressMonitorDialogExample.progressMonitorDialog(shell, true);
			}
		});
		myButton.setText("ProgressMonitor Dialog : Indeterminate");

		messageLabel = new Label(shell, SWT.NONE);
		messageLabel.setText("Custom JFace Dialog");

		groupComposite = new Composite(shell, SWT.NONE);
		groupComposite.setLayout(new GridLayout(2, false));

		myButton = new Button(groupComposite, SWT.FLAT);
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				CustomTitleAreaDialog.customTitleAreaDialog(shell);
			}
		});
		myButton.setText("TitleAreaDialog : Custom");

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] args) {
		new DialogLibraryExample();
	}
}
