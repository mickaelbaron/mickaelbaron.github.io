package eclipse.jface.dialogexamples;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * MessageDialog : based on IconAndMessageDialog
 * 
 * Date : March 2008
 */
public class MessageDialogExample {
	public static void confirmDialog(Shell pShell) {
		boolean confirmationStatus = MessageDialog.openConfirm(pShell,
				"JFace Message Dialog : Confirmation",
				"[Placer ici votre message] Demande confirmation.");
		System.out.println("Valeur retournée : " + confirmationStatus);
	}

	public static void errorDialog(Shell pShell) {
		MessageDialog
				.openError(pShell, "JFace Message Dialog : Error",
						"[Placer ici votre message] Attention une erreur est survenue.");
	}

	public static void informationDialog(Shell pShell) {
		MessageDialog.openInformation(pShell,
				"JFace Message Dialog : Information",
				"[Placer ici votre message] Message à caractère informatif.");
	}

	public static void questionDialog(Shell pShell) {
		boolean questionStatus = MessageDialog
				.openQuestion(pShell, "JFace Message Dialog : Question",
						"[Placer ici votre message] Etes-vous sur de vouloir faire cela.");
		System.out.println("Valeur retournée : " + questionStatus);
	}

	public static void warningDialog(Shell pShell) {
		MessageDialog
				.openWarning(
						pShell,
						"JFace Message Dialog : Warning",
						"[Placer ici votre message] Attention, il s'est passé quelque chose d'étrange ...");
	}
}
