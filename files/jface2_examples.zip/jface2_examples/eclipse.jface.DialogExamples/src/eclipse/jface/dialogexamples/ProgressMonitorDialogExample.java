package eclipse.jface.dialogexamples;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class ProgressMonitorDialogExample {
	public static void progressMonitorDialog(Shell pShell, boolean indeterminate) {
		try {
			new ProgressMonitorDialog(pShell).run(true, true,
					new WorkLessOperation(indeterminate));
		} catch (InvocationTargetException e) {
			MessageDialog.openError(pShell, "Erreur", e.getMessage());
		} catch (InterruptedException e) {
			MessageDialog.openInformation(pShell, "Annulée", e.getMessage());
		}
	}
}
