package eclipse.jface.dialogexamples;

import org.eclipse.jface.dialogs.IInputValidator;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class StringInputValidator implements IInputValidator {
	public String isValid(String newText) {
		int length = newText.length();

		if (length < 4)
			return "Chaîne trop courte (doit être supérieure à 4)";
		if (length > 10)
			return "Chaîne trop longue (doit être inférieure à 10)";

		return null;
	}
}
