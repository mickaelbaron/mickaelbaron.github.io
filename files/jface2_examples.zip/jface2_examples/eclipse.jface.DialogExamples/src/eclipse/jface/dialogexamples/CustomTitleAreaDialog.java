package eclipse.jface.dialogexamples;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class CustomTitleAreaDialog extends TitleAreaDialog {

	private String title;

	private String message;

	private String dialogMessage;

	protected Control createContents(Composite parent) {
		Control contents = super.createContents(parent);
		this.setTitle(title);
		this.setMessage(message);
		this.getShell().setText(title);
		return contents;
	}

	protected Control createDialogArea(Composite parent) {
		Composite composite = (Composite) super.createDialogArea(parent);

		Composite inComposite = new Composite(composite, SWT.NONE);
		inComposite.setLayout(new GridLayout(1, false));
		GridData gd = new GridData();
		gd.horizontalIndent = 5;
		gd.verticalIndent = 5;
		inComposite.setLayoutData(gd);
		Label label = new Label(inComposite, SWT.NONE);
		label.setText(dialogMessage);
		Button button = new Button(inComposite, SWT.FLAT);
		button.setText("Ceci est un Bouton");
		return composite;
	}

	public CustomTitleAreaDialog(Shell parentShell, String pTitle,
			String pMessage, String pDialogMessage) {
		super(parentShell);
		this.title = pTitle;
		this.message = pMessage;
		this.dialogMessage = pDialogMessage;
		this.setShellStyle(this.getShellStyle() | SWT.RESIZE);
	}

	protected void createButtonsForButtonBar(Composite parent) {
		this.createButton(parent, IDialogConstants.OK_ID,
				IDialogConstants.OK_LABEL, true);
	}

	public static void customTitleAreaDialog(Shell shell) {
		new CustomTitleAreaDialog(shell, "CustomTitleAreaDialog",
				"Ceci est un message dans la zone de titre",
				"Ceci est un message dans la zone de dialogue").open();
	}
}
