package eclipse.jface.wizardexamples;

import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class HolidayWizard extends Wizard {

	/**
	 * Main page.
	 */
	HolidayMainPage holidayPage;
	
	/**
	 * Page related to the plane choice.
	 */
	PlanePage planePage;
	
	/**
	 * Page related to the car choice.
	 */
	CarPage carPage;

	/**
	 * The model 
	 */
	HolidayModel model;

	protected boolean planeCompleted = false;

	protected boolean carCompleted = false;

	/**
	 * Constructor for HolidayMainWizard.
	 */
	public HolidayWizard() {
		super();
		model = new HolidayModel();
	}

	public void addPages() {
		holidayPage = new HolidayMainPage();
		addPage(holidayPage);
		planePage = new PlanePage("");
		addPage(planePage);
		carPage = new CarPage("");
		addPage(carPage);
	}

	public boolean canFinish() {
		if (this.getContainer().getCurrentPage() == holidayPage)
			return false;

		if (model.usePlane)
			return planeCompleted;
		return carCompleted;
	}

	public boolean performFinish() {
		String summary = model.toString();
		System.out.println(summary);
		return true;
	}
	
	public static void main(String[] args) {
		Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("Wizard Example");
		shell.setLayout(new FillLayout());
		
		Button myButton = new Button(shell, SWT.FLAT);
		myButton.setText("Ouvrir Holiday Wizard");
		
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				HolidayWizard wizard = new HolidayWizard();
				wizard.setWindowTitle("Holiday Wizard");
				WizardDialog refWizardDialog = new WizardDialog(shell, wizard);
				refWizardDialog.open();
			}			
		});		
		
		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
