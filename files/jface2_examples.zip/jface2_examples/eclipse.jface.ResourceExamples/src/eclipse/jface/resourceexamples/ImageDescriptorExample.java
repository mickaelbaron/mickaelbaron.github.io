package eclipse.jface.resourceexamples;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class ImageDescriptorExample {
	public ImageDescriptorExample() {
		Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("ImageDescriptor : File and URL");
		shell.setLayout(new GridLayout(1, false));

		// The first parameter gives the peer to localize the image file.
		ImageDescriptor imageDescr = ImageDescriptor.createFromFile(
				eclipse.jface.resourceexamples.ImageDescriptorExample.class,
				"image/superstar.jpg");
		Label myLabelImage = new Label(shell, SWT.NONE);
		myLabelImage.setImage(imageDescr.createImage());

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public static void main(String[] args) {
		new ImageDescriptorExample();
	}
}
