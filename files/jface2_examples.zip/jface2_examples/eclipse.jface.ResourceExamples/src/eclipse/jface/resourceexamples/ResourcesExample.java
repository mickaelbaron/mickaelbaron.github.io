package eclipse.jface.resourceexamples;

import org.eclipse.jface.resource.ColorRegistry;
import org.eclipse.jface.resource.FontRegistry;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : March 2008
 */
public class ResourcesExample {
	public static final String SUPERSTAR_KEULKEUL_IMAGE = "superstar";

	public static final String ARIAL_KEULKEUL_FONT = "Arial";

	public static final String RED_KEULKEUL_COLOR = "red";

	public static final String BLACK_KEULKEUL_COLOR = "black";

	public ResourcesExample() {
		Display display = new Display();
		initResources();

		final Shell shell = new Shell(display);
		shell.setText("JFaceResources : Registry");
		shell.setLayout(new GridLayout());

		// The first parameter gives the peer to localize the image file.
		Label myLabelImage = new Label(shell, SWT.NONE);
		myLabelImage.setImage(JFaceResources.getImageRegistry().get(
				SUPERSTAR_KEULKEUL_IMAGE));

		Label myLabelColor = new Label(shell, SWT.NONE);
		myLabelColor.setBackground(JFaceResources.getColorRegistry().get(
				BLACK_KEULKEUL_COLOR));
		myLabelColor.setForeground(JFaceResources.getColorRegistry().get(
				RED_KEULKEUL_COLOR));
		myLabelColor.setFont(JFaceResources.getFontRegistry().get(
				ARIAL_KEULKEUL_FONT));
		myLabelColor.setText("He is a super star baby");

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	public void initResources() {
		// Color resources definition
		ColorRegistry colorRegistry = JFaceResources.getColorRegistry();
		colorRegistry.put(BLACK_KEULKEUL_COLOR, new RGB(0, 0, 0));
		colorRegistry.put(RED_KEULKEUL_COLOR, new RGB(255, 0, 0));

		// Font resources definition
		FontRegistry fontRegistry = JFaceResources.getFontRegistry();
		FontData fontData = new FontData(ARIAL_KEULKEUL_FONT, 40, SWT.BOLD);
		fontRegistry.put(ARIAL_KEULKEUL_FONT, new FontData[] { fontData });

		// Image resources definition
		ImageRegistry imageRegistry = JFaceResources.getImageRegistry();
		ImageDescriptor myImageDescriptor = ImageDescriptor.createFromFile(
				eclipse.jface.resourceexamples.ResourcesExample.class,
				"image/superstar.jpg");
		imageRegistry.put(SUPERSTAR_KEULKEUL_IMAGE, myImageDescriptor);
	}

	public static void main(String[] args) {
		new ResourcesExample();
	}
}
