package eclipse.workbench.iadaptableexample3;

import org.eclipse.core.runtime.IAdapterFactory;
import org.eclipse.ui.views.properties.IPropertySource;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class ContactAdapterFactory implements IAdapterFactory {

	@SuppressWarnings("unchecked")
	private static final Class[] TYPES = { IPropertySource.class };

	@SuppressWarnings("unchecked")
	public Object getAdapter(Object adaptableObject, Class adapterType) {
		if (adapterType == IPropertySource.class) {
			if (adaptableObject instanceof Contact) {
				return new ContactPropertySourceAdapter((Contact) adaptableObject);
			}
		}
		
		return null;
	}

	@SuppressWarnings("unchecked")
	public Class[] getAdapterList() {
		return TYPES;
	}
}
