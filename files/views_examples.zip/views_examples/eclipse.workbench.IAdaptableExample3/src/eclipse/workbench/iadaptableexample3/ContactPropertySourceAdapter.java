package eclipse.workbench.iadaptableexample3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class ContactPropertySourceAdapter implements IPropertySource {

	private Contact contact;

	public ContactPropertySourceAdapter(Contact contact) {
		this.contact = contact;
	}

	public Object getEditableValue() {
		return this;
	}

	public IPropertyDescriptor[] getPropertyDescriptors() {
		List<PropertyDescriptor> descriptors = new ArrayList<PropertyDescriptor>();

		Map<String, Object> properties = this.contact.getProperties();
		for (String key : properties.keySet()) {
			PropertyDescriptor descriptor = new PropertyDescriptor(key, key);
			descriptor.setAlwaysIncompatible(true);
			descriptors.add(descriptor);
		}

		return descriptors.toArray(new IPropertyDescriptor[0]);
	}

	public Object getPropertyValue(Object id) {
		Map<String, Object> properties = this.contact.getProperties();
		return properties.get(id);
	}

	public boolean isPropertySet(Object id) {
		return false;
	}

	public void resetPropertyValue(Object id) {
	}

	public void setPropertyValue(Object id, Object value) {
	}
}
