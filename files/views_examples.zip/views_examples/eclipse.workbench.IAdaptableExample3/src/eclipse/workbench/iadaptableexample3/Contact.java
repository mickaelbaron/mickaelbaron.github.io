package eclipse.workbench.iadaptableexample3;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class Contact { // implements IAdaptable {
	private String address;

	private String name;

	private Map<String, Object> properties;

	public Contact(String name, String address) {
		this.name = name;
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	public String getName() {
		return this.name;
	}

	public synchronized Map<String, Object> getProperties() {
		if (this.properties == null) {
			return Collections.emptyMap();
		}

		return new HashMap<String, Object>(this.properties);
	}

	public synchronized void setProperty(String key, Serializable value) {
		if (this.properties == null) {
			this.properties = new HashMap<String, Object>();
		}

		this.properties.put(key, value);
	}

//	public Object getAdapter(Class adapter) {
//		return Platform.getAdapterManager().getAdapter(this, adapter);
//	}
}
