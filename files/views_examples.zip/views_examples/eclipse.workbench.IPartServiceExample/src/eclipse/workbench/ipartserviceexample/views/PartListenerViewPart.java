package eclipse.workbench.ipartserviceexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IPartListener2;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class PartListenerViewPart extends ViewPart {

	@Override
	public void dispose() {
		super.dispose();
		System.out.println("PartListenerViewPart.dispose() : DISPOSED");
	}

	public PartListenerViewPart() {
		System.out.println("PartListenerViewPart.PartListenerViewPart() : CREATED");
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, false));
		Label myLabel = new Label(parent, SWT.NONE);
		myLabel.setText("Listened View");

		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

		activePage.addPartListener(new IPartListener2() {
					@Override
					public void partActivated(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partActivated()");
						}
					}

					@Override
					public void partBroughtToTop(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partBroughtToTop()");
						}						
					}

					@Override
					public void partClosed(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partClosed()");
						}
					}

					@Override
					public void partDeactivated(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partDeactivated()");
						}
					}

					@Override
					public void partHidden(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partHidden()");
						}
					}

					@Override
					public void partInputChanged(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partInputChanged()");
						}
					}

					@Override
					public void partOpened(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partOpened()");
						}
					}

					@Override
					public void partVisible(IWorkbenchPartReference partRef) {
						IWorkbenchPart part = partRef.getPart(false);
						if (PartListenerViewPart.this == part) {
							System.out.println(".partVisible()");
						}
					}			
				});

	}

	@Override
	public void setFocus() {
	}
}
