package eclipse.workbench.iadaptableexample1.views;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import eclipse.workbench.iadaptableexample1.Activator;
import eclipse.workbench.iadaptableexample1.Contact;
import eclipse.workbench.iadaptableexample1.ContactManager;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class ContactView extends ViewPart {
	
	public ContactView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new FillLayout());

		final ListViewer contactsList = new ListViewer(container, SWT.BORDER);
		contactsList.setLabelProvider(new ListLabelProvider());
		contactsList.setContentProvider(new ContentProvider());
		contactsList.setInput(Activator.getDefault().getContactManager());
		getViewSite().setSelectionProvider(contactsList);		
	}

	@Override
	public void setFocus() {
	}

	class ContentProvider implements IStructuredContentProvider {

		public void dispose() {
		}

		public Object[] getElements(Object inputElement) {
			ContactManager contactManager = (ContactManager) inputElement;
			return contactManager.contacts();
		}

		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		}
	}

	class ListLabelProvider extends LabelProvider {

		@Override
		public Image getImage(Object element) {
			return null;
		}

		@Override
		public String getText(Object element) {
			Contact contact = (Contact) element;
			return contact.getName();
		}
	}
}
