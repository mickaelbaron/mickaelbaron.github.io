package eclipse.workbench.iadaptableexample1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class Contact implements IPropertySource {
	private String address;

	private String name;

	private Map<String, Object> properties;

	public Contact(String name, String address) {
		this.name = name;
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	public String getName() {
		return this.name;
	}

	public synchronized Map<String, Object> getProperties() {
		if (this.properties == null) {
			return Collections.emptyMap();
		}

		return new HashMap<String, Object>(this.properties);
	}

	public synchronized void setProperty(String key, Serializable value) {
		if (this.properties == null) {
			this.properties = new HashMap<String, Object>();
		}

		this.properties.put(key, value);
	}

	public Object getEditableValue() {
		return null;
	}

	public IPropertyDescriptor[] getPropertyDescriptors() {
		List<PropertyDescriptor> descriptors = new ArrayList<PropertyDescriptor>();

		Map<String, Object> properties = this.getProperties();
		for (String key : properties.keySet()) {
			PropertyDescriptor descriptor = new PropertyDescriptor(key, key);
			descriptor.setAlwaysIncompatible(true);
			descriptors.add(descriptor);
		}

		return descriptors.toArray(new IPropertyDescriptor[0]);
	}
	
	public Object getPropertyValue(Object id) {
		Map<String, Object> properties = this.getProperties();
		return properties.get(id);
	}
	
	public boolean isPropertySet(Object id) {
		return false;
	}

	public void resetPropertyValue(Object id) {
	}

	public void setPropertyValue(Object id, Object value) {
	}
}
