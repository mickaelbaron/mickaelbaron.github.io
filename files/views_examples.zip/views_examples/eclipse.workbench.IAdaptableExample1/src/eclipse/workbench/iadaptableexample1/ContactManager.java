package eclipse.workbench.iadaptableexample1;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class ContactManager {
	private List<Contact> contacts;

	public ContactManager() {
		this.contacts = new ArrayList<Contact>();

		Contact contact = new Contact("Mickael BARON", "1 rue des Eclipses");
		contact.setProperty("Created", "2008/04/05 11:44");
		contact.setProperty("Updated", "2008/04/05 11:53");
		this.contacts.add(contact);

		contact = new Contact("Tom STORY", "11 rue du Pixar");
		contact.setProperty("Created", "2008/04/05 15:21");
		contact.setProperty("Updated", "2008/04/07 09:48");
		this.contacts.add(contact);

		contact = new Contact("Sarah PRINCESSE", "32 rue des Goonies");
		contact.setProperty("Created", "2008/04/06 10:34");
		this.contacts.add(contact);
	}

	public Contact[] contacts() {
		return (Contact[])this.contacts.toArray(new Contact[0]);
	}
}
