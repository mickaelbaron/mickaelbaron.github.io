package eclipse.workbench.linkviewexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class LinkView2 extends ViewPart {

	private String familyName;
	
	public String getFamilyName() {
		return familyName;
	}

	public String getFirstName() {
		return firstName;
	}

	private String firstName;
	
	public LinkView2() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(2, false));
		
		Label nameLabel = new Label(parent, SWT.NONE);
		nameLabel.setText("Family Name");
		Label fnameLabel = new Label(parent, SWT.NONE);
		fnameLabel.setText("First Name");
		final Text nameText = new Text(parent, SWT.BORDER);
		nameText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				familyName = nameText.getText();
			}			
		});
		final Text fnameText = new Text(parent, SWT.BORDER);
		fnameText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				firstName = fnameText.getText();
			}
		});
	}

	@Override
	public void setFocus() {
	}
}
