package eclipse.workbench.linkviewexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class LinkView1 extends ViewPart {

	public LinkView1() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Button getLinkView2DataButton = new Button(parent, SWT.FLAT);
		getLinkView2DataButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
				IViewPart findView = activePage.findView("eclipse.workbench.LinkViewExample.views.linkviewid2");
				if (findView != null) {
					String familyName = ((LinkView2)findView).getFamilyName();
					String firstName = ((LinkView2)findView).getFirstName();
					System.out.println(familyName + " " + firstName);
				} else {
					System.out.println("Instance de vue non cr��e");
				}
				IPerspectiveDescriptor[] openPerspectives = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getOpenPerspectives();
				System.out.println(openPerspectives.length);
			}
		});
		getLinkView2DataButton.setText("Retrieve information from LinkView2");
	}

	@Override
	public void setFocus() {
	}
}
