package eclipse.workbench.linkviewexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class SeveralLinkDirectPerspectiveFactory implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorArea = layout.getEditorArea();
		layout.setEditorAreaVisible(false);

		layout.addView("eclipse.workbench.LinkViewExample.views.multiplelinkviewid",
				IPageLayout.LEFT, 0.45f, editorArea);
		layout.addView("eclipse.workbench.LinkViewExample.views.linkviewid2:1",
				IPageLayout.RIGHT, 0.45f, editorArea);
		layout.addView("eclipse.workbench.LinkViewExample.views.linkviewid2:2",
				IPageLayout.BOTTOM, 0.45f, editorArea);
	}

}
