package eclipse.workbench.linkviewexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class LinkDirectPerspectiveFactory implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorArea = layout.getEditorArea();
		layout.setEditorAreaVisible(false);
		
		layout.addView("eclipse.workbench.LinkViewExample.views.linkviewid1", IPageLayout.LEFT, 0.45f, editorArea);
		layout.addView("eclipse.workbench.LinkViewExample.views.linkviewid2", IPageLayout.RIGHT, 0.45f, editorArea);
	}

}
