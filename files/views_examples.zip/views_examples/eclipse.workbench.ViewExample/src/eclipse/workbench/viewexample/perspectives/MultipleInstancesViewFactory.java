package eclipse.workbench.viewexample.perspectives;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class MultipleInstancesViewFactory implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorAreaId = layout.getEditorArea();
		
		layout.addView("eclipse.workbench.ViewExample.MultipleInstanceView1:1", IPageLayout.LEFT, 0.25f,
				editorAreaId);

		layout.addView("eclipse.workbench.ViewExample.MultipleInstanceView1:2", IPageLayout.BOTTOM, 0.25f,
				editorAreaId);
	}

}
