package eclipse.workbench.viewexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class MultipleInstanceViewPart2 extends ViewPart {

	public MultipleInstanceViewPart2() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Button myButton = new Button(parent, SWT.FLAT);
		myButton.setText("Give me the Secondary ID");
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				String secondaryId = getViewSite().getSecondaryId();
				System.out.println(secondaryId);
			}
		});
	}

	@Override
	public void setFocus() {
	}
}
