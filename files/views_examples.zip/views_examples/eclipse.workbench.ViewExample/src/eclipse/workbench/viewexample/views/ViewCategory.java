package eclipse.workbench.viewexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class ViewCategory extends ViewPart {

	public ViewCategory() {
	}

	public void createPartControl(Composite parent) {		
		Label myLabel = new Label(parent, SWT.NONE);
		myLabel.setText("View Category");
	}

	public void setFocus() {
	}
}
