package eclipse.workbench.viewexample.views;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.IViewSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class SimpleView extends ViewPart {

	@Override
	public void dispose() {
		super.dispose();
		
		System.out.println("SimpleView.dispose()");
	}

	@Override
	public void saveState(IMemento memento) {
		super.saveState(memento);
		
		System.out.println("SimpleView.saveState()");
	}

	@Override
	public void init(IViewSite site, IMemento memento) throws PartInitException {
		super.init(site, memento);

		System.out.println("SimpleView.init() with IMemento");
	}

	@Override
	public void init(IViewSite site) throws PartInitException {
		super.init(site);

		System.out.println("SimpleView.init()");
	}

	@Override
	public void setInitializationData(IConfigurationElement cfig,
			String propertyName, Object data) {
		super.setInitializationData(cfig, propertyName, data);

		System.out.println("SimpleView.setInitializationData()");
	}

	public SimpleView() {
		System.out.println("SimpleView.SimpleView()");
	}

	@Override
	public void createPartControl(Composite parent) {
		System.out.println("SimpleView.createPartControl()");
		
		Label myLabel = new Label(parent, SWT.NONE);
		myLabel.setText("Simple View");
	}

	@Override
	public void setFocus() {		
	}
}
