package eclipse.workbench.viewexample.views;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class MultipleInstanceViewPart1 extends ViewPart implements
		ISelectionProvider {

	public MultipleInstanceViewPart1() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Label myCurrentLabel = new Label(parent, SWT.NONE);

		myCurrentLabel.setText("Multiple Instance View Example 1");

		this.getSite().setSelectionProvider(this);

		this.getSite().getPage().addSelectionListener(new ISelectionListener() {

			public void selectionChanged(IWorkbenchPart part,
					ISelection selection) {
			}
		});
	}

	@Override
	public void setFocus() {
	}

	public void addSelectionChangedListener(ISelectionChangedListener listener) {
	}

	public ISelection getSelection() {
		return null;
	}

	public void removeSelectionChangedListener(
			ISelectionChangedListener listener) {
	}

	public void setSelection(ISelection selection) {
	}
}
