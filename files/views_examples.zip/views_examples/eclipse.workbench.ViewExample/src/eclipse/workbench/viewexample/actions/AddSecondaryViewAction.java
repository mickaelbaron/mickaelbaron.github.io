package eclipse.workbench.viewexample.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class AddSecondaryViewAction implements IWorkbenchWindowActionDelegate {

	private int secondaryIdCount = 0;

	public AddSecondaryViewAction() {
	}

	public void run(IAction action) {
		try {
			PlatformUI
					.getWorkbench()
					.getActiveWorkbenchWindow()
					.getActivePage()
					.showView(
							"eclipse.workbench.ViewExample.MultipleInstanceView2",
							Integer.toString(secondaryIdCount),
							IWorkbenchPage.VIEW_CREATE);
			secondaryIdCount++;
		} catch (PartInitException e) {
			e.printStackTrace();
		}		
	}

	public void selectionChanged(IAction action, ISelection selection) {
	}

	public void dispose() {
	}

	public void init(IWorkbenchWindow window) {
	}
}