package eclipse.workbench.viewexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.internal.WorkbenchPage;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : july 2010
 */
@SuppressWarnings("restriction")
public class OpenDetachViewPart extends DetachViewPart {

	public OpenDetachViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		super.createPartControl(parent);
		Button detachViewButton = new Button(parent, SWT.NONE);
		detachViewButton.addSelectionListener(new SelectionAdapter() {
			
			public void widgetSelected(SelectionEvent e) {
				IWorkbenchPage page = getSite().getPage();
				final IViewReference findViewReference = page.findViewReference("eclipse.workbench.ViewExample.openDetachViewId");
				if (!isDetached) {				
					((WorkbenchPage) page).detachView(findViewReference);
				} else {
					((WorkbenchPage) page).attachView(findViewReference);
				}
			}
		});		
		
		detachViewButton.setText("Attach/Detach");
	}

	@Override
	public void setFocus() {
	}
}
