package eclipse.workbench.viewexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Original source on http://eclipsesource.com/blogs/2010/06/23/tip-how-to-detect-that-a-view-was-detached/
 * 
 * Date : august 2009
 */
public class DetachViewPart extends ViewPart {

	private Composite parent;

	private Label label;

	protected boolean isDetached;

	public DetachViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		this.parent = parent;
		parent.setLayout(new RowLayout());
		label = new Label(parent, SWT.NONE);

		parent.addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent e) {
				updateDetached();
			}
		});
		updateDetached();
	}

	@Override
	public void setFocus() {
	}

	private void updateDetached() {
		isDetached = parent.getShell().getText().length() == 0;
		label.setText("View isDetached? " + isDetached);
	}
}
