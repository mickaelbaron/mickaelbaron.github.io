package eclipse.workbench.viewexample.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.ui.views.IStickyViewDescriptor;
import org.eclipse.ui.views.IViewCategory;
import org.eclipse.ui.views.IViewDescriptor;
import org.eclipse.ui.views.IViewRegistry;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class ViewRegistryViewPart extends ViewPart {

	public ViewRegistryViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		GridLayout myGRidLayout = new GridLayout(1, false);
		parent.setLayout(myGRidLayout);
		
		Button findView = new Button(parent, SWT.FLAT);
		findView.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				System.out.println("- Find View -");
				IViewRegistry viewRegistry = PlatformUI.getWorkbench().getViewRegistry();
				IViewDescriptor find = viewRegistry.find("eclipse.workbench.ViewExample.views.ViewRegistryId");
				System.out.println(find.getLabel());
				System.out.println(find.getAllowMultiple());
			}
		});
		findView.setText("Find : ViewRegistryId");
		
		Button getCategories = new Button(parent, SWT.FLAT);
		getCategories.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				System.out.println("- Get Categories -");
				IViewRegistry viewRegistry = PlatformUI.getWorkbench().getViewRegistry();
				IViewCategory[] categories = viewRegistry.getCategories();
				for (IViewCategory viewCategory : categories) {
					System.out.println(viewCategory.getLabel());
				}
			}
		});
		getCategories.setText("Get Categories");
		
		Button getStickyViews = new Button(parent, SWT.FLAT);
		getStickyViews.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("- Get Sticky Views -");
				IViewRegistry viewRegistry = PlatformUI.getWorkbench().getViewRegistry();
				IStickyViewDescriptor[] stickyViews = viewRegistry.getStickyViews();
				for (IStickyViewDescriptor stickyViewDescriptor : stickyViews) {
					System.out.println(stickyViewDescriptor.getId() + " " + stickyViewDescriptor.getLocation());
				}
			}			
		});
		getStickyViews.setText("Get Sticky Views");

		Button getViews = new Button(parent, SWT.FLAT);
		getViews.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("- Get Views -");
				IViewRegistry viewRegistry = PlatformUI.getWorkbench().getViewRegistry();
				IViewDescriptor[] views = viewRegistry.getViews();
				for (IViewDescriptor viewDescriptor : views) {
					System.out.println(viewDescriptor.getId());
				}
			}			
		});
		getViews.setText("Get Views");
	}

	@Override
	public void setFocus() {
	}
}
