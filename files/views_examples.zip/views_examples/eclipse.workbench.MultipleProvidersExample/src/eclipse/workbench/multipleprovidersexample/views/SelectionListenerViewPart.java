package eclipse.workbench.multipleprovidersexample.views;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : august 2009
 */
public class SelectionListenerViewPart extends ViewPart {

	public SelectionListenerViewPart() {
	}

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, true));
		final Label listenerLabel = new Label(parent, SWT.NONE);

		this
				.getSite()
				.getWorkbenchWindow()
				.getSelectionService()
				.addSelectionListener(
						"eclipse.workbench.MultipleProvidersExample.views.multipleprovidersid",
						new ISelectionListener() {
							public void selectionChanged(IWorkbenchPart part,
									ISelection selection) {
								if (selection == null) {
									return;
								}

								if (selection instanceof IStructuredSelection) {
									IStructuredSelection structuredSelection = (IStructuredSelection) selection;
									Object firstElement = structuredSelection
											.getFirstElement();
									if (firstElement != null) {
										listenerLabel.setText("Selected object : " + firstElement
												.toString());
										listenerLabel.getParent().pack();
									}
								}
							}
						});
	}

	@Override
	public void setFocus() {
	}
}
