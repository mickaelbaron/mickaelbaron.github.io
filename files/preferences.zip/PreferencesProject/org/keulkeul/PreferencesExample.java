package org.keulkeul;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.prefs.Preferences;

import javax.swing.JFrame;

/**
 * Copyright (C) 2006  Mickaël BARON
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * @author Mickaël BARON (baron.mickael@gmail.com)
 **/
public class PreferencesExample extends JFrame {

	private Preferences myPref;
	
	public PreferencesExample() {
		myPref = Preferences.systemNodeForPackage(this.getClass()); // Specific Preferences for the current application
		Preferences.systemRoot(); // Global Preferences for the current application
		
		Preferences.userNodeForPackage(this.getClass()); // Specific Preferences for the user
		Preferences.userRoot(); // Global Preferences for the current application
		
		// Load preferences
		this.loadProperties();
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				// Save preferences
				saveProperties();
				System.exit(0);
			}			
		});
		this.setVisible(true);
	}
	
	private void loadProperties() {
		double width = Double.parseDouble(myPref.get("width", "200"));
		double height = Double.parseDouble(myPref.get("height", "200"));
		double posx = Double.parseDouble(myPref.get("posx","0"));
		double posy = Double.parseDouble(myPref.get("posy", "0"));
		System.out.println(width + " " + height + " " + posx + " " + posy);
		this.setBounds((int)posx, (int)posy, (int)width, (int)height);
	}
	
	public void saveProperties() {
		myPref.put("width",Double.toString(this.getSize().getWidth()));
		myPref.put("height",Double.toString(this.getSize().getHeight()));
		myPref.put("posx",Double.toString(this.getBounds().getX()));
		myPref.put("posy",Double.toString(this.getBounds().getY()));		
	}
	
	public static void main(String[] argv) {
		new PreferencesExample();
	}
}
