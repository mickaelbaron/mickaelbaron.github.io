package org.keulkeul;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JFrame;

/**
 * Copyright (C) 2006  Mickaël BARON
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * @author Mickaël BARON (baron.mickael@gmail.com)
 **/
public class PropertiesExample extends JFrame {

	private static final long serialVersionUID = 5716408270528223486L;

	private Properties prop;
	
	public PropertiesExample() {
		prop = new Properties();

		// Load preferences
		this.loadProperties();
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				// Save preferences
				saveProperties();
				System.exit(0);
			}			
		});
		this.setVisible(true);
	}
	
	public void loadProperties() {
		try {
			FileInputStream in = new FileInputStream("config.ini");
			prop.load(in);
			in.close();
		} catch (IOException e) {
		}
		
		double width = Double.parseDouble(prop.getProperty("width", "200"));
		double height = Double.parseDouble(prop.getProperty("height", "200"));
		double posx = Double.parseDouble(prop.getProperty("posx", "0"));
		double posy = Double.parseDouble(prop.getProperty("posy", "0"));
		System.out.println(width + " " + height + " " + posx + " " + posy);
		this.setBounds((int)posx, (int)posy, (int)width, (int)height);
	}
	
	public void saveProperties() {
		prop.setProperty("width",Double.toString(this.getSize().getWidth()));
		prop.setProperty("height",Double.toString(this.getSize().getHeight()));
		prop.setProperty("posx",Double.toString(this.getBounds().getX()));
		prop.setProperty("posy",Double.toString(this.getBounds().getY()));		
		try {
			FileOutputStream out = new FileOutputStream("config.ini");
			prop.store(out,"");
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] argv) {
		new PropertiesExample();
	}
}
