package javaee.dwr.clientside;

import java.util.Observable;
import java.util.Observer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.directwebremoting.proxy.dwr.Util;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : december 2007
 */
public class ClientSide extends Observable implements Observer {

	private WebContext wctx = null;

	private static final Log log = LogFactory.getLog(ClientSide.class);

	public ClientSide() {
		wctx = WebContextFactory.get();
		Object tt = wctx.getServletContext().getAttribute("desktopandweb");
		if (tt instanceof Observable) {
			log.info("Observable trouv�");
			Observable tto = (Observable) tt;
			tto.addObserver(this);
		}

		if (tt instanceof Observer) {
			log.info("Observer trouv�");
			Observer te = (Observer) tt;
			this.addObserver(te);
		}
	}

	public void setValue(String value) {
		this.setChanged();
		this.notifyObservers(value);
	}

	public void update(Observable observable, Object param) {
		try {
			String currentPage = wctx.getCurrentPage();
			Util pages = new Util(wctx.getScriptSessionsByPage(currentPage));
			pages.setValue("text", param.toString());
			log.info("Valeur envoy�e aux clients");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
