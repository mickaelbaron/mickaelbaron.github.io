package eclipse.rcp.desktopandweb;

import java.util.Observable;
import java.util.Observer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;
import org.mortbay.jetty.Connector;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.nio.SelectChannelConnector;
import org.mortbay.jetty.webapp.WebAppContext;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : december 2007
 */
public class View extends ViewPart {
	public static final String ID = "eclipse.rcp.DesktopAndWeb.view";

	private Browser myBrowser;

	private WebAppContext webapp;

	private Text myText;

	private ServerThread serverThread;

	public void createPartControl(Composite parent) {
		parent.setLayout(new GridLayout(1, true));
		myBrowser = new Browser(parent, SWT.MOZILLA);
		GridData myData = new GridData(GridData.FILL_BOTH);
		myBrowser.setLayoutData(myData);
		Button myButton = new Button(parent, SWT.FLAT);
		myButton.setText("Démarrer");
		myButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				serverThread = new ServerThread();
			}
		});

		Button loadURL = new Button(parent, SWT.FLAT);
		loadURL.setText("Charger Page");
		loadURL.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				myBrowser.setUrl("http://localhost:8080");
			}
		});

		myText = new Text(parent, SWT.BORDER);
		Button applyButton = new Button(parent, SWT.FLAT);
		applyButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				serverThread.setValue(myText.getText());
			}
		});
		applyButton.setText("Envoyer vers HTML");
	}


	public void setFocus() {
		myBrowser.setFocus();
	}

	class ServerThread extends Observable implements Observer, Runnable {
		private String value;

		public ServerThread() {
			new Thread(this).start();
		}

		public void run() {
			Server server = new Server();

			Connector connector = new SelectChannelConnector();
			connector.setPort(Integer.getInteger("jetty.port", 8080).intValue());
			server.setConnectors(new Connector[] { connector });

			webapp = new WebAppContext();
			webapp.setAttribute("desktopandweb", this);
			webapp.setContextPath("/");
			webapp.setWar("c:\\javaee.dwr.clientside");
			server.setHandler(webapp);
			try {
				server.start();
				server.join();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}

		public void setValue(String value) {
			this.setChanged();
			this.notifyObservers(value);
		}

		public void update(Observable observable, Object param) {
			value = param.toString();
			Display.getDefault().asyncExec(new Runnable() {
				public void run() {
					View.this.myText.setText(value.toString());
				}
			});
		}
	}
}