import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2007
 */
@SuppressWarnings("serial")
public class PushServerServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		ServletOutputStream out = res.getOutputStream();

		res.setContentType("multipart/x-mixed-replace;boundary=End");
		out.println();
		out.println("--End");

		for (int i = 10; i > 0; i--) {
			out.println("Content-Type: text/plain");
			out.println();
			out.println(new Date().toString());
			out.println();
			out.println("--End");
			out.flush();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}

		out.println("Content-Type: text/plain");
		out.println();
		out.println("Fin");

		out.println("--End--");
		out.flush();
	}
}
