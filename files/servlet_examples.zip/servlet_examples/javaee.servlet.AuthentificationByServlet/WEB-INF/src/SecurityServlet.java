import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2007
 */
@SuppressWarnings("serial")
public class SecurityServlet extends HttpServlet {
	@SuppressWarnings("unchecked")
	private Hashtable users = new Hashtable();

	@SuppressWarnings("unchecked")
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		users.put("keulkeul:manoue", "allowed");
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/plain");
		PrintWriter out = res.getWriter();

		String auth = req.getHeader("Authorization");

		if (!allowUser(auth)) {
			res.setHeader("WWW-Authenticate", "BASIC realm=\"users\"");
			res.sendError(HttpServletResponse.SC_UNAUTHORIZED);
		} else {
			out.println("Page Top-Secret");
		}
	}

	protected boolean allowUser(String auth) throws IOException {
		if (auth == null)
			return false;

		if (!auth.toUpperCase().startsWith("BASIC "))
			return false;

		String userpassEncoded = auth.substring(6);
		String userpassDecoded = Base64EnDecoder.decode(userpassEncoded);

		return ("allowed".equals(users.get(userpassDecoded)));
	}
}
