import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
@SuppressWarnings("serial")
public class InfosServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		out.print("Protocol: " + request.getProtocol());
		out.println(" Scheme: " + request.getScheme());
		out.print("ServerName: " + request.getServerName());
		out.println(" ServerPort: " + request.getServerPort());
		out.print("RemoteAddr: " + request.getRemoteAddr());
		out.println(" RemoteHost: " + request.getRemoteHost());
		out.print("Method: " + request.getMethod());
		out.println(" requestuestURI: " + request.getRequestURI());
		out.print("ServletPath: " + request.getServletPath());
		out.println(" PathInfo: " + request.getPathInfo());
		out.print("PathTranslated: " + request.getPathTranslated());
		out.println(" QueryString: " + request.getQueryString());
		out.print("RemoteUser: " + request.getRemoteUser());
		out.println(" AuthType: " + request.getAuthType());
	}
}
