import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2007
 */
@SuppressWarnings("serial")
public class SecurityFormServlet extends HttpServlet {	
	@SuppressWarnings("unchecked")
	private Hashtable users = new Hashtable();

	@SuppressWarnings("unchecked")
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		users.put("keulkeul:manoue","allowed");
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String account = req.getParameter("account");
		String password = req.getParameter("password");
		
		if (!allowUser(account, password)) {
			out.println("<HTML><HEAD><TITLE>Access Denied</TITLE></HEAD>");
			out.println("<BODY>Votre compte et mot de passe sont incorrects.<BR>");
			out.println("<A HREF=\"/SecuritePersoFormServlet/index.html\">Retenter</A>");
			out.println("</BODY></HTML>");
		} else {
			HttpSession session = req.getSession();
			session.setAttribute("logon.isDone", account);
			out.println("Bravo : " + account);
		}
	}
	
	protected boolean allowUser(String account, String password) {
		String tempo = account + ":" + password;
		if ("allowed".equals(users.get(tempo))) 
			return true;
		else 
			return false;
	}
}
