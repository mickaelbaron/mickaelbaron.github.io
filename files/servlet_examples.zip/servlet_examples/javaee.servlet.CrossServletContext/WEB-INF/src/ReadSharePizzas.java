import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2007
 */
@SuppressWarnings("serial")
public class ReadSharePizzas extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        
        ServletContext my_context = this.getServletContext();
        ServletContext pizzas_context = my_context.getContext("/ServletContext");	
        String pizza_specialite = (String)pizzas_context.getAttribute("Specialite");
        Date day = (Date)pizzas_context.getAttribute("Date");

        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        String today = df.format(day);
      
        out.println("Aujourd'hui (" + today + "), notre specialite est : " + pizza_specialite);    
    }
}
