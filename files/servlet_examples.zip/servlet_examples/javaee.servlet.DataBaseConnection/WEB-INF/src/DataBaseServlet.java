import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2007
 */
@SuppressWarnings("serial")
public class DataBaseServlet extends HttpServlet {

	/**
	 * SQL script that select NAME, FIRSTNAME, OLDYEAR.
	 */
	private static final String SELECT_TABLE = "select NAME, FIRSTNAME, OLDYEAR from PERSON";

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		try {
			querySelect(out);
			out.println("<br>Creation et initialisation de la base "
					+ InitDataBaseServlet.DATABASE + " reussie.");
		} catch (SQLException e) {
			out.println("Probl�me li� � une erreur sur une requ�te SQL");
			out.println(e.getMessage());
		} catch (IllegalAccessException e) {
			out.println("Probl�me d'acc�s ill�gale � une m�thode");
		} catch (ClassNotFoundException e) {
			out.println("Driver non trouv�");
		} catch (InstantiationException e) {
			out.println("Probl�me li� � l'instanciation d'un objet");
		}
	}

	private void querySelect(PrintWriter out) throws SQLException,
			IllegalAccessException, ClassNotFoundException,
			InstantiationException {

		Connection currentConnection = null;

		Class.forName(InitDataBaseServlet.DRIVER).newInstance();
		currentConnection = DriverManager.getConnection(InitDataBaseServlet.PROTOCOL + InitDataBaseServlet.DATABASE);
		Statement s = currentConnection.createStatement();
		try {
			ResultSet myResult = s.executeQuery(SELECT_TABLE);
			while (myResult.next()) {
				out.print("Nom : " + myResult.getString(1));
				out.print(" Prenom : " + myResult.getString(2));
				out.println(" Age : " + myResult.getInt(3));
				out.println("<br>");
			}
		} finally {
			s.close();
		}
	}
}
