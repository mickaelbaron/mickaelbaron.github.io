import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2007
 */
@SuppressWarnings("serial")
public class InitDataBaseServlet extends HttpServlet {

	/**
	 * Driver 
	 */
	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver";

	/**
	 * Protocol 
	 */
	public static final String PROTOCOL = "jdbc:derby://localhost:1527/";
	
	/**
	 * DataBase name  
	 */
	public static final String DATABASE = "PersonDB";

	/**
	 * SQL script that create Person Table 
	 */
	private static final String CREATE_TABLE = "CREATE TABLE PERSON (Name VARCHAR(20), FirstName VARCHAR(20), OLDYear int)";

	/**
	 * SQL script that add new row into the Person table 
	 */
	private static final String INSERT_RECORDS_QUERY = "insert into PERSON (NAME, FIRSTNAME, OLDYEAR) values ";

	private void queryRecords() throws SQLException, IllegalAccessException,
			ClassNotFoundException, InstantiationException {

		Connection currentConnection = null;

		try {
			Class.forName(DRIVER).newInstance();
			currentConnection = DriverManager.getConnection(PROTOCOL + DATABASE);
		} catch (SQLException sqlException) {
			currentConnection = DriverManager.getConnection(PROTOCOL + DATABASE + ";create=true");
			try {
				Statement s = currentConnection.createStatement();
				try {
					s.execute(CREATE_TABLE);					
				} finally {
					s.close();
				}
				currentConnection.commit();
			} catch (SQLException ex) {
				currentConnection.close();
				throw ex;
			}
		}
		try {
			Statement s = currentConnection.createStatement();
			try {
				s.execute(INSERT_RECORDS_QUERY + "('Chirac', 'Patrick', 50)");
				s.execute(INSERT_RECORDS_QUERY + "('Sanou', 'Loe', 30)");
				s.execute(INSERT_RECORDS_QUERY + "('Dupont', 'Cecile', 15)");
				s.execute(INSERT_RECORDS_QUERY + "('Dubois', 'Raoul', 50)");
				s.execute(INSERT_RECORDS_QUERY + "('Brooks', 'Robert', 50)");
				s.execute(INSERT_RECORDS_QUERY + "('Baron', 'Mickael', 30)");
				currentConnection.commit();				
			} finally {
				s.close();
			}
		} finally {
			currentConnection.close();
		}
	}

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		try {
			queryRecords();
			out.println("Cr�ation et initialisation de la base " + DATABASE + " r�ussie.");
		} catch (SQLException e) {
			out.println("Probl�me li� � une erreur sur une requ�te SQL");
			out.println(e.getMessage());
		} catch (IllegalAccessException e) {
			out.println("Probl�me d'acc�s ill�gale � une m�thode");
		} catch (ClassNotFoundException e) {
			out.println("Driver non trouv�");
		} catch (InstantiationException e) {
			out.println("Probl�me li� � l'instanciation d'un objet");
		}
	}
}
