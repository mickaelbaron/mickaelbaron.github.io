import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
@SuppressWarnings("serial")
public class GenerateImageServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		ServletOutputStream out = res.getOutputStream();
		Frame frame = null; Graphics2D g = null;

		frame = new Frame();
		frame.addNotify();
		
		BufferedImage buffer_image = new BufferedImage(620, 60,BufferedImage.TYPE_3BYTE_BGR);
		g = buffer_image.createGraphics();
		
		g.setFont(new Font("Serif", Font.ITALIC, 48));
		g.drawString("Bonjour tout le monde !", 10,50);	

		JPEGImageEncoder encode = JPEGCodec.createJPEGEncoder(out);
		encode.encode(buffer_image);
		out.close();
	}
}
