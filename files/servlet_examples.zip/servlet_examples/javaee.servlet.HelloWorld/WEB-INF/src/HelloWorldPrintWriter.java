import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
@SuppressWarnings("serial")
public class HelloWorldPrintWriter extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/plain");
		
		PrintWriter out = res.getWriter();
		
		out.println("Premier Message");
		out.println("Coucou voil� comment �crire un message");
		out.println("Second Message");
	}
}
