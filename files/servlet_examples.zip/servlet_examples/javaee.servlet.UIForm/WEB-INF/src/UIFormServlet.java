import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Date : october 2007
 */
@SuppressWarnings("serial")
public class UIFormServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/plain");
		PrintWriter out = res.getWriter();
		
		out.println("Nom : " + req.getParameter("nom"));
		out.println("Pr�nom : " + req.getParameter("prenom"));
		
		if (req.getParameterValues("radio1")[0].equals("mas")) {
			out.print("C'est un homme. Il");
		} else {
			out.print("C'est une femme. Elle");
		}
		
		out.print(" a �crit sur ce magnifique cours que ");
		out.println(req.getParameter("textarea"));
	}
}
