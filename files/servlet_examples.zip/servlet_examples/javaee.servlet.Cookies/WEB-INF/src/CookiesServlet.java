import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : october 2007
 */
@SuppressWarnings("serial")
public class CookiesServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/plain");
		PrintWriter out = res.getWriter();
		String sessionId = null;
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals("sessionid")) {
					sessionId = cookies[i].getValue();
				}
			}
		}
		if (sessionId == null) {
			sessionId = new java.rmi.server.UID().toString();
			Cookie c = new Cookie("sessionid", sessionId);
			res.addCookie(c);
			out.println("Bonjour le nouveau");
		} else {
			out.println("Encore vous");
		}
	}
}
