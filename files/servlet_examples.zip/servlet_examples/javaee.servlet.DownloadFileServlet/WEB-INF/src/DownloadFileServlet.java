import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 *
 * Permet de t�l�charger un fichier sur le client.
 *
 * Date : october 2007
 */
@SuppressWarnings("serial")
public class DownloadFileServlet extends HttpServlet {
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1)
		throws ServletException, IOException {

		try   {
			InputStream is = new FileInputStream("c:\\file.txt");
			OutputStream os = arg1.getOutputStream();
			arg1.setContentType("application/octet-stream");
			arg1.setHeader("Content-Disposition","attachment;filename=toto.xml");
			int count;
			byte buf[] = new byte[4096];
			while ((count = is.read(buf)) > -1)
				os.write(buf, 0, count);
			is.close();
			os.close();
		} catch (Exception e) {
			arg1.setContentType("text/html");
			PrintWriter out = arg1.getWriter();
			out.println("Probl�me de t�l�chargement du fichier : contactez l'administrateur ...");
		}
	}
}
