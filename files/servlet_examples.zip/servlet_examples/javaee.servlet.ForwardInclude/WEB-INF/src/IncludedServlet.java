import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mickael BARON (baron.mickael@gmail.com)
 * 
 * Date : november 2007
 */
@SuppressWarnings("serial")
public class IncludedServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        PrintWriter out = res.getWriter();
        if(req.getAttribute("bonjour") != null) {
            out.println(req.getAttribute("bonjour"));
            if (req.getAttribute("bonsoir") != null) {
                out.println(req.getAttribute("bonsoir"));
            } else {
                out.println("Pas Bonsoir");
            }
        } else {
            out.println("Rien de rien");
        }
    }
}
